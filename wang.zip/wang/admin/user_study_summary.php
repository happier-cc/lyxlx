<?php
require_once '../config/database.php';

if (!isset($_SESSION['user_id']) || $_SESSION['role'] != 'admin') {
    header("Location: login.php");
    exit();
}

// 获取所有课程用于筛选 - 使用正确的字段名 course_name
$courses_sql = "SELECT id, course_name FROM courses ORDER BY created_at DESC";
$courses_stmt = $pdo->query($courses_sql);
$courses = $courses_stmt->fetchAll();

// 获取筛选条件
$course_filter = isset($_GET['course_id']) && $_GET['course_id'] ? $_GET['course_id'] : 'all';

// 构建基础查询
$base_sql = "
    SELECT 
        u.id,
        u.username,
        u.role,
        u.created_at as register_time,
        u.last_login,
        MAX(up.completed_at) as last_study_time
    FROM users u
    LEFT JOIN user_progress up ON u.id = up.user_id AND up.completed = TRUE
";

// 如果选择了特定课程，添加关联条件
if ($course_filter != 'all') {
    $base_sql .= "
        LEFT JOIN projects p ON up.project_id = p.id
        LEFT JOIN modules m ON p.module_id = m.id
        WHERE m.course_id = :course_id
    ";
}

$base_sql .= " GROUP BY u.id ORDER BY last_study_time DESC";

// 执行基础查询获取用户列表
if ($course_filter != 'all') {
    $base_stmt = $pdo->prepare($base_sql);
    $base_stmt->execute(['course_id' => $course_filter]);
} else {
    $base_stmt = $pdo->query($base_sql);
}
$user_list = $base_stmt->fetchAll();

// 获取详细的统计信息
$user_summary = [];
foreach ($user_list as $user) {
    // 根据是否筛选课程构建不同的统计查询
    if ($course_filter != 'all') {
        $stat_sql = "
            SELECT 
                COUNT(DISTINCT p.id) as completed_projects,
                SUM(up.attempt_count) as total_attempts,
                AVG(up.score) as avg_score,
                SUM(up.study_duration) as total_study_time,
                -- 错题统计（仅限当前课程）
                (SELECT COUNT(*) 
                 FROM wrong_questions wq 
                 JOIN projects p2 ON wq.project_id = p2.id
                 JOIN modules m2 ON p2.module_id = m2.id
                 WHERE wq.user_id = :user_id AND m2.course_id = :course_id) as total_wrong,
                -- 收藏统计（仅限当前课程）
                (SELECT COUNT(*) 
                 FROM favorite_questions fq 
                 JOIN projects p3 ON fq.project_id = p3.id
                 JOIN modules m3 ON p3.module_id = m3.id
                 WHERE fq.user_id = :user_id2 AND m3.course_id = :course_id2) as total_favorites,
                -- 有错题的项目数（仅限当前课程）
                (SELECT COUNT(DISTINCT p4.id) 
                 FROM wrong_questions wq2 
                 JOIN projects p4 ON wq2.project_id = p4.id
                 JOIN modules m4 ON p4.module_id = m4.id
                 WHERE wq2.user_id = :user_id3 AND m4.course_id = :course_id3) as wrong_projects,
                -- 有收藏的项目数（仅限当前课程）
                (SELECT COUNT(DISTINCT p5.id) 
                 FROM favorite_questions fq2 
                 JOIN projects p5 ON fq2.project_id = p5.id
                 JOIN modules m5 ON p5.module_id = m5.id
                 WHERE fq2.user_id = :user_id4 AND m5.course_id = :course_id4) as favorite_projects,
                -- 学习历史记录数（仅限当前课程）
                (SELECT COUNT(*) 
                 FROM user_study_history ush 
                 JOIN projects p6 ON ush.project_id = p6.id
                 JOIN modules m6 ON p6.module_id = m6.id
                 WHERE ush.user_id = :user_id5 AND m6.course_id = :course_id5) as history_count,
                -- 当前课程完成项目数
                (SELECT COUNT(DISTINCT p7.id)
                 FROM user_progress up7 
                 JOIN projects p7 ON up7.project_id = p7.id
                 JOIN modules m7 ON p7.module_id = m7.id
                 WHERE up7.user_id = :user_id6 AND m7.course_id = :course_id6 AND up7.completed = TRUE) as course_completed_projects,
                -- 当前课程总项目数
                (SELECT COUNT(*) 
                 FROM projects p8 
                 JOIN modules m8 ON p8.module_id = m8.id
                 WHERE m8.course_id = :course_id7) as total_course_projects
            FROM users u
            LEFT JOIN user_progress up ON u.id = up.user_id AND up.completed = TRUE
            LEFT JOIN projects p ON up.project_id = p.id
            LEFT JOIN modules m ON p.module_id = m.id AND m.course_id = :course_id8
            WHERE u.id = :user_id7
            GROUP BY u.id
        ";
        
        $stat_stmt = $pdo->prepare($stat_sql);
        $stat_params = [
            'user_id' => $user['id'],
            'user_id2' => $user['id'],
            'user_id3' => $user['id'],
            'user_id4' => $user['id'],
            'user_id5' => $user['id'],
            'user_id6' => $user['id'],
            'user_id7' => $user['id'],
            'course_id' => $course_filter,
            'course_id2' => $course_filter,
            'course_id3' => $course_filter,
            'course_id4' => $course_filter,
            'course_id5' => $course_filter,
            'course_id6' => $course_filter,
            'course_id7' => $course_filter,
            'course_id8' => $course_filter
        ];
        $stat_stmt->execute($stat_params);
    } else {
        // 全部课程的数据
        $stat_sql = "
            SELECT 
                COUNT(DISTINCT up.project_id) as completed_projects,
                SUM(up.attempt_count) as total_attempts,
                AVG(up.score) as avg_score,
                SUM(up.study_duration) as total_study_time,
                (SELECT COUNT(*) FROM wrong_questions wq WHERE wq.user_id = u.id) as total_wrong,
                (SELECT COUNT(*) FROM favorite_questions fq WHERE fq.user_id = u.id) as total_favorites,
                (SELECT COUNT(DISTINCT project_id) FROM wrong_questions wq WHERE wq.user_id = u.id) as wrong_projects,
                (SELECT COUNT(DISTINCT project_id) FROM favorite_questions fq WHERE fq.user_id = u.id) as favorite_projects,
                (SELECT COUNT(*) FROM user_study_history ush WHERE ush.user_id = u.id) as history_count,
                (SELECT COUNT(DISTINCT c.id) 
                 FROM courses c 
                 JOIN modules m ON c.id = m.course_id 
                 JOIN projects p ON m.id = p.module_id 
                 JOIN user_progress up2 ON p.id = up2.project_id 
                 WHERE up2.user_id = u.id AND up2.completed = TRUE) as completed_courses,
                (SELECT COUNT(DISTINCT m.id) 
                 FROM modules m 
                 JOIN projects p ON m.id = p.module_id 
                 JOIN user_progress up2 ON p.id = up2.project_id 
                 WHERE up2.user_id = u.id AND up2.completed = TRUE) as completed_modules,
                0 as course_completed_projects,
                0 as total_course_projects
            FROM users u
            LEFT JOIN user_progress up ON u.id = up.user_id AND up.completed = TRUE
            WHERE u.id = :user_id
            GROUP BY u.id
        ";
        
        $stat_stmt = $pdo->prepare($stat_sql);
        $stat_stmt->execute(['user_id' => $user['id']]);
    }
    
    $stat = $stat_stmt->fetch();
    
    // 合并用户基本信息和统计信息
    $user_summary[] = array_merge($user, $stat ? $stat : []);
}

// 获取当前课程名称
$current_course_name = '所有课程';
if ($course_filter != 'all') {
    $course_name_sql = "SELECT course_name FROM courses WHERE id = ?";
    $course_name_stmt = $pdo->prepare($course_name_sql);
    $course_name_stmt->execute([$course_filter]);
    $course_data = $course_name_stmt->fetch();
    $current_course_name = $course_data ? $course_data['course_name'] : '未知课程';
}

// 统计信息
$total_users = count($user_summary);
$active_users = array_filter($user_summary, function($user) {
    return !empty($user['last_study_time']);
});

// 计算平均完成率（仅限筛选课程时）
if ($course_filter != 'all') {
    $total_completed_projects = array_sum(array_column($user_summary, 'course_completed_projects'));
    $total_course_projects = $user_summary[0]['total_course_projects'] ?? 0;
    $avg_completion_rate = $total_users > 0 && $total_course_projects > 0 
        ? round(($total_completed_projects / ($total_users * $total_course_projects)) * 100, 1)
        : 0;
}

$avg_completed_projects = $total_users > 0 ? round(array_sum(array_column($user_summary, 'completed_projects')) / $total_users, 1) : 0;
$avg_score_all = $total_users > 0 ? round(array_sum(array_column($user_summary, 'avg_score')) / $total_users, 1) : 0;
$total_attempts_all = $total_users > 0 ? array_sum(array_column($user_summary, 'total_attempts')) : 0;
$avg_attempts_per_user = $total_users > 0 ? round($total_attempts_all / $total_users, 1) : 0;
$avg_completed_courses = $course_filter == 'all' && $total_users > 0 ? round(array_sum(array_column($user_summary, 'completed_courses')) / $total_users, 1) : 0;
$avg_completed_modules = $course_filter == 'all' && $total_users > 0 ? round(array_sum(array_column($user_summary, 'completed_modules')) / $total_users, 1) : 0;

// 格式化学习时长
function formatStudyTime($seconds) {
    if (!$seconds) return '0分钟';
    
    $hours = floor($seconds / 3600);
    $minutes = floor(($seconds % 3600) / 60);
    
    if ($hours > 0) {
        return $hours . '小时' . $minutes . '分钟';
    } else {
        return $minutes . '分钟';
    }
}
?>

<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>用户学习汇总 - 在线刷题系统</title>
    <link rel="stylesheet" href="../config/style.css">
    <style>
        /* 保持原有样式不变，只添加筛选器样式 */
        .filter-container {
            background: white;
            padding: 20px;
            border-radius: 12px;
            margin-bottom: 20px;
            box-shadow: var(--shadow);
        }
        .filter-form {
            display: flex;
            gap: 15px;
            align-items: center;
            flex-wrap: wrap;
        }
        .filter-form select {
            padding: 8px 15px;
            border: 1px solid var(--border-color);
            border-radius: 6px;
            min-width: 200px;
        }
        .filter-form button {
            padding: 8px 20px;
        }
        .current-filter {
            margin-top: 10px;
            font-size: 14px;
            color: var(--primary-color);
            font-weight: 600;
        }
        .filter-info {
            background: var(--bg-secondary);
            padding: 10px 15px;
            border-radius: 8px;
            margin-top: 10px;
            border-left: 4px solid var(--primary-color);
        }
        .completion-rate {
            display: inline-block;
            padding: 2px 8px;
            background: #e3f2fd;
            border-radius: 12px;
            font-size: 12px;
            margin-left: 5px;
        }
        .completion-high { background: #d1fae5; color: #065f46; }
        .completion-medium { background: #fef3c7; color: #92400e; }
        .completion-low { background: #fee2e2; color: #991b1b; }
    </style>
</head>
<body>
    <nav class="navbar">
        <div class="container">
            <div class="nav-content">
                <a href="index.php" class="nav-brand">← 返回后台</a>
                <span class="nav-brand">用户学习汇总</span>
            </div>
        </div>
    </nav>

    <div class="container">
        <div class="summary-container">
            <div class="card">
                <h1>用户学习汇总</h1>
                <p>查看所有用户的学习统计和进度概况</p>

                <!-- 筛选器 -->
                <div class="filter-container">
                    <form method="GET" class="filter-form">
                        <select name="course_id">
                            <option value="all" <?php echo $course_filter == 'all' ? 'selected' : ''; ?>>所有课程</option>
                            <?php foreach ($courses as $course): ?>
                                <option value="<?php echo $course['id']; ?>" 
                                    <?php echo $course_filter == $course['id'] ? 'selected' : ''; ?>>
                                    <?php echo htmlspecialchars($course['course_name']); ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                        <button type="submit" class="btn btn-primary">筛选</button>
                        <a href="user_study_summary.php" class="btn btn-secondary">重置</a>
                    </form>
                    
                    <div class="current-filter">
                        📚 当前查看：<?php echo $current_course_name; ?>
                        <?php if ($course_filter != 'all' && isset($avg_completion_rate)): ?>
                            <span class="completion-rate">
                                平均完成率：<?php echo $avg_completion_rate; ?>%
                            </span>
                        <?php endif; ?>
                    </div>
                    
                    <?php if ($course_filter != 'all' && isset($total_course_projects)): ?>
                        <div class="filter-info">
                            <small>📝 本课程共有 <?php echo $total_course_projects; ?> 个项目，筛选到 <?php echo $total_users; ?> 个学习过的用户</small>
                        </div>
                    <?php endif; ?>
                </div>

                <!-- 统计信息 -->
                <div class="stats-grid">
                    <div class="stat-card">
                        <div class="stat-number"><?php echo $total_users; ?></div>
                        <div><?php echo $course_filter != 'all' ? '相关用户' : '总用户数'; ?></div>
                    </div>
                    <div class="stat-card">
                        <div class="stat-number"><?php echo count($active_users); ?></div>
                        <div>活跃用户</div>
                    </div>
                    <?php if ($course_filter == 'all'): ?>
                        <div class="stat-card">
                            <div class="stat-number"><?php echo $avg_completed_courses; ?></div>
                            <div>平均完成课程</div>
                        </div>
                        <div class="stat-card">
                            <div class="stat-number"><?php echo $avg_completed_modules; ?></div>
                            <div>平均完成模块</div>
                        </div>
                    <?php else: ?>
                        <div class="stat-card">
                            <div class="stat-number">
                                <?php echo $total_course_projects > 0 ? round(($total_completed_projects / $total_course_projects) * 100, 1) : '0'; ?>%
                            </div>
                            <div>课程完成率</div>
                        </div>
                        <div class="stat-card">
                            <div class="stat-number"><?php echo $total_completed_projects; ?></div>
                            <div>总完成项目</div>
                        </div>
                    <?php endif; ?>
                    <div class="stat-card">
                        <div class="stat-number"><?php echo $avg_completed_projects; ?></div>
                        <div>平均完成项目</div>
                    </div>
                    <div class="stat-card">
                        <div class="stat-number"><?php echo $avg_score_all; ?>分</div>
                        <div>平均得分</div>
                    </div>
                    <div class="stat-card">
                        <div class="stat-number"><?php echo $avg_attempts_per_user; ?></div>
                        <div>平均学习次数</div>
                    </div>
                </div>

                <!-- 导出按钮 -->
                <div class="export-buttons">
                    <a href="export_user_summary.php?course_id=<?php echo $course_filter; ?>" class="btn btn-success">
                        📊 导出用户汇总
                    </a>
                    <a href="user_study_records.php" class="btn btn-primary">
                        📖 查看学习记录
                    </a>
                    <?php if ($course_filter != 'all'): ?>
                        <span style="margin-left: auto; font-size: 14px; color: #666;">
                            当前筛选：<?php echo $current_course_name; ?>
                        </span>
                    <?php endif; ?>
                </div>

                <!-- 用户汇总表格 -->
                <?php if (empty($user_summary)): ?>
                    <div class="empty-state">
                        <div style="font-size: 64px; margin-bottom: 20px;">👥</div>
                        <h3>暂无用户数据</h3>
                        <p>还没有用户学习记录</p>
                    </div>
                <?php else: ?>
                    <div style="overflow-x: auto;">
                        <table class="summary-table">
                            <thead>
                                <tr>
                                    <th>用户</th>
                                    <th>角色</th>
                                    <th>注册时间</th>
                                    <th>最后登录</th>
                                    <th>完成情况</th>
                                    <th>学习次数</th>
                                    <th>平均得分</th>
                                    <th>学习时长</th>
                                    <th>最后学习</th>
                                    <th>错题总数</th>
                                    <th>收藏总数</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($user_summary as $user): 
                                    $attempt_class = '';
                                    if ($user['total_attempts'] >= 20) {
                                        $attempt_class = 'attempt-high';
                                    } elseif ($user['total_attempts'] >= 10) {
                                        $attempt_class = 'attempt-medium';
                                    } else {
                                        $attempt_class = 'attempt-low';
                                    }
                                    
                                    // 计算课程完成率
                                    $completion_rate = 0;
                                    if ($course_filter != 'all' && $user['total_course_projects'] > 0) {
                                        $completion_rate = round(($user['course_completed_projects'] / $user['total_course_projects']) * 100, 1);
                                    }
                                    
                                    $completion_class = '';
                                    if ($completion_rate >= 80) {
                                        $completion_class = 'completion-high';
                                    } elseif ($completion_rate >= 50) {
                                        $completion_class = 'completion-medium';
                                    } else {
                                        $completion_class = 'completion-low';
                                    }
                                ?>
                                    <tr>
                                        <td>
                                            <strong><?php echo htmlspecialchars($user['username']); ?></strong>
                                            <br><small>ID: <?php echo $user['id']; ?></small>
                                        </td>
                                        <td>
                                            <span class="user-role role-<?php echo $user['role']; ?>">
                                                <?php echo $user['role'] == 'admin' ? '管理员' : '普通用户'; ?>
                                            </span>
                                        </td>
                                        <td>
                                            <?php echo date('Y-m-d', strtotime($user['register_time'])); ?>
                                        </td>
                                        <td>
                                            <?php echo $user['last_login'] ? date('Y-m-d H:i', strtotime($user['last_login'])) : '从未登录'; ?>
                                        </td>
                                        <td>
                                            <?php if ($course_filter == 'all'): ?>
                                                <div class="hierarchy-stats">
                                                    <span class="hierarchy-stat">📖 <?php echo $user['completed_courses']; ?> 课程</span>
                                                    <span class="hierarchy-stat">📚 <?php echo $user['completed_modules']; ?> 模块</span>
                                                    <span class="hierarchy-stat">🎯 <?php echo $user['completed_projects']; ?> 项目</span>
                                                </div>
                                            <?php else: ?>
                                                <div class="hierarchy-stats">
                                                    <span class="hierarchy-stat">🎯 <?php echo $user['course_completed_projects']; ?>/<?php echo $user['total_course_projects']; ?> 项目</span>
                                                    <?php if ($user['total_course_projects'] > 0): ?>
                                                        <span class="hierarchy-stat <?php echo $completion_class; ?>">
                                                            完成率: <?php echo $completion_rate; ?>%
                                                        </span>
                                                    <?php endif; ?>
                                                </div>
                                            <?php endif; ?>
                                            <?php if ($user['wrong_projects'] > 0): ?>
                                                <br><small style="color: var(--error-color);"><?php echo $user['wrong_projects']; ?> 项目有错题</small>
                                            <?php endif; ?>
                                            <?php if ($user['favorite_projects'] > 0): ?>
                                                <br><small style="color: #e74c3c;"><?php echo $user['favorite_projects']; ?> 项目有收藏</small>
                                            <?php endif; ?>
                                        </td>
                                        <td>
                                            <span class="attempt-badge <?php echo $attempt_class; ?>">
                                                <?php echo $user['total_attempts'] ?: '0'; ?> 次
                                            </span>
                                            <?php if ($user['completed_projects'] > 0 && $user['total_attempts'] > 0): ?>
                                                <div class="attempt-detail">
                                                    平均 <?php echo round($user['total_attempts'] / $user['completed_projects'], 1); ?> 次/项目
                                                </div>
                                            <?php endif; ?>
                                            <?php if ($user['history_count'] > 0): ?>
                                                <div class="history-count">
                                                    <?php echo $user['history_count']; ?> 条历史记录
                                                </div>
                                            <?php endif; ?>
                                        </td>
                                        <td>
                                            <?php echo $user['avg_score'] ? round($user['avg_score'], 1) : '0'; ?>分
                                        </td>
                                        <td>
                                            <?php echo formatStudyTime($user['total_study_time']); ?>
                                        </td>
                                        <td>
                                            <?php echo $user['last_study_time'] ? date('Y-m-d H:i', strtotime($user['last_study_time'])) : '未学习'; ?>
                                        </td>
                                        <td>
                                            <?php if ($user['total_wrong'] > 0): ?>
                                                <span style="color: var(--error-color);"><?php echo $user['total_wrong']; ?> 题</span>
                                            <?php else: ?>
                                                <span>0 题</span>
                                            <?php endif; ?>
                                        </td>
                                        <td>
                                            <?php if ($user['total_favorites'] > 0): ?>
                                                <span style="color: #e74c3c;"><?php echo $user['total_favorites']; ?> 题</span>
                                            <?php else: ?>
                                                <span>0 题</span>
                                            <?php endif; ?>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>

                    <!-- 分页信息 -->
                    <div style="margin-top: 20px; text-align: center; color: var(--text-secondary);">
                        共 <?php echo $total_users; ?> 个用户，总学习次数 <?php echo $total_attempts_all; ?> 次，
                        总学习时长 <?php echo formatStudyTime(array_sum(array_column($user_summary, 'total_study_time'))); ?>
                        <?php if ($course_filter != 'all' && isset($total_completed_projects) && isset($total_course_projects)): ?>
                            ，课程完成率 <?php echo $total_course_projects > 0 ? round(($total_completed_projects / $total_course_projects) * 100, 1) : '0'; ?>%
                        <?php endif; ?>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</body>
</html>