<?php
require_once '../config/database.php';

// 如果已经是管理员，直接跳转到后台
if (isset($_SESSION['user_id']) && isset($_SESSION['role']) && $_SESSION['role'] == 'admin') {
    header("Location: index.php");
    exit();
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $username = trim($_POST['username']);
    $password = $_POST['password'];
    
    // 查询管理员用户
    $stmt = $pdo->prepare("SELECT * FROM users WHERE username = ? AND role = 'admin'");
    $stmt->execute([$username]);
    $user = $stmt->fetch();
    
    if ($user && password_verify($password, $user['password'])) {
        // 登录成功，设置session
        $_SESSION['user_id'] = $user['id'];
        $_SESSION['username'] = $user['username'];
        $_SESSION['role'] = $user['role'];
        
        // 更新最后登录时间
        $update_stmt = $pdo->prepare("UPDATE users SET last_login = NOW() WHERE id = ?");
        $update_stmt->execute([$user['id']]);
        
        header("Location: index.php");
        exit();
    } else {
        $error = "管理员账号或密码错误！";
    }
}
?>

<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
    <title>管理员登录 - 在线刷题系统</title>
    <link rel="stylesheet" href="../config/style.css">
    <style>
        body { 
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 20px;
        }
        .login-card {
            background: white;
            padding: 40px;
            border-radius: 20px;
            box-shadow: 0 20px 40px rgba(0,0,0,0.1);
            width: 100%;
            max-width: 450px;
            position: relative;
            overflow: hidden;
        }
        .logo {
            text-align: center;
            margin-bottom: 30px;
        }
        .logo h1 {
            color: var(--primary-color);
            font-size: 28px;
            margin-bottom: 8px;
        }
        .logo p {
            color: var(--text-secondary);
            font-size: 16px;
        }
        .admin-notice {
            background: #fff3cd;
            border: 1px solid #ffeaa7;
            border-radius: 10px;
            padding: 15px;
            margin: 20px 0;
            font-size: 14px;
            line-height: 1.5;
        }
        .admin-icon {
            display: inline-block;
            width: 40px;
            height: 40px;
            background: var(--primary-color);
            color: white;
            border-radius: 50%;
            text-align: center;
            line-height: 40px;
            margin-right: 10px;
            font-size: 20px;
        }
        .form-group {
            margin-bottom: 20px;
        }
        .form-label {
            display: block;
            margin-bottom: 8px;
            font-weight: 600;
            color: var(--text-primary);
        }
        .form-input {
            width: 100%;
            padding: 12px 16px;
            border: 2px solid var(--border-color);
            border-radius: 10px;
            font-size: 16px;
            transition: all 0.3s;
            box-sizing: border-box;
        }
        .form-input:focus {
            border-color: var(--primary-color);
            box-shadow: 0 0 0 3px rgba(102, 126, 234, 0.1);
            outline: none;
        }
        .btn-primary {
            width: 100%;
            padding: 14px;
            background: var(--primary-color);
            color: white;
            border: none;
            border-radius: 10px;
            font-size: 16px;
            font-weight: 600;
            cursor: pointer;
            transition: background 0.3s;
        }
        .btn-primary:hover {
            background: var(--secondary-color);
        }
        .text-center {
            text-align: center;
        }
        .mt-3 {
            margin-top: 20px;
        }
        .login-links {
            display: flex;
            justify-content: center;
            gap: 15px;
            margin-top: 20px;
        }
        .login-links a {
            color: var(--primary-color);
            text-decoration: none;
            font-size: 14px;
            transition: color 0.3s;
        }
        .login-links a:hover {
            color: var(--secondary-color);
            text-decoration: underline;
        }
        .system-info {
            margin-top: 30px;
            padding-top: 20px;
            border-top: 1px solid var(--border-color);
            text-align: center;
            color: var(--text-secondary);
            font-size: 12px;
        }
        .decoration {
            position: absolute;
            top: -50px;
            right: -50px;
            width: 150px;
            height: 150px;
            background: linear-gradient(135deg, var(--primary-color), var(--secondary-color));
            border-radius: 50%;
            opacity: 0.1;
        }
        .decoration-2 {
            position: absolute;
            bottom: -30px;
            left: -30px;
            width: 100px;
            height: 100px;
            background: linear-gradient(135deg, var(--success-color), #10b981);
            border-radius: 50%;
            opacity: 0.1;
        }
        @media (max-width: 480px) {
            .login-card {
                padding: 30px 20px;
            }
            .logo h1 {
                font-size: 24px;
            }
        }
    </style>
</head>
<body>
    <div class="login-card">
        <div class="decoration"></div>
        <div class="decoration-2"></div>
        
        <div class="logo">

            <h1>⚙️ 管理员登录</h1>
            <p>在线刷题系统 - 管理后台</p>
        </div>
        
        <?php if (isset($error)): ?>
            <div class="alert alert-error">
                <?php echo $error; ?>
            </div>
        <?php endif; ?>


        <form method="post">
            <div class="form-group">
                <label for="username" class="form-label">管理员账号：</label>
                <input type="text" id="username" name="username" class="form-input" 
                       value="<?php echo isset($_POST['username']) ? htmlspecialchars($_POST['username']) : ''; ?>" 
                       placeholder="请输入管理员账号" required
                       autocomplete="username">
            </div>
            
            <div class="form-group">
                <label for="password" class="form-label">密码：</label>
                <input type="password" id="password" name="password" class="form-input" 
                       placeholder="请输入密码" required
                       autocomplete="current-password">
            </div>
            
            <button type="submit" class="btn btn-primary">登录管理后台</button>
        </form>
        
        <div class="login-links">
            <a href="../user/login.php">👤 用户登录</a>
            <a href="../index.php">🏠 返回首页</a>
        </div>

        <div class="system-info">
            <p>© <?php echo date('Y'); ?> 在线刷题系统 - 多课程刷题平台</p>
            <p>版本：2.0 (课程-模块-项目三级结构)</p>
        </div>
    </div>

    <script>
        // 简单的表单验证和用户体验增强
        document.addEventListener('DOMContentLoaded', function() {
            const loginForm = document.querySelector('form');
            const usernameInput = document.getElementById('username');
            const passwordInput = document.getElementById('password');
            
            // 自动聚焦到用户名输入框
            usernameInput.focus();
            
            // 表单提交前的简单验证
            loginForm.addEventListener('submit', function(e) {
                const username = usernameInput.value.trim();
                const password = passwordInput.value.trim();
                
                if (!username) {
                    alert('请输入管理员账号！');
                    usernameInput.focus();
                    e.preventDefault();
                    return;
                }
                
                if (!password) {
                    alert('请输入密码！');
                    passwordInput.focus();
                    e.preventDefault();
                    return;
                }
                
                // 可以添加更多验证逻辑，如密码长度等
                if (password.length < 6) {
                    alert('密码长度至少为6位！');
                    passwordInput.focus();
                    e.preventDefault();
                    return;
                }
            });
            
            // 回车键切换输入框
            usernameInput.addEventListener('keypress', function(e) {
                if (e.key === 'Enter') {
                    e.preventDefault();
                    passwordInput.focus();
                }
            });
            
            passwordInput.addEventListener('keypress', function(e) {
                if (e.key === 'Enter') {
                    e.preventDefault();
                    loginForm.submit();
                }
            });
            
            // 输入框获得焦点时的效果
            const inputs = document.querySelectorAll('.form-input');
            inputs.forEach(input => {
                input.addEventListener('focus', function() {
                    this.parentElement.classList.add('focused');
                });
                
                input.addEventListener('blur', function() {
                    this.parentElement.classList.remove('focused');
                });
            });
        });
    </script>
</body>
</html>