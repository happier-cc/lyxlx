<?php
require_once '../config/database.php';

if (!isset($_SESSION['user_id']) || $_SESSION['role'] != 'admin') {
    header("Location: login.php");
    exit();
}

$message = '';
$message_type = '';
$imported_count = 0;
$error_count = 0;

// 处理文件上传和导入
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_FILES['import_file'])) {
    $import_type = $_POST['import_type'] ?? 'append'; // append 或 replace
    
    if ($_FILES['import_file']['error'] !== UPLOAD_ERR_OK) {
        $message = "文件上传失败，错误代码：" . $_FILES['import_file']['error'];
        $message_type = 'error';
    } else {
        $file_path = $_FILES['import_file']['tmp_name'];
        $file_type = pathinfo($_FILES['import_file']['name'], PATHINFO_EXTENSION);
        
        // 检查文件类型
        if (!in_array(strtolower($file_type), ['csv', 'txt'])) {
            $message = "只支持 CSV 或 TXT 文件格式！";
            $message_type = 'error';
        } else {
            try {
                // 读取文件内容
                $file_content = file_get_contents($file_path);
                $file_content = mb_convert_encoding($file_content, 'UTF-8', 'auto');
                $lines = explode("\n", $file_content);
                
                $imported_count = 0;
                $error_count = 0;
                $error_details = [];
                
                // 用于统计的项目信息
                $imported_projects = [];
                
                foreach ($lines as $line_num => $line) {
                    $line = trim($line);
                    if (empty($line) || $line_num == 0) continue; // 跳过空行和标题行
                    
                    // 解析CSV行
                    $data = str_getcsv($line);
                    if (count($data) < 10) {
                        $error_count++;
                        $error_details[] = "第 " . ($line_num + 1) . " 行：数据列数不足，需要10列";
                        continue;
                    }
                    
                    // 解析数据 - 新的格式包含课程、模块、项目信息
                    $course_id = trim($data[0] ?? '');
                    $module_id = trim($data[1] ?? '');
                    $project_id = trim($data[2] ?? '');
                    $question_text = trim($data[3] ?? '');
                    $option_a = trim($data[4] ?? '');
                    $option_b = trim($data[5] ?? '');
                    $option_c = trim($data[6] ?? '');
                    $option_d = trim($data[7] ?? '');
                    $correct_answer = strtoupper(trim($data[8] ?? ''));
                    $explanation = trim($data[9] ?? '');
                    
                    // 验证数据
                    if (empty($course_id) || empty($module_id) || empty($project_id)) {
                        $error_count++;
                        $error_details[] = "第 " . ($line_num + 1) . " 行：课程ID、模块ID或项目ID不能为空";
                        continue;
                    }
                    
                    if (empty($question_text) || empty($option_a) || empty($option_b) || empty($correct_answer)) {
                        $error_count++;
                        $error_details[] = "第 " . ($line_num + 1) . " 行：题目内容、选项A、选项B或正确答案不能为空";
                        continue;
                    }
                    
                    if (!in_array($correct_answer, ['A', 'B', 'C', 'D'])) {
                        $error_count++;
                        $error_details[] = "第 " . ($line_num + 1) . " 行：正确答案必须是 A、B、C 或 D";
                        continue;
                    }
                    
                    // 验证项目是否存在
                    try {
                        $stmt = $pdo->prepare("
                            SELECT p.id 
                            FROM projects p 
                            JOIN modules m ON p.module_id = m.id 
                            JOIN courses c ON m.course_id = c.id 
                            WHERE p.id = ? AND m.id = ? AND c.id = ?
                        ");
                        $stmt->execute([$project_id, $module_id, $course_id]);
                        $project_exists = $stmt->fetch();
                        
                        if (!$project_exists) {
                            $error_count++;
                            $error_details[] = "第 " . ($line_num + 1) . " 行：指定的项目不存在（课程ID: {$course_id}, 模块ID: {$module_id}, 项目ID: {$project_id}）";
                            continue;
                        }
                        
                        // 记录导入的项目
                        if (!in_array($project_id, $imported_projects)) {
                            $imported_projects[] = $project_id;
                        }
                        
                    } catch (PDOException $e) {
                        $error_count++;
                        $error_details[] = "第 " . ($line_num + 1) . " 行：验证项目失败 - " . $e->getMessage();
                        continue;
                    }
                    
                    // 如果是替换模式，且这是该项目的第一个题目，先删除该项目的所有题目
                    if ($import_type == 'replace' && !isset($processed_projects[$project_id])) {
                        $delete_stmt = $pdo->prepare("DELETE FROM questions WHERE project_id = ?");
                        $delete_stmt->execute([$project_id]);
                        $processed_projects[$project_id] = true;
                    }
                    
                    // 检查题目是否已存在（防止重复导入）- 修改为题干和所有选项都相同才视为重复
                    $check_stmt = $pdo->prepare("
                        SELECT id FROM questions 
                        WHERE project_id = ? 
                        AND question_text = ? 
                        AND option_a = ? 
                        AND option_b = ? 
                        AND option_c = ? 
                        AND option_d = ? 
                        LIMIT 1
                    ");
                    $check_stmt->execute([
                        $project_id, 
                        $question_text, 
                        $option_a, 
                        $option_b, 
                        $option_c, 
                        $option_d
                    ]);
                    $existing_question = $check_stmt->fetch();
                    
                    if ($existing_question) {
                        // 如果题目已存在，根据导入模式决定是否更新
                        if ($import_type == 'replace') {
                            // 在替换模式下，更新现有题目
                            $update_stmt = $pdo->prepare("
                                UPDATE questions 
                                SET option_a = ?, option_b = ?, option_c = ?, option_d = ?, 
                                    correct_answer = ?, explanation = ?
                                WHERE id = ?
                            ");
                            $update_stmt->execute([
                                $option_a, $option_b, $option_c, $option_d, 
                                $correct_answer, $explanation, $existing_question['id']
                            ]);
                            $imported_count++;
                        } else {
                            // 在追加模式下，跳过重复题目
                            $error_count++;
                            $error_details[] = "第 " . ($line_num + 1) . " 行：题目已存在，已跳过";
                        }
                    } else {
                        // 插入新题目
                        try {
                            $stmt = $pdo->prepare("
                                INSERT INTO questions (project_id, question_text, option_a, option_b, option_c, option_d, correct_answer, explanation) 
                                VALUES (?, ?, ?, ?, ?, ?, ?, ?)
                            ");
                            $stmt->execute([
                                $project_id, 
                                $question_text, 
                                $option_a, 
                                $option_b, 
                                $option_c, 
                                $option_d, 
                                $correct_answer, 
                                $explanation
                            ]);
                            $imported_count++;
                        } catch (PDOException $e) {
                            $error_count++;
                            $error_details[] = "第 " . ($line_num + 1) . " 行：数据库插入失败 - " . $e->getMessage();
                        }
                    }
                }
                
                if ($imported_count > 0) {
                    $message = "成功导入 {$imported_count} 道题目";
                    if (!empty($imported_projects)) {
                        $message .= "（覆盖 " . count($imported_projects) . " 个项目）";
                    }
                    $message_type = 'success';
                    
                    if ($error_count > 0) {
                        $message .= "，但有 {$error_count} 个错误";
                        $message_type = 'warning';
                    }
                } else {
                    $message = "没有成功导入任何题目";
                    $message_type = 'error';
                    if ($error_count > 0) {
                        $message .= "，共发现 {$error_count} 个错误";
                    }
                }
                
                // 显示详细错误信息
                if (!empty($error_details)) {
                    $message .= "<br><br><strong>错误详情：</strong><br>" . implode("<br>", array_slice($error_details, 0, 10));
                    if (count($error_details) > 10) {
                        $message .= "<br>... 还有 " . (count($error_details) - 10) . " 个错误";
                    }
                }
                
            } catch (Exception $e) {
                $message = "导入过程中发生错误：" . $e->getMessage();
                $message_type = 'error';
            }
        }
    }
}

// 获取所有课程、模块、项目信息（用于参考）
$courses_info = $pdo->query("SELECT id, course_name FROM courses ORDER BY id")->fetchAll();
$modules_info = $pdo->query("SELECT id, module_name, course_id FROM modules ORDER BY course_id, id")->fetchAll();
$projects_info = $pdo->query("
    SELECT p.id, p.project_name, m.id as module_id, m.module_name, c.id as course_id, c.course_name 
    FROM projects p 
    JOIN modules m ON p.module_id = m.id 
    JOIN courses c ON m.course_id = c.id 
    ORDER BY c.id, m.id, p.id
")->fetchAll();

// 处理模板下载
if (isset($_GET['download_template'])) {
    header('Content-Type: text/csv; charset=utf-8');
    header('Content-Disposition: attachment; filename="questions_import_template_with_hierarchy.csv"');
    
    $output = fopen('php://output', 'w');
    
    // 写入标题行 - 新的格式包含层级信息
    fputcsv($output, ['课程ID', '模块ID', '项目ID', '题目内容', '选项A', '选项B', '选项C', '选项D', '正确答案', '题目解析']);
    
    // 写入示例数据
    if (!empty($projects_info)) {
        $sample_project = $projects_info[0];
        fputcsv($output, [
            $sample_project['course_id'],
            $sample_project['module_id'],
            $sample_project['id'],
            '以下哪个是编程语言？',
            'Java',
            'HTML',
            'CSS',
            'JSON',
            'A',
            'HTML是标记语言，不是编程语言'
        ]);
        
        if (count($projects_info) > 1) {
            $sample_project2 = $projects_info[1];
            fputcsv($output, [
                $sample_project2['course_id'],
                $sample_project2['module_id'],
                $sample_project2['id'],
                'Python是什么类型的语言？',
                '编译型',
                '解释型',
                '汇编语言',
                '机器语言',
                'B',
                'Python是解释型语言'
            ]);
        }
    }
    
    fclose($output);
    exit;
}
?>

<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
    <title>批量导入题目 - 在线刷题系统</title>
    <link rel="stylesheet" href="../config/style.css">
    <style>
        .import-container {
            max-width: 1200px;
            margin: 50px auto;
            padding: 30px;
        }
        
        .import-card {
            background: white;
            padding: 30px;
            border-radius: 12px;
            box-shadow: var(--shadow);
            margin-bottom: 24px;
        }
        
        .file-upload-area {
            border: 2px dashed var(--border-color);
            border-radius: 12px;
            padding: 40px 20px;
            text-align: center;
            margin: 20px 0;
            transition: border-color 0.3s;
        }
        
        .file-upload-area:hover {
            border-color: var(--primary-color);
        }
        
        .file-upload-area.dragover {
            border-color: var(--primary-color);
            background: var(--bg-tertiary);
        }
        
        .file-input {
            display: none;
        }
        
        .file-label {
            display: inline-block;
            padding: 12px 24px;
            background: var(--primary-color);
            color: white;
            border-radius: 6px;
            cursor: pointer;
            transition: background 0.3s;
        }
        
        .file-label:hover {
            background: var(--secondary-color);
        }
        
        .file-info {
            margin-top: 16px;
            font-size: 14px;
            color: var(--text-secondary);
        }
        
        .import-options {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 20px;
            margin: 24px 0;
        }
        
        .option-card {
            background: var(--bg-tertiary);
            padding: 20px;
            border-radius: 8px;
            border-left: 4px solid var(--primary-color);
            cursor: pointer;
            transition: all 0.3s;
        }
        
        .option-card:hover {
            background: var(--bg-secondary);
        }
        
        .option-card.selected {
            background: var(--primary-color);
            color: white;
        }
        
        .format-guide {
            background: #f8f9fa;
            border: 1px solid var(--border-color);
            border-radius: 8px;
            padding: 20px;
            margin: 24px 0;
        }
        
        .format-table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 12px;
        }
        
        .format-table th,
        .format-table td {
            padding: 8px 12px;
            border: 1px solid var(--border-color);
            text-align: left;
        }
        
        .format-table th {
            background: var(--bg-primary);
            font-weight: 600;
        }
        
        .hierarchy-info {
            background: #e7f3ff;
            border: 2px solid #b3d9ff;
            border-radius: 8px;
            padding: 20px;
            margin: 20px 0;
        }
        
        .info-table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 12px;
        }
        
        .info-table th,
        .info-table td {
            padding: 8px 12px;
            border: 1px solid #b3d9ff;
            text-align: left;
        }
        
        .info-table th {
            background: #d1ecf1;
            font-weight: 600;
        }
        
        .template-section {
            background: #e7f3ff;
            border: 2px solid #b3d9ff;
            border-radius: 8px;
            padding: 20px;
            margin: 20px 0;
            text-align: center;
        }
        
        @media (max-width: 768px) {
            .import-options {
                grid-template-columns: 1fr;
            }
            
            .import-container {
                padding: 15px;
            }
        }
    </style>
</head>
<body>
    <nav class="navbar">
        <div class="container">
            <div class="nav-content">
                <a href="index.php" class="nav-brand">← 返回后台</a>
                <span class="nav-brand">批量导入题目</span>
            </div>
        </div>
    </nav>

    <div class="container">
        <div class="import-container">
            <div class="import-card">
                <h1>批量导入题目</h1>
                <p>通过CSV文件批量导入题目到指定项目（支持多项目混合导入）</p>
                
                <?php if ($message): ?>
                    <div class="alert alert-<?php echo $message_type; ?>">
                        <?php echo $message; ?>
                    </div>
                <?php endif; ?>

                <!-- 模板下载区域 -->
                <div class="template-section">
                    <h3>📥 下载导入模板</h3>
                    <p>下载包含课程-模块-项目层级信息的CSV模板文件</p>
                    <a href="?download_template=1" class="btn btn-primary">
                        📋 下载CSV模板文件（含层级信息）
                    </a>
                    <p class="text-muted mt-2">模板已包含当前系统中的课程、模块、项目ID参考</p>
                </div>

                <form method="post" enctype="multipart/form-data" id="importForm">
                    <div class="form-group">
                        <label class="form-label">导入模式：</label>
                        <div class="import-options">
                            <label class="option-card">
                                <input type="radio" name="import_type" value="append" checked>
                                <div style="font-weight: 600; margin-bottom: 8px;">追加模式</div>
                                <div style="font-size: 14px; color: var(--text-secondary);">
                                    在现有题目基础上添加新题目，跳过重复题目
                                </div>
                            </label>
                            <label class="option-card">
                                <input type="radio" name="import_type" value="replace">
                                <div style="font-weight: 600; margin-bottom: 8px;">替换模式</div>
                                <div style="font-size: 14px; color: var(--text-secondary);">
                                    删除指定项目的所有现有题目，导入新题目
                                </div>
                            </label>
                        </div>
                    </div>
                    
                    <div class="form-group">
                        <label class="form-label">选择文件：</label>
                        <div class="file-upload-area" id="fileUploadArea">
                            <input type="file" id="import_file" name="import_file" class="file-input" accept=".csv,.txt" required>
                            <label for="import_file" class="file-label">
                                📁 选择CSV文件
                            </label>
                            <div class="file-info" id="fileInfo">
                                支持 CSV 格式，文件大小不超过 2MB
                            </div>
                        </div>
                    </div>
                    
                    <div class="form-group">
                        <button type="submit" class="btn btn-primary btn-full">开始导入</button>
                    </div>
                </form>
            </div>

            <!-- 层级信息参考 -->
            <div class="import-card">
                <h3>📚 课程-模块-项目层级参考</h3>
                <div class="hierarchy-info">
                    <p>请在导入文件中使用以下ID来指定题目所属的层级：</p>
                    
                    <h4>课程列表：</h4>
                    <table class="info-table">
                        <thead>
                            <tr>
                                <th width="80">课程ID</th>
                                <th>课程名称</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($courses_info as $course): ?>
                                <tr>
                                    <td><strong><?php echo $course['id']; ?></strong></td>
                                    <td><?php echo htmlspecialchars($course['course_name']); ?></td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                    
                    <h4 style="margin-top: 20px;">模块列表：</h4>
                    <table class="info-table">
                        <thead>
                            <tr>
                                <th width="80">模块ID</th>
                                <th>模块名称</th>
                                <th width="80">所属课程ID</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($modules_info as $module): ?>
                                <tr>
                                    <td><strong><?php echo $module['id']; ?></strong></td>
                                    <td><?php echo htmlspecialchars($module['module_name']); ?></td>
                                    <td><strong><?php echo $module['course_id']; ?></strong></td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                    
                    <h4 style="margin-top: 20px;">项目列表：</h4>
                    <table class="info-table">
                        <thead>
                            <tr>
                                <th width="80">项目ID</th>
                                <th>项目名称</th>
                                <th width="80">所属模块ID</th>
                                <th width="80">所属课程ID</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($projects_info as $project): ?>
                                <tr>
                                    <td><strong><?php echo $project['id']; ?></strong></td>
                                    <td><?php echo htmlspecialchars($project['project_name']); ?></td>
                                    <td><strong><?php echo $project['module_id']; ?></strong></td>
                                    <td><strong><?php echo $project['course_id']; ?></strong></td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>

            <div class="import-card">
                <h3>文件格式说明</h3>
                <div class="format-guide">
                    <p>请使用以下格式的CSV文件（<strong>包含课程-模块-项目层级信息</strong>）：</p>
                    
                    <table class="format-table">
                        <thead>
                            <tr>
                                <th width="100">字段</th>
                                <th>说明</th>
                                <th width="80">必填</th>
                                <th>示例</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <td>课程ID</td>
                                <td>题目所属课程的ID</td>
                                <td>是</td>
                                <td>1</td>
                            </tr>
                            <tr>
                                <td>模块ID</td>
                                <td>题目所属模块的ID</td>
                                <td>是</td>
                                <td>3</td>
                            </tr>
                            <tr>
                                <td>项目ID</td>
                                <td>题目所属项目的ID</td>
                                <td>是</td>
                                <td>5</td>
                            </tr>
                            <tr>
                                <td>题目内容</td>
                                <td>题目的正文内容</td>
                                <td>是</td>
                                <td>以下哪个是编程语言？</td>
                            </tr>
                            <tr>
                                <td>选项A</td>
                                <td>第一个选项内容</td>
                                <td>是</td>
                                <td>Java</td>
                            </tr>
                            <tr>
                                <td>选项B</td>
                                <td>第二个选项内容</td>
                                <td>是</td>
                                <td>HTML</td>
                            </tr>
                            <tr>
                                <td>选项C</td>
                                <td>第三个选项内容（可选）</td>
                                <td>否</td>
                                <td>CSS</td>
                            </tr>
                            <tr>
                                <td>选项D</td>
                                <td>第四个选项内容（可选）</td>
                                <td>否</td>
                                <td>JSON</td>
                            </tr>
                            <tr>
                                <td>正确答案</td>
                                <td>正确选项（A、B、C、D）</td>
                                <td>是</td>
                                <td>A</td>
                            </tr>
                            <tr>
                                <td>题目解析</td>
                                <td>题目的解析说明（可选）</td>
                                <td>否</td>
                                <td>HTML是标记语言，不是编程语言</td>
                            </tr>
                        </tbody>
                    </table>
                    
                    <div style="margin-top: 16px;">
                        <strong>CSV文件示例：</strong>
                        <pre style="background: #f8f9fa; padding: 12px; border-radius: 6px; font-size: 13px; margin-top: 8px;">
1,3,5,"以下哪个是编程语言？","Java","HTML","CSS","JSON","A","HTML是标记语言，不是编程语言"
1,3,6,"Python是什么类型的语言？","编译型","解释型","汇编语言","机器语言","B","Python是解释型语言"
2,4,8,"HTTP是什么的缩写？","超文本传输协议","文件传输协议","简单邮件传输协议","域名系统","A","HTTP是HyperText Transfer Protocol的缩写"
                        </pre>
                    </div>
                    
                    <div style="margin-top: 16px;">
                        <strong>注意事项：</strong>
                        <ul style="color: var(--text-secondary); margin-top: 8px;">
                            <li>文件编码请使用 UTF-8</li>
                            <li>CSV文件请使用逗号分隔，文本包含逗号时请用双引号包围</li>
                            <li>请确保课程ID、模块ID、项目ID的对应关系正确</li>
                            <li>选项C和选项D可以为空，但A和B必须填写</li>
                            <li>正确答案必须是 A、B、C、D 中的一个</li>
                            <li>建议先下载模板文件，按照模板格式填写</li>
                        </ul>
                    </div>
                </div>
                
                <div class="text-center mt-4">
                    <a href="manage_questions.php" class="btn btn-outline">❓ 管理题目</a>
                    <a href="manage_projects.php" class="btn btn-outline">📁 项目管理</a>
                    <a href="manage_courses.php" class="btn btn-outline">📖 课程管理</a>
                </div>
            </div>
        </div>
    </div>

    <script>
        // 文件上传区域交互效果
        const fileUploadArea = document.getElementById('fileUploadArea');
        const fileInput = document.getElementById('import_file');
        const fileInfo = document.getElementById('fileInfo');
        
        fileUploadArea.addEventListener('dragover', function(e) {
            e.preventDefault();
            this.classList.add('dragover');
        });
        
        fileUploadArea.addEventListener('dragleave', function(e) {
            e.preventDefault();
            this.classList.remove('dragover');
        });
        
        fileUploadArea.addEventListener('drop', function(e) {
            e.preventDefault();
            this.classList.remove('dragover');
            const files = e.dataTransfer.files;
            if (files.length > 0) {
                fileInput.files = files;
                updateFileInfo(files[0]);
            }
        });
        
        fileInput.addEventListener('change', function(e) {
            if (this.files.length > 0) {
                updateFileInfo(this.files[0]);
            }
        });
        
        function updateFileInfo(file) {
            const fileSize = (file.size / 1024 / 1024).toFixed(2);
            fileInfo.innerHTML = `
                <strong>已选择文件：</strong> ${file.name}<br>
                <strong>文件大小：</strong> ${fileSize} MB<br>
                <strong>文件类型：</strong> ${file.type || '未知'}
            `;
        }
        
        // 表单提交验证
        document.querySelector('form').addEventListener('submit', function(e) {
            const file = document.getElementById('import_file').files[0];
            
            if (!file) {
                alert('请选择要导入的文件！');
                e.preventDefault();
                return;
            }
            
            // 检查文件大小（2MB限制）
            if (file.size > 2 * 1024 * 1024) {
                alert('文件大小不能超过 2MB！');
                e.preventDefault();
                return;
            }
            
            // 检查文件类型
            const fileExtension = file.name.split('.').pop().toLowerCase();
            if (!['csv', 'txt'].includes(fileExtension)) {
                alert('只支持 CSV 或 TXT 文件格式！');
                e.preventDefault();
                return;
            }
        });

        // 导入模式选择
        const optionCards = document.querySelectorAll('.option-card');
        optionCards.forEach(card => {
            card.addEventListener('click', function() {
                const radio = this.querySelector('input[type="radio"]');
                radio.checked = true;
                
                optionCards.forEach(c => c.classList.remove('selected'));
                this.classList.add('selected');
            });
        });
    </script>
</body>
</html>