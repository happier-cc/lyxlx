<?php
require_once '../config/database.php';

if (!isset($_SESSION['user_id']) || $_SESSION['role'] != 'admin') {
    header("Location: login.php");
    exit();
}

$selected_course = $_GET['course_id'] ?? 'all';

// 添加模块
if (isset($_POST['add_module'])) {
    $course_id = $_POST['course_id'];
    $module_name = trim($_POST['module_name']);
    $description = trim($_POST['description']);
    
    if (!empty($module_name) && !empty($course_id)) {
        $stmt = $pdo->prepare("INSERT INTO modules (course_id, module_name, description) VALUES (?, ?, ?)");
        $stmt->execute([$course_id, $module_name, $description]);
        $success = "模块添加成功！";
    } else {
        $error = "模块名称和所属课程不能为空！";
    }
}

// 编辑模块
if (isset($_POST['edit_module'])) {
    $module_id = $_POST['module_id'];
    $course_id = $_POST['course_id'];
    $module_name = trim($_POST['module_name']);
    $description = trim($_POST['description']);
    
    if (!empty($module_name) && !empty($course_id)) {
        $stmt = $pdo->prepare("UPDATE modules SET course_id = ?, module_name = ?, description = ? WHERE id = ?");
        $stmt->execute([$course_id, $module_name, $description, $module_id]);
        $success = "模块更新成功！";
    } else {
        $error = "模块名称和所属课程不能为空！";
    }
}

// 删除模块
if (isset($_GET['delete'])) {
    $module_id = $_GET['delete'];
    
    // 检查是否有项目关联
    $check_stmt = $pdo->prepare("SELECT COUNT(*) FROM projects WHERE module_id = ?");
    $check_stmt->execute([$module_id]);
    $project_count = $check_stmt->fetchColumn();
    
    if ($project_count > 0) {
        $error = "无法删除该模块，因为有关联的项目存在！";
    } else {
        $stmt = $pdo->prepare("DELETE FROM modules WHERE id = ?");
        $stmt->execute([$module_id]);
        $success = "模块删除成功！";
    }
}

// 获取所有课程
$courses = $pdo->query("SELECT * FROM courses ORDER BY course_name")->fetchAll();

// 获取模块
if ($selected_course == 'all') {
    $modules = $pdo->query("
        SELECT m.*, c.course_name 
        FROM modules m 
        JOIN courses c ON m.course_id = c.id 
        ORDER BY c.course_name, m.module_name
    ")->fetchAll();
} else {
    $modules_stmt = $pdo->prepare("
        SELECT m.*, c.course_name 
        FROM modules m 
        JOIN courses c ON m.course_id = c.id 
        WHERE m.course_id = ? 
        ORDER BY m.module_name
    ");
    $modules_stmt->execute([$selected_course]);
    $modules = $modules_stmt->fetchAll();
}

// 获取编辑的模块信息
$editing_module = null;
if (isset($_GET['edit'])) {
    $edit_id = $_GET['edit'];
    $stmt = $pdo->prepare("SELECT * FROM modules WHERE id = ?");
    $stmt->execute([$edit_id]);
    $editing_module = $stmt->fetch();
}
?>

<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
    <title>模块管理 - 在线刷题系统</title>
    <link rel="stylesheet" href="../config/style.css">
    <style>
        .filter-section {
            margin-bottom: 24px;
        }
        
        .form-section {
            margin-bottom: 32px;
        }
        
        .modules-grid {
            display: grid;
            gap: 16px;
        }
        
        .module-card {
            background: white;
            padding: 20px;
            border-radius: 12px;
            box-shadow: var(--shadow);
            border-left: 4px solid var(--primary-color);
        }
        
        .module-header {
            display: flex;
            justify-content: space-between;
            align-items: flex-start;
            margin-bottom: 12px;
        }
        
        .module-title {
            font-size: 18px;
            font-weight: 600;
            color: var(--text-primary);
        }
        
        .module-actions {
            display: flex;
            gap: 8px;
            flex-wrap: wrap;
        }
        
        .module-stats {
            display: flex;
            gap: 16px;
            margin-top: 12px;
            font-size: 14px;
            color: var(--text-secondary);
        }
        
        .stat-item {
            display: flex;
            align-items: center;
            gap: 4px;
        }
        
        .course-badge {
            background: var(--bg-tertiary);
            padding: 4px 8px;
            border-radius: 6px;
            font-size: 12px;
            margin-bottom: 8px;
            display: inline-block;
        }
        
        @media (max-width: 640px) {
            .module-header {
                flex-direction: column;
                gap: 12px;
            }
            
            .module-actions {
                width: 100%;
                justify-content: flex-start;
            }
        }
    </style>
</head>
<body>
    <nav class="navbar">
        <div class="container">
            <div class="nav-content">
                <a href="index.php" class="nav-brand">← 返回后台</a>
                <span class="nav-brand">模块管理</span>
            </div>
        </div>
    </nav>

    <div class="container">
        <?php if (isset($success)): ?>
            <div class="alert alert-success"><?php echo $success; ?></div>
        <?php endif; ?>
        
        <?php if (isset($error)): ?>
            <div class="alert alert-error"><?php echo $error; ?></div>
        <?php endif; ?>

        <div class="filter-section">
            <div class="card">
                <h3>筛选模块</h3>
                <form method="get">
                    <select name="course_id" class="form-input form-select" onchange="this.form.submit()">
                        <option value="all" <?php echo $selected_course == 'all' ? 'selected' : ''; ?>>所有课程</option>
                        <?php foreach ($courses as $course): ?>
                            <option value="<?php echo $course['id']; ?>" <?php echo $selected_course == $course['id'] ? 'selected' : ''; ?>>
                                <?php echo htmlspecialchars($course['course_name']); ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </form>
                <div class="mt-2">
                    <a href="manage_courses.php" class="btn btn-outline btn-sm">📖 管理课程</a>
                </div>
            </div>
        </div>

        <div class="form-section">
            <div class="card">
                <h2><?php echo $editing_module ? '编辑模块' : '添加新模块'; ?></h2>
                <form method="post">
                    <?php if ($editing_module): ?>
                        <input type="hidden" name="module_id" value="<?php echo $editing_module['id']; ?>">
                    <?php endif; ?>
                    
                    <div class="form-group">
                        <label for="course_id" class="form-label">所属课程：</label>
                        <select id="course_id" name="course_id" class="form-input form-select" required>
                            <option value="">选择课程</option>
                            <?php foreach ($courses as $course): ?>
                                <option value="<?php echo $course['id']; ?>" 
                                    <?php echo ($editing_module['course_id'] ?? '') == $course['id'] ? 'selected' : ''; ?>>
                                    <?php echo htmlspecialchars($course['course_name']); ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    
                    <div class="form-group">
                        <label for="module_name" class="form-label">模块名称：</label>
                        <input type="text" id="module_name" name="module_name" class="form-input" 
                               value="<?php echo $editing_module ? htmlspecialchars($editing_module['module_name']) : ''; ?>" 
                               placeholder="请输入模块名称" required>
                    </div>
                    
                    <div class="form-group">
                        <label for="description" class="form-label">模块描述：</label>
                        <textarea id="description" name="description" class="form-input form-textarea" 
                                  placeholder="请输入模块描述（可选）"><?php echo $editing_module ? htmlspecialchars($editing_module['description']) : ''; ?></textarea>
                    </div>
                    
                    <div class="form-group">
                        <?php if ($editing_module): ?>
                            <button type="submit" name="edit_module" class="btn btn-primary">更新模块</button>
                            <a href="manage_modules.php?course_id=<?php echo $selected_course; ?>" class="btn btn-outline">取消编辑</a>
                        <?php else: ?>
                            <button type="submit" name="add_module" class="btn btn-primary">添加模块</button>
                        <?php endif; ?>
                    </div>
                </form>
            </div>
        </div>

        <div class="card">
            <h2>模块列表 (<?php echo count($modules); ?> 个)</h2>
            
            <?php if (empty($modules)): ?>
                <div class="text-center" style="padding: 40px; color: var(--text-secondary);">
                    <p>暂无模块</p>
                    <a href="manage_modules.php?action=add" class="btn btn-primary mt-2">添加第一个模块</a>
                </div>
            <?php else: ?>
                <div class="modules-grid">
                    <?php foreach ($modules as $module): 
                        // 获取该模块的项目数量
                        $project_count_stmt = $pdo->prepare("SELECT COUNT(*) FROM projects WHERE module_id = ?");
                        $project_count_stmt->execute([$module['id']]);
                        $project_count = $project_count_stmt->fetchColumn();
                        
                        // 获取题目数量
                        $question_count_stmt = $pdo->prepare("
                            SELECT COUNT(*) FROM questions q 
                            JOIN projects p ON q.project_id = p.id 
                            WHERE p.module_id = ?
                        ");
                        $question_count_stmt->execute([$module['id']]);
                        $question_count = $question_count_stmt->fetchColumn();
                    ?>
                        <div class="module-card">
                            <div class="course-badge">
                                📖 <?php echo htmlspecialchars($module['course_name']); ?>
                            </div>
                            
                            <div class="module-header">
                                <div class="module-title"><?php echo htmlspecialchars($module['module_name']); ?></div>
                                <div class="module-actions">
                                    <a href="manage_projects.php?module_id=<?php echo $module['id']; ?>" class="btn btn-primary btn-sm">管理项目</a>
                                    <a href="manage_modules.php?course_id=<?php echo $selected_course; ?>&edit=<?php echo $module['id']; ?>" class="btn btn-outline btn-sm">编辑</a>
                                    <a href="manage_modules.php?course_id=<?php echo $selected_course; ?>&delete=<?php echo $module['id']; ?>" 
                                       class="btn btn-error btn-sm"
                                       onclick="return confirm('确定要删除这个模块吗？')">删除</a>
                                </div>
                            </div>
                            
                            <?php if ($module['description']): ?>
                                <p style="color: var(--text-secondary); margin-bottom: 12px;">
                                    <?php echo htmlspecialchars($module['description']); ?>
                                </p>
                            <?php endif; ?>
                            
                            <div class="module-stats">
                                <div class="stat-item">
                                    <span>🎯</span>
                                    <span><?php echo $project_count; ?> 个项目</span>
                                </div>
                                <div class="stat-item">
                                    <span>❓</span>
                                    <span><?php echo $question_count; ?> 道题目</span>
                                </div>
                                <div class="stat-item">
                                    <span>📅</span>
                                    <span><?php echo date('Y-m-d', strtotime($module['created_at'])); ?></span>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>
            <?php endif; ?>
        </div>
    </div>
</body>
</html>