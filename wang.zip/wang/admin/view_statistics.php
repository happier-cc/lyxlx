<?php
require_once '../config/database.php';

if (!isset($_SESSION['user_id']) || $_SESSION['role'] != 'admin') {
    header("Location: login.php");
    exit();
}

// 获取基础统计信息
$total_users = $pdo->query("SELECT COUNT(*) FROM users")->fetchColumn();
$total_courses = $pdo->query("SELECT COUNT(*) FROM courses")->fetchColumn();
$total_modules = $pdo->query("SELECT COUNT(*) FROM modules")->fetchColumn();
$total_projects = $pdo->query("SELECT COUNT(*) FROM projects")->fetchColumn();
$total_questions = $pdo->query("SELECT COUNT(*) FROM questions")->fetchColumn();
$total_wrong = $pdo->query("SELECT COUNT(*) FROM wrong_questions")->fetchColumn();
$total_progress = $pdo->query("SELECT COUNT(*) FROM user_progress WHERE completed = TRUE")->fetchColumn();

// 获取今日数据
$today_users = $pdo->query("SELECT COUNT(*) FROM users WHERE DATE(created_at) = CURDATE()")->fetchColumn();
$today_progress = $pdo->query("SELECT COUNT(*) FROM user_progress WHERE DATE(completed_at) = CURDATE()")->fetchColumn();

// 获取项目学习情况
$project_stats = $pdo->query("
    SELECT p.id, p.project_name, m.module_name, c.course_name,
           COUNT(DISTINCT up.user_id) as completed_users, 
           AVG(up.score) as avg_score, 
           COUNT(DISTINCT wq.id) as wrong_count,
           (SELECT COUNT(*) FROM questions q WHERE q.project_id = p.id) as question_count
    FROM projects p 
    JOIN modules m ON p.module_id = m.id
    JOIN courses c ON m.course_id = c.id
    LEFT JOIN user_progress up ON p.id = up.project_id AND up.completed = TRUE
    LEFT JOIN wrong_questions wq ON p.id = wq.project_id
    GROUP BY p.id 
    ORDER BY c.course_name, m.module_name, p.project_name
")->fetchAll();

// 获取用户活跃度
$active_users = $pdo->query("
    SELECT u.username, 
           COUNT(DISTINCT up.project_id) as completed_projects, 
           COUNT(DISTINCT wq.id) as wrong_count, 
           AVG(up.score) as avg_score,
           MAX(up.completed_at) as last_activity
    FROM users u 
    LEFT JOIN user_progress up ON u.id = up.user_id AND up.completed = TRUE
    LEFT JOIN wrong_questions wq ON u.id = wq.user_id
    GROUP BY u.id 
    ORDER BY last_activity DESC, completed_projects DESC
    LIMIT 10
")->fetchAll();

// 获取学习趋势（最近7天）
$trend_data = $pdo->query("
    SELECT DATE(completed_at) as date, COUNT(*) as count
    FROM user_progress 
    WHERE completed = TRUE AND completed_at >= DATE_SUB(CURDATE(), INTERVAL 7 DAY)
    GROUP BY DATE(completed_at)
    ORDER BY date
")->fetchAll();

// 格式化趋势数据
$trend_labels = [];
$trend_values = [];
foreach ($trend_data as $trend) {
    $trend_labels[] = date('m-d', strtotime($trend['date']));
    $trend_values[] = $trend['count'];
}

// 如果没有数据，设置默认值
if (empty($trend_values)) {
    $trend_labels = ['暂无数据'];
    $trend_values = [0];
}

// 获取课程统计
$course_stats = $pdo->query("
    SELECT c.id, c.course_name,
           COUNT(DISTINCT m.id) as module_count,
           COUNT(DISTINCT p.id) as project_count,
           COUNT(DISTINCT up.user_id) as completed_users,
           AVG(up.score) as avg_score
    FROM courses c
    LEFT JOIN modules m ON c.id = m.course_id
    LEFT JOIN projects p ON m.id = p.module_id
    LEFT JOIN user_progress up ON p.id = up.project_id AND up.completed = TRUE
    GROUP BY c.id
    ORDER BY completed_users DESC
")->fetchAll();
?>

<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
    <title>数据统计 - 在线刷题系统</title>
    <link rel="stylesheet" href="../config/style.css">
    <style>
        .stats-overview {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 20px;
            margin: 24px 0;
        }
        
        .stat-card {
            background: white;
            padding: 25px;
            border-radius: 12px;
            text-align: center;
            box-shadow: var(--shadow);
            border-left: 4px solid var(--primary-color);
        }
        
        .stat-number {
            font-size: 32px;
            font-weight: 700;
            color: var(--primary-color);
            margin-bottom: 8px;
        }
        
        .today-stats {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(150px, 1fr));
            gap: 16px;
            margin: 20px 0;
        }
        
        .today-stat {
            background: var(--bg-tertiary);
            padding: 20px;
            border-radius: 10px;
            text-align: center;
        }
        
        .today-number {
            font-size: 24px;
            font-weight: 700;
            color: var(--success-color);
        }
        
        .section {
            margin: 32px 0;
        }
        
        .data-table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 16px;
        }
        
        .data-table th,
        .data-table td {
            padding: 12px;
            text-align: left;
            border-bottom: 1px solid var(--border-color);
        }
        
        .data-table th {
            background: var(--bg-tertiary);
            font-weight: 600;
        }
        
        .progress-bar {
            height: 8px;
            background: var(--bg-tertiary);
            border-radius: 4px;
            overflow: hidden;
            margin: 4px 0;
        }
        
        .progress-fill {
            height: 100%;
            background: linear-gradient(135deg, var(--primary-color), var(--secondary-color));
        }
        
        .trend-chart {
            background: white;
            padding: 20px;
            border-radius: 12px;
            margin-top: 16px;
        }
        
        .chart-bar {
            display: flex;
            align-items: end;
            height: 120px;
            gap: 8px;
            margin-top: 20px;
        }
        
        .chart-column {
            flex: 1;
            display: flex;
            flex-direction: column;
            align-items: center;
        }
        
        .chart-bar-item {
            background: linear-gradient(135deg, var(--primary-color), var(--secondary-color));
            border-radius: 4px 4px 0 0;
            width: 100%;
            min-height: 4px;
        }
        
        .chart-label {
            margin-top: 8px;
            font-size: 12px;
            color: var(--text-secondary);
        }
        
        .no-data {
            text-align: center;
            padding: 40px;
            color: var(--text-secondary);
        }
        
        .hierarchy-path {
            font-size: 12px;
            color: var(--text-secondary);
            margin-bottom: 4px;
        }
        
        @media (max-width: 768px) {
            .data-table {
                font-size: 14px;
            }
            
            .data-table th,
            .data-table td {
                padding: 8px 4px;
            }
            
            .chart-bar {
                height: 80px;
            }
        }
    </style>
</head>
<body>
    <nav class="navbar">
        <div class="container">
            <div class="nav-content">
                <a href="index.php" class="nav-brand">← 返回后台</a>
                <span class="nav-brand">数据统计</span>
            </div>
        </div>
    </nav>

    <div class="container">
        <div class="card">
            <h1>系统数据统计</h1>
            <p>全面了解系统运行情况和学习数据</p>
            
            <div class="stats-overview">
                <div class="stat-card">
                    <div class="stat-number"><?php echo $total_users; ?></div>
                    <div>用户总数</div>
                </div>
                <div class="stat-card">
                    <div class="stat-number"><?php echo $total_courses; ?></div>
                    <div>课程数量</div>
                </div>
                <div class="stat-card">
                    <div class="stat-number"><?php echo $total_modules; ?></div>
                    <div>模块数量</div>
                </div>
                <div class="stat-card">
                    <div class="stat-number"><?php echo $total_projects; ?></div>
                    <div>项目数量</div>
                </div>
                <div class="stat-card">
                    <div class="stat-number"><?php echo $total_questions; ?></div>
                    <div>题目数量</div>
                </div>
                <div class="stat-card">
                    <div class="stat-number"><?php echo $total_progress; ?></div>
                    <div>完成记录</div>
                </div>
            </div>
            
            <div class="today-stats">
                <div class="today-stat">
                    <div class="today-number"><?php echo $today_users; ?></div>
                    <div>今日注册</div>
                </div>
                <div class="today-stat">
                    <div class="today-number"><?php echo $today_progress; ?></div>
                    <div>今日完成</div>
                </div>
            </div>
        </div>

        <div class="section">
            <div class="card">
                <h2>学习趋势 (最近7天)</h2>
                <div class="trend-chart">
                    <?php if (!empty($trend_values) && max($trend_values) > 0): ?>
                        <div class="chart-bar">
                            <?php foreach ($trend_values as $index => $value): ?>
                                <div class="chart-column">
                                    <div class="chart-bar-item" style="height: <?php echo ($value / max($trend_values)) * 100; ?>%;"></div>
                                    <div class="chart-label">
                                        <?php echo $trend_labels[$index]; ?><br>
                                        <small><?php echo $value; ?></small>
                                    </div>
                                </div>
                            <?php endforeach; ?>
                        </div>
                    <?php else: ?>
                        <div class="no-data">
                            <p>暂无最近7天的学习数据</p>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>

        <div class="section">
            <div class="card">
                <h2>课程学习情况</h2>
                <?php if (!empty($course_stats)): ?>
                    <div class="data-table-container" style="overflow-x: auto;">
                        <table class="data-table">
                            <thead>
                                <tr>
                                    <th>课程名称</th>
                                    <th>模块数量</th>
                                    <th>项目数量</th>
                                    <th>完成人数</th>
                                    <th>平均得分</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($course_stats as $course): ?>
                                    <tr>
                                        <td>
                                            <strong><?php echo htmlspecialchars($course['course_name']); ?></strong>
                                            <br><small>ID: <?php echo $course['id']; ?></small>
                                        </td>
                                        <td><?php echo $course['module_count']; ?></td>
                                        <td><?php echo $course['project_count']; ?></td>
                                        <td><?php echo $course['completed_users']; ?></td>
                                        <td>
                                            <?php echo $course['avg_score'] ? round($course['avg_score'], 1) : '0'; ?>分
                                            <?php if ($course['avg_score']): ?>
                                                <div class="progress-bar">
                                                    <div class="progress-fill" style="width: <?php echo $course['avg_score']; ?>%"></div>
                                                </div>
                                            <?php endif; ?>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                <?php else: ?>
                    <div class="no-data">
                        <p>暂无课程学习数据</p>
                    </div>
                <?php endif; ?>
            </div>
        </div>

        <div class="section">
            <div class="card">
                <h2>项目学习情况</h2>
                <?php if (!empty($project_stats)): ?>
                    <div class="data-table-container" style="overflow-x: auto;">
                        <table class="data-table">
                            <thead>
                                <tr>
                                    <th>学习路径</th>
                                    <th>题目数量</th>
                                    <th>完成人数</th>
                                    <th>平均得分</th>
                                    <th>错题数量</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($project_stats as $project): ?>
                                    <tr>
                                        <td>
                                            <div class="hierarchy-path">
                                                📖 <?php echo htmlspecialchars($project['course_name']); ?> 
                                                → 📚 <?php echo htmlspecialchars($project['module_name']); ?> 
                                                → 🎯 <?php echo htmlspecialchars($project['project_name']); ?>
                                            </div>
                                            <small>项目ID: <?php echo $project['id']; ?></small>
                                        </td>
                                        <td><?php echo $project['question_count']; ?></td>
                                        <td><?php echo $project['completed_users']; ?></td>
                                        <td>
                                            <?php echo $project['avg_score'] ? round($project['avg_score'], 1) : '0'; ?>分
                                            <?php if ($project['avg_score']): ?>
                                                <div class="progress-bar">
                                                    <div class="progress-fill" style="width: <?php echo $project['avg_score']; ?>%"></div>
                                                </div>
                                            <?php endif; ?>
                                        </td>
                                        <td><?php echo $project['wrong_count']; ?></td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                <?php else: ?>
                    <div class="no-data">
                        <p>暂无项目学习数据</p>
                    </div>
                <?php endif; ?>
            </div>
        </div>

        <div class="section">
            <div class="card">
                <h2>活跃用户排行</h2>
                <?php if (!empty($active_users)): ?>
                    <div class="data-table-container" style="overflow-x: auto;">
                        <table class="data-table">
                            <thead>
                                <tr>
                                    <th>用户名</th>
                                    <th>完成项目</th>
                                    <th>错题数量</th>
                                    <th>平均得分</th>
                                    <th>最后活动</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($active_users as $user): ?>
                                    <tr>
                                        <td><?php echo htmlspecialchars($user['username']); ?></td>
                                        <td><?php echo $user['completed_projects']; ?></td>
                                        <td><?php echo $user['wrong_count']; ?></td>
                                        <td>
                                            <?php echo $user['avg_score'] ? round($user['avg_score'], 1) : '0'; ?>分
                                            <?php if ($user['avg_score']): ?>
                                                <div class="progress-bar">
                                                    <div class="progress-fill" style="width: <?php echo $user['avg_score']; ?>%"></div>
                                                </div>
                                            <?php endif; ?>
                                        </td>
                                        <td><?php echo $user['last_activity'] ? date('m-d H:i', strtotime($user['last_activity'])) : '暂无'; ?></td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                <?php else: ?>
                    <div class="no-data">
                        <p>暂无活跃用户数据</p>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</body>
</html>