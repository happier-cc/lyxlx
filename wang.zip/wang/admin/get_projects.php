<?php
require_once '../config/database.php';

header('Content-Type: application/json');

if (!isset($_SESSION['user_id']) || $_SESSION['role'] != 'admin') {
    http_response_code(403);
    echo json_encode(['error' => '无权限访问']);
    exit();
}

$module_id = $_GET['module_id'] ?? '';

if (empty($module_id)) {
    echo json_encode([]);
    exit();
}

$stmt = $pdo->prepare("SELECT id, project_name FROM projects WHERE module_id = ? ORDER BY project_name");
$stmt->execute([$module_id]);
$projects = $stmt->fetchAll(PDO::FETCH_ASSOC);

echo json_encode($projects);