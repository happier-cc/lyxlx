<?php
require_once '../config/database.php';

if (!isset($_SESSION['user_id']) || $_SESSION['role'] != 'admin') {
    header("Location: login.php");
    exit();
}

// 添加用户
if (isset($_POST['add_user'])) {
    $username = trim($_POST['username']);
    $password = $_POST['password'];
    $role = $_POST['role'];
    
    if (!empty($username) && !empty($password)) {
        // 检查用户名是否已存在
        $check_stmt = $pdo->prepare("SELECT COUNT(*) FROM users WHERE username = ?");
        $check_stmt->execute([$username]);
        $user_exists = $check_stmt->fetchColumn();
        
        if ($user_exists > 0) {
            $error = "用户名已存在！";
        } else {
            $hashed_password = password_hash($password, PASSWORD_DEFAULT);
            $stmt = $pdo->prepare("INSERT INTO users (username, password, role) VALUES (?, ?, ?)");
            $stmt->execute([$username, $hashed_password, $role]);
            $success = "用户添加成功！";
        }
    } else {
        $error = "请填写完整的用户信息！";
    }
}

// 设置/取消管理员
if (isset($_GET['set_admin'])) {
    $user_id = $_GET['set_admin'];
    $action = $_GET['action'];
    
    if ($action == 'set') {
        $stmt = $pdo->prepare("UPDATE users SET role = 'admin' WHERE id = ?");
        $stmt->execute([$user_id]);
        $success = "已设置为管理员！";
    } else {
        // 防止取消最后一个管理员
        $admin_count = $pdo->query("SELECT COUNT(*) FROM users WHERE role = 'admin'")->fetchColumn();
        if ($admin_count <= 1) {
            $error = "不能取消最后一个管理员账号！";
        } else {
            $stmt = $pdo->prepare("UPDATE users SET role = 'user' WHERE id = ?");
            $stmt->execute([$user_id]);
            $success = "已取消管理员权限！";
        }
    }
}

// 禁用/启用用户
if (isset($_GET['toggle_status'])) {
    $user_id = $_GET['toggle_status'];
    $action = $_GET['action'];
    
    // 不能禁用自己
    if ($user_id == $_SESSION['user_id'] && $action == 'disable') {
        $error = "不能禁用自己的账号！";
    } else {
        $new_status = $action == 'disable' ? 'disabled' : 'active';
        $stmt = $pdo->prepare("UPDATE users SET status = ? WHERE id = ?");
        $stmt->execute([$new_status, $user_id]);
        $success = $action == 'disable' ? "用户已禁用！" : "用户已启用！";
    }
}

// 删除用户
if (isset($_GET['delete'])) {
    $user_id = $_GET['delete'];
    
    // 不能删除自己
    if ($user_id == $_SESSION['user_id']) {
        $error = "不能删除自己的账号！";
    } else {
        // 开始事务，确保数据一致性
        $pdo->beginTransaction();
        
        try {
            // 删除用户相关的所有数据
            $tables_to_clean = [
                'user_progress',
                'wrong_questions', 
                'favorite_questions',
                'user_study_history',
                'user_answers'
            ];
            
            foreach ($tables_to_clean as $table) {
                $check_table = $pdo->query("SHOW TABLES LIKE '$table'")->fetch();
                if ($check_table) {
                    $delete_stmt = $pdo->prepare("DELETE FROM $table WHERE user_id = ?");
                    $delete_stmt->execute([$user_id]);
                }
            }
            
            // 最后删除用户
            $stmt = $pdo->prepare("DELETE FROM users WHERE id = ?");
            $stmt->execute([$user_id]);
            
            $pdo->commit();
            $success = "用户删除成功！";
        } catch (Exception $e) {
            $pdo->rollBack();
            $error = "删除用户时发生错误：" . $e->getMessage();
        }
    }
}

// 重置用户密码
if (isset($_POST['reset_password'])) {
    $user_id = $_POST['user_id'];
    $new_password = $_POST['new_password'];
    
    if (!empty($new_password)) {
        $hashed_password = password_hash($new_password, PASSWORD_DEFAULT);
        $stmt = $pdo->prepare("UPDATE users SET password = ? WHERE id = ?");
        $stmt->execute([$hashed_password, $user_id]);
        $success = "密码重置成功！";
    } else {
        $error = "请输入新密码！";
    }
}

// 获取所有用户
$users = $pdo->query("SELECT * FROM users ORDER BY created_at DESC")->fetchAll();

// 获取用户统计信息
foreach ($users as &$user) {
    // 获取完成项目数
    $completed_stmt = $pdo->prepare("SELECT COUNT(*) FROM user_progress WHERE user_id = ? AND completed = TRUE");
    $completed_stmt->execute([$user['id']]);
    $user['completed_projects'] = $completed_stmt->fetchColumn();
    
    // 获取错题数
    $wrong_stmt = $pdo->prepare("SELECT COUNT(*) FROM wrong_questions WHERE user_id = ?");
    $wrong_stmt->execute([$user['id']]);
    $user['wrong_count'] = $wrong_stmt->fetchColumn();
    
    // 获取平均分
    $score_stmt = $pdo->prepare("SELECT AVG(score) FROM user_progress WHERE user_id = ? AND completed = TRUE");
    $score_stmt->execute([$user['id']]);
    $user['avg_score'] = $score_stmt->fetchColumn();
    
    // 获取总学习时长（分钟）
    $time_stmt = $pdo->prepare("SELECT SUM(study_duration) FROM user_progress WHERE user_id = ?");
    $time_stmt->execute([$user['id']]);
    $user['total_study_time'] = $time_stmt->fetchColumn();
    
    // 获取最后学习时间
    $last_stmt = $pdo->prepare("SELECT MAX(completed_at) FROM user_progress WHERE user_id = ?");
    $last_stmt->execute([$user['id']]);
    $user['last_study'] = $last_stmt->fetchColumn();
}
unset($user); // 断开引用

// 获取系统统计
$total_users = count($users);
$active_users = array_filter($users, function($user) {
    return $user['status'] == 'active';
});
$admin_users = array_filter($users, function($user) {
    return $user['role'] == 'admin';
});
$today_users = $pdo->query("SELECT COUNT(*) FROM users WHERE DATE(created_at) = CURDATE()")->fetchColumn();
?>

<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
    <title>用户管理 - 在线刷题系统</title>
    <link rel="stylesheet" href="../config/style.css">
    <style>
        .users-grid {
            display: grid;
            gap: 16px;
        }
        
        .user-card {
            background: white;
            padding: 20px;
            border-radius: 12px;
            box-shadow: var(--shadow);
            border-left: 4px solid var(--primary-color);
        }
        
        .user-card.disabled {
            opacity: 0.7;
            border-left-color: var(--error-color);
            background: #f8f9fa;
        }
        
        .user-header {
            display: flex;
            justify-content: space-between;
            align-items: flex-start;
            margin-bottom: 16px;
        }
        
        .user-info {
            flex: 1;
        }
        
        .username {
            font-size: 18px;
            font-weight: 600;
            color: var(--text-primary);
            margin-bottom: 4px;
        }
        
        .user-role {
            display: inline-block;
            padding: 4px 12px;
            border-radius: 20px;
            font-size: 12px;
            font-weight: 600;
            margin-right: 8px;
        }
        
        .role-admin {
            background: var(--success-color);
            color: white;
        }
        
        .role-user {
            background: var(--text-secondary);
            color: white;
        }
        
        .user-status {
            display: inline-block;
            padding: 4px 12px;
            border-radius: 20px;
            font-size: 12px;
            font-weight: 600;
        }
        
        .status-active {
            background: var(--success-color);
            color: white;
        }
        
        .status-disabled {
            background: var(--error-color);
            color: white;
        }
        
        .user-actions {
            display: flex;
            gap: 8px;
            flex-wrap: wrap;
        }
        
        .user-stats {
            display: grid;
            grid-template-columns: repeat(4, 1fr);
            gap: 12px;
            margin-top: 16px;
        }
        
        .user-stat {
            text-align: center;
            padding: 12px;
            background: var(--bg-tertiary);
            border-radius: 8px;
        }
        
        .stat-value {
            font-size: 18px;
            font-weight: 700;
            color: var(--primary-color);
            margin-bottom: 4px;
        }
        
        .stat-label {
            font-size: 12px;
            color: var(--text-secondary);
        }
        
        .empty-state {
            text-align: center;
            padding: 60px 20px;
            color: var(--text-secondary);
        }
        
        .stats-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 16px;
            margin: 24px 0;
        }
        
        .stat-card {
            background: white;
            padding: 20px;
            border-radius: 12px;
            text-align: center;
            box-shadow: var(--shadow);
            border-left: 4px solid var(--primary-color);
        }
        
        .stat-number {
            font-size: 24px;
            font-weight: 700;
            color: var(--primary-color);
            margin-bottom: 8px;
        }
        
        .form-section {
            margin-bottom: 32px;
        }
        
        .password-reset-form {
            background: var(--bg-tertiary);
            padding: 20px;
            border-radius: 8px;
            margin-top: 16px;
        }
        
        .study-time {
            font-size: 11px;
            color: var(--text-secondary);
            margin-top: 2px;
        }
        
        @media (max-width: 768px) {
            .user-header {
                flex-direction: column;
                gap: 12px;
            }
            
            .user-actions {
                width: 100%;
                justify-content: flex-start;
            }
            
            .user-stats {
                grid-template-columns: repeat(2, 1fr);
            }
            
            .stats-grid {
                grid-template-columns: 1fr 1fr;
            }
        }
        
        @media (max-width: 480px) {
            .user-stats {
                grid-template-columns: 1fr;
            }
            
            .stats-grid {
                grid-template-columns: 1fr;
            }
        }
    </style>
</head>
<body>
    <nav class="navbar">
        <div class="container">
            <div class="nav-content">
                <a href="index.php" class="nav-brand">← 返回后台</a>
                <span class="nav-brand">用户管理</span>
            </div>
        </div>
    </nav>

    <div class="container">
        <?php if (isset($success)): ?>
            <div class="alert alert-success"><?php echo $success; ?></div>
        <?php endif; ?>
        
        <?php if (isset($error)): ?>
            <div class="alert alert-error"><?php echo $error; ?></div>
        <?php endif; ?>

        <!-- 系统统计 -->
        <div class="stats-grid">
            <div class="stat-card">
                <div class="stat-number"><?php echo $total_users; ?></div>
                <div>用户总数</div>
            </div>
            <div class="stat-card">
                <div class="stat-number"><?php echo count($active_users); ?></div>
                <div>活跃用户</div>
            </div>
            <div class="stat-card">
                <div class="stat-number"><?php echo count($admin_users); ?></div>
                <div>管理员</div>
            </div>
            <div class="stat-card">
                <div class="stat-number"><?php echo $today_users; ?></div>
                <div>今日注册</div>
            </div>
        </div>

        <!-- 添加用户表单 -->
        <div class="form-section">
            <div class="card">
                <h2>添加新用户</h2>
                <form method="post">
                    <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 16px;">
                        <div class="form-group">
                            <label for="username" class="form-label">用户名：</label>
                            <input type="text" id="username" name="username" class="form-input" 
                                   placeholder="请输入用户名" required>
                        </div>
                        
                        <div class="form-group">
                            <label for="password" class="form-label">密码：</label>
                            <input type="password" id="password" name="password" class="form-input" 
                                   placeholder="请输入密码" required>
                        </div>
                        
                        <div class="form-group">
                            <label for="role" class="form-label">用户角色：</label>
                            <select id="role" name="role" class="form-input form-select" required>
                                <option value="user">普通用户</option>
                                <option value="admin">管理员</option>
                            </select>
                        </div>
                    </div>
                    
                    <div class="form-group">
                        <button type="submit" name="add_user" class="btn btn-primary">添加用户</button>
                    </div>
                </form>
            </div>
        </div>

        <div class="card">
            <h2>用户管理 (<?php echo $total_users; ?> 人)</h2>
            <p>管理用户账号、权限和学习数据</p>
            
            <?php if (empty($users)): ?>
                <div class="empty-state">
                    <div style="font-size: 64px; margin-bottom: 20px;">👥</div>
                    <h3>暂无用户</h3>
                    <p>还没有用户注册</p>
                </div>
            <?php else: ?>
                <div class="users-grid">
                    <?php foreach ($users as $user): ?>
                        <div class="user-card <?php echo $user['status'] == 'disabled' ? 'disabled' : ''; ?>">
                            <div class="user-header">
                                <div class="user-info">
                                    <div class="username">
                                        <?php echo htmlspecialchars($user['username']); ?>
                                        <span class="user-role <?php echo $user['role'] == 'admin' ? 'role-admin' : 'role-user'; ?>">
                                            <?php echo $user['role'] == 'admin' ? '管理员' : '普通用户'; ?>
                                        </span>
                                        <span class="user-status <?php echo $user['status'] == 'active' ? 'status-active' : 'status-disabled'; ?>">
                                            <?php echo $user['status'] == 'active' ? '正常' : '已禁用'; ?>
                                        </span>
                                    </div>
                                    <div style="color: var(--text-secondary); font-size: 14px;">
                                        <div>注册时间：<?php echo date('Y-m-d H:i', strtotime($user['created_at'])); ?></div>
                                        <?php if ($user['last_login']): ?>
                                            <div>最后登录：<?php echo date('Y-m-d H:i', strtotime($user['last_login'])); ?></div>
                                        <?php endif; ?>
                                    </div>
                                </div>
                                
                                <div class="user-actions">
                                    <?php if ($user['status'] == 'active'): ?>
                                        <a href="manage_users.php?toggle_status=<?php echo $user['id']; ?>&action=disable" 
                                           class="btn btn-warning btn-sm"
                                           onclick="return confirm('确定要禁用该用户吗？禁用后用户将无法登录！')">
                                            禁用账号
                                        </a>
                                    <?php else: ?>
                                        <a href="manage_users.php?toggle_status=<?php echo $user['id']; ?>&action=enable" 
                                           class="btn btn-success btn-sm"
                                           onclick="return confirm('确定要启用该用户吗？')">
                                            启用账号
                                        </a>
                                    <?php endif; ?>
                                    
                                    <?php if ($user['role'] == 'admin'): ?>
                                        <?php if ($user['id'] != $_SESSION['user_id']): ?>
                                            <a href="manage_users.php?set_admin=<?php echo $user['id']; ?>&action=unset" 
                                               class="btn btn-warning btn-sm"
                                               onclick="return confirm('确定要取消该用户的管理员权限吗？')">
                                                取消管理员
                                            </a>
                                        <?php else: ?>
                                            <span class="btn btn-outline btn-sm" style="opacity: 0.6;">当前账号</span>
                                        <?php endif; ?>
                                    <?php else: ?>
                                        <a href="manage_users.php?set_admin=<?php echo $user['id']; ?>&action=set" 
                                           class="btn btn-success btn-sm"
                                           onclick="return confirm('确定要设置该用户为管理员吗？')">
                                            设为管理员
                                        </a>
                                    <?php endif; ?>
                                    
                                    <button type="button" class="btn btn-info btn-sm" 
                                            onclick="showPasswordReset(<?php echo $user['id']; ?>, '<?php echo htmlspecialchars($user['username']); ?>')">
                                        重置密码
                                    </button>
                                    
                                    <?php if ($user['id'] != $_SESSION['user_id']): ?>
                                        <a href="manage_users.php?delete=<?php echo $user['id']; ?>" 
                                           class="btn btn-error btn-sm"
                                           onclick="return confirm('确定要删除这个用户吗？此操作将删除该用户的所有学习数据，且不可恢复！')">
                                            删除
                                        </a>
                                    <?php endif; ?>
                                </div>
                            </div>
                            
                            <div class="user-stats">
                                <div class="user-stat">
                                    <div class="stat-value"><?php echo $user['completed_projects']; ?></div>
                                    <div class="stat-label">完成项目</div>
                                </div>
                                <div class="user-stat">
                                    <div class="stat-value"><?php echo $user['wrong_count']; ?></div>
                                    <div class="stat-label">错题数量</div>
                                </div>
                                <div class="user-stat">
                                    <div class="stat-value">
                                        <?php echo $user['avg_score'] ? round($user['avg_score'], 1) : '0'; ?>
                                    </div>
                                    <div class="stat-label">平均分</div>
                                </div>
                                <div class="user-stat">
                                    <div class="stat-value">
                                        <?php 
                                        if ($user['total_study_time'] > 0) {
                                            $hours = floor($user['total_study_time'] / 60);
                                            $minutes = $user['total_study_time'] % 60;
                                            if ($hours > 0) {
                                                echo $hours . '时' . $minutes . '分';
                                            } else {
                                                echo $minutes . '分';
                                            }
                                        } else {
                                            echo '0分';
                                        }
                                        ?>
                                    </div>
                                    <div class="stat-label">学习时长</div>
                                    <?php if ($user['last_study']): ?>
                                        <div class="study-time">
                                            最后学习：<?php echo date('m-d H:i', strtotime($user['last_study'])); ?>
                                        </div>
                                    <?php endif; ?>
                                </div>
                            </div>
                            
                            <!-- 密码重置表单（默认隐藏） -->
                            <div class="password-reset-form" id="passwordReset<?php echo $user['id']; ?>" style="display: none;">
                                <form method="post">
                                    <input type="hidden" name="user_id" value="<?php echo $user['id']; ?>">
                                    <div class="form-group">
                                        <label class="form-label">为 <?php echo htmlspecialchars($user['username']); ?> 设置新密码：</label>
                                        <input type="password" name="new_password" class="form-input" 
                                               placeholder="请输入新密码" required minlength="6">
                                    </div>
                                    <div class="form-group">
                                        <button type="submit" name="reset_password" class="btn btn-primary btn-sm">确认重置</button>
                                        <button type="button" class="btn btn-outline btn-sm" 
                                                onclick="hidePasswordReset(<?php echo $user['id']; ?>)">取消</button>
                                    </div>
                                </form>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>
            <?php endif; ?>
        </div>

        <div class="card">
            <h3>管理员说明</h3>
            <ul style="color: var(--text-secondary); line-height: 1.6;">
                <li><strong>用户权限：</strong>管理员可以访问系统后台，管理题目和用户；普通用户只能在前台学习和查看个人数据</li>
                <li><strong>账号状态：</strong>禁用用户后，该用户将无法登录系统；启用后恢复正常使用</li>
                <li><strong>安全要求：</strong>系统必须至少保留一个管理员账号，不能取消最后一个管理员权限</li>
                <li><strong>数据删除：</strong>删除用户会同时删除该用户的所有学习记录、错题、收藏等数据，此操作不可恢复</li>
                <li><strong>密码重置：</strong>可以为用户重置密码，新密码至少需要6位字符</li>
                <li><strong>学习统计：</strong>系统会记录用户的学习进度、成绩、错题数量和学习时长等数据</li>
                <li>建议定期备份重要数据，谨慎执行删除操作</li>
            </ul>
        </div>
    </div>

    <script>
        // 显示密码重置表单
        function showPasswordReset(userId, username) {
            // 隐藏所有其他密码重置表单
            document.querySelectorAll('[id^="passwordReset"]').forEach(form => {
                form.style.display = 'none';
            });
            
            // 显示当前用户的密码重置表单
            const resetForm = document.getElementById('passwordReset' + userId);
            resetForm.style.display = 'block';
            
            // 滚动到该表单位置
            resetForm.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
        }
        
        // 隐藏密码重置表单
        function hidePasswordReset(userId) {
            const resetForm = document.getElementById('passwordReset' + userId);
            resetForm.style.display = 'none';
        }
        
        // 页面加载时隐藏所有密码重置表单
        document.addEventListener('DOMContentLoaded', function() {
            document.querySelectorAll('[id^="passwordReset"]').forEach(form => {
                form.style.display = 'none';
            });
        });
        
        // 添加用户表单验证
        document.querySelector('form').addEventListener('submit', function(e) {
            const username = document.getElementById('username').value.trim();
            const password = document.getElementById('password').value;
            
            if (!username) {
                alert('请输入用户名！');
                e.preventDefault();
                return;
            }
            
            if (username.length < 3) {
                alert('用户名至少需要3个字符！');
                e.preventDefault();
                return;
            }
            
            if (!password) {
                alert('请输入密码！');
                e.preventDefault();
                return;
            }
            
            if (password.length < 6) {
                alert('密码至少需要6个字符！');
                e.preventDefault();
                return;
            }
        });
        
        // 密码重置表单验证
        document.addEventListener('submit', function(e) {
            if (e.target.querySelector('input[name="new_password"]')) {
                const newPassword = e.target.querySelector('input[name="new_password"]').value;
                
                if (!newPassword) {
                    alert('请输入新密码！');
                    e.preventDefault();
                    return;
                }
                
                if (newPassword.length < 6) {
                    alert('新密码至少需要6个字符！');
                    e.preventDefault();
                    return;
                }
            }
        });
    </script>
</body>
</html>