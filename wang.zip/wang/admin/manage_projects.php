<?php
require_once '../config/database.php';

if (!isset($_SESSION['user_id']) || $_SESSION['role'] != 'admin') {
    header("Location: login.php");
    exit();
}

$selected_module = $_GET['module_id'] ?? 'all';

// 添加项目
if (isset($_POST['add_project'])) {
    $module_id = $_POST['module_id'];
    $project_name = trim($_POST['project_name']);
    $description = trim($_POST['description']);
    
    if (!empty($project_name) && !empty($module_id)) {
        $stmt = $pdo->prepare("INSERT INTO projects (module_id, project_name, description) VALUES (?, ?, ?)");
        $stmt->execute([$module_id, $project_name, $description]);
        $success = "项目添加成功！";
    } else {
        $error = "项目名称和所属模块不能为空！";
    }
}

// 编辑项目
if (isset($_POST['edit_project'])) {
    $project_id = $_POST['project_id'];
    $module_id = $_POST['module_id'];
    $project_name = trim($_POST['project_name']);
    $description = trim($_POST['description']);
    
    if (!empty($project_name) && !empty($module_id)) {
        $stmt = $pdo->prepare("UPDATE projects SET module_id = ?, project_name = ?, description = ? WHERE id = ?");
        $stmt->execute([$module_id, $project_name, $description, $project_id]);
        $success = "项目更新成功！";
    } else {
        $error = "项目名称和所属模块不能为空！";
    }
}

// 删除项目
if (isset($_GET['delete'])) {
    $project_id = $_GET['delete'];
    
    // 检查是否有题目关联
    $check_stmt = $pdo->prepare("SELECT COUNT(*) FROM questions WHERE project_id = ?");
    $check_stmt->execute([$project_id]);
    $question_count = $check_stmt->fetchColumn();
    
    if ($question_count > 0) {
        $error = "无法删除该项目，因为有关联的题目存在！";
    } else {
        $stmt = $pdo->prepare("DELETE FROM projects WHERE id = ?");
        $stmt->execute([$project_id]);
        $success = "项目删除成功！";
    }
}

// 获取所有模块（包含课程信息）
$modules = $pdo->query("
    SELECT m.*, c.course_name 
    FROM modules m 
    JOIN courses c ON m.course_id = c.id 
    ORDER BY c.course_name, m.module_name
")->fetchAll();

// 获取项目
if ($selected_module == 'all') {
    $projects = $pdo->query("
        SELECT p.*, m.module_name, c.course_name 
        FROM projects p 
        JOIN modules m ON p.module_id = m.id 
        JOIN courses c ON m.course_id = c.id 
        ORDER BY c.course_name, m.module_name, p.project_name
    ")->fetchAll();
} else {
    $projects_stmt = $pdo->prepare("
        SELECT p.*, m.module_name, c.course_name 
        FROM projects p 
        JOIN modules m ON p.module_id = m.id 
        JOIN courses c ON m.course_id = c.id 
        WHERE p.module_id = ? 
        ORDER BY p.project_name
    ");
    $projects_stmt->execute([$selected_module]);
    $projects = $projects_stmt->fetchAll();
}

// 获取编辑的项目信息
$editing_project = null;
if (isset($_GET['edit'])) {
    $edit_id = $_GET['edit'];
    $stmt = $pdo->prepare("SELECT * FROM projects WHERE id = ?");
    $stmt->execute([$edit_id]);
    $editing_project = $stmt->fetch();
}
?>

<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
    <title>项目管理 - 在线刷题系统</title>
    <link rel="stylesheet" href="../config/style.css">
    <style>
        .filter-section {
            margin-bottom: 24px;
        }
        
        .form-section {
            margin-bottom: 32px;
        }
        
        .projects-grid {
            display: grid;
            gap: 16px;
        }
        
        .project-card {
            background: white;
            padding: 20px;
            border-radius: 12px;
            box-shadow: var(--shadow);
            border-left: 4px solid var(--primary-color);
        }
        
        .project-header {
            display: flex;
            justify-content: space-between;
            align-items: flex-start;
            margin-bottom: 12px;
        }
        
        .project-title {
            font-size: 18px;
            font-weight: 600;
            color: var(--text-primary);
        }
        
        .project-actions {
            display: flex;
            gap: 8px;
            flex-wrap: wrap;
        }
        
        .project-stats {
            display: flex;
            gap: 16px;
            margin-top: 12px;
            font-size: 14px;
            color: var(--text-secondary);
        }
        
        .stat-item {
            display: flex;
            align-items: center;
            gap: 4px;
        }
        
        .hierarchy-badge {
            background: var(--bg-tertiary);
            padding: 4px 8px;
            border-radius: 6px;
            font-size: 12px;
            margin-bottom: 8px;
            display: inline-block;
        }
        
        @media (max-width: 640px) {
            .project-header {
                flex-direction: column;
                gap: 12px;
            }
            
            .project-actions {
                width: 100%;
                justify-content: flex-start;
            }
        }
    </style>
</head>
<body>
    <nav class="navbar">
        <div class="container">
            <div class="nav-content">
                <a href="index.php" class="nav-brand">← 返回后台</a>
                <span class="nav-brand">项目管理</span>
            </div>
        </div>
    </nav>

    <div class="container">
        <?php if (isset($success)): ?>
            <div class="alert alert-success"><?php echo $success; ?></div>
        <?php endif; ?>
        
        <?php if (isset($error)): ?>
            <div class="alert alert-error"><?php echo $error; ?></div>
        <?php endif; ?>

        <div class="filter-section">
            <div class="card">
                <h3>筛选项目</h3>
                <form method="get">
                    <select name="module_id" class="form-input form-select" onchange="this.form.submit()">
                        <option value="all" <?php echo $selected_module == 'all' ? 'selected' : ''; ?>>所有模块</option>
                        <?php foreach ($modules as $module): ?>
                            <option value="<?php echo $module['id']; ?>" <?php echo $selected_module == $module['id'] ? 'selected' : ''; ?>>
                                <?php echo htmlspecialchars($module['course_name'] . ' / ' . $module['module_name']); ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </form>
                <div class="mt-2">
                    <a href="manage_modules.php" class="btn btn-outline btn-sm">📚 管理模块</a>
                </div>
            </div>
        </div>

        <div class="form-section">
            <div class="card">
                <h2><?php echo $editing_project ? '编辑项目' : '添加新项目'; ?></h2>
                <form method="post">
                    <?php if ($editing_project): ?>
                        <input type="hidden" name="project_id" value="<?php echo $editing_project['id']; ?>">
                    <?php endif; ?>
                    
                    <div class="form-group">
                        <label for="module_id" class="form-label">所属模块：</label>
                        <select id="module_id" name="module_id" class="form-input form-select" required>
                            <option value="">选择模块</option>
                            <?php foreach ($modules as $module): ?>
                                <option value="<?php echo $module['id']; ?>" 
                                    <?php echo ($editing_project['module_id'] ?? '') == $module['id'] ? 'selected' : ''; ?>>
                                    <?php echo htmlspecialchars($module['course_name'] . ' / ' . $module['module_name']); ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    
                    <div class="form-group">
                        <label for="project_name" class="form-label">项目名称：</label>
                        <input type="text" id="project_name" name="project_name" class="form-input" 
                               value="<?php echo $editing_project ? htmlspecialchars($editing_project['project_name']) : ''; ?>" 
                               placeholder="请输入项目名称" required>
                    </div>
                    
                    <div class="form-group">
                        <label for="description" class="form-label">项目描述：</label>
                        <textarea id="description" name="description" class="form-input form-textarea" 
                                  placeholder="请输入项目描述（可选）"><?php echo $editing_project ? htmlspecialchars($editing_project['description']) : ''; ?></textarea>
                    </div>
                    
                    <div class="form-group">
                        <?php if ($editing_project): ?>
                            <button type="submit" name="edit_project" class="btn btn-primary">更新项目</button>
                            <a href="manage_projects.php?module_id=<?php echo $selected_module; ?>" class="btn btn-outline">取消编辑</a>
                        <?php else: ?>
                            <button type="submit" name="add_project" class="btn btn-primary">添加项目</button>
                        <?php endif; ?>
                    </div>
                </form>
            </div>
        </div>

        <div class="card">
            <h2>项目列表 (<?php echo count($projects); ?> 个)</h2>
            
            <?php if (empty($projects)): ?>
                <div class="text-center" style="padding: 40px; color: var(--text-secondary);">
                    <p>暂无项目</p>
                    <a href="manage_projects.php?action=add" class="btn btn-primary mt-2">添加第一个项目</a>
                </div>
            <?php else: ?>
                <div class="projects-grid">
                    <?php foreach ($projects as $project): 
                        // 获取该项目的题目数量
                        $question_count_stmt = $pdo->prepare("SELECT COUNT(*) FROM questions WHERE project_id = ?");
                        $question_count_stmt->execute([$project['id']]);
                        $question_count = $question_count_stmt->fetchColumn();
                        
                        // 获取学习人数
                        $user_count_stmt = $pdo->prepare("SELECT COUNT(DISTINCT user_id) FROM user_progress WHERE project_id = ?");
                        $user_count_stmt->execute([$project['id']]);
                        $user_count = $user_count_stmt->fetchColumn();
                    ?>
                        <div class="project-card">
                            <div class="hierarchy-badge">
                                📖 <?php echo htmlspecialchars($project['course_name']); ?> 
                                → 📚 <?php echo htmlspecialchars($project['module_name']); ?>
                            </div>
                            
                            <div class="project-header">
                                <div class="project-title"><?php echo htmlspecialchars($project['project_name']); ?></div>
                                <div class="project-actions">
                                    <a href="manage_questions.php?project_id=<?php echo $project['id']; ?>" class="btn btn-primary btn-sm">管理题目</a>
                                    <a href="manage_projects.php?module_id=<?php echo $selected_module; ?>&edit=<?php echo $project['id']; ?>" class="btn btn-outline btn-sm">编辑</a>
                                    <a href="manage_projects.php?module_id=<?php echo $selected_module; ?>&delete=<?php echo $project['id']; ?>" 
                                       class="btn btn-error btn-sm"
                                       onclick="return confirm('确定要删除这个项目吗？')">删除</a>
                                </div>
                            </div>
                            
                            <?php if ($project['description']): ?>
                                <p style="color: var(--text-secondary); margin-bottom: 12px;">
                                    <?php echo htmlspecialchars($project['description']); ?>
                                </p>
                            <?php endif; ?>
                            
                            <div class="project-stats">
                                <div class="stat-item">
                                    <span>❓</span>
                                    <span><?php echo $question_count; ?> 题</span>
                                </div>
                                <div class="stat-item">
                                    <span>👥</span>
                                    <span><?php echo $user_count; ?> 人学习</span>
                                </div>
                                <div class="stat-item">
                                    <span>📅</span>
                                    <span><?php echo date('Y-m-d', strtotime($project['created_at'])); ?></span>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>
            <?php endif; ?>
        </div>
    </div>
</body>
</html>