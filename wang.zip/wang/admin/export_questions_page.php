<?php
require_once '../config/database.php';

if (!isset($_SESSION['user_id']) || $_SESSION['role'] != 'admin') {
    header("Location: login.php");
    exit();
}

// 获取所有课程、模块和项目
$courses = $pdo->query("SELECT * FROM courses ORDER BY course_name")->fetchAll();
$modules = [];
$projects = [];

// 如果有选中的课程，获取对应的模块
$selected_course = $_GET['course_id'] ?? '';
if (!empty($selected_course)) {
    $modules_stmt = $pdo->prepare("SELECT * FROM modules WHERE course_id = ? ORDER BY module_name");
    $modules_stmt->execute([$selected_course]);
    $modules = $modules_stmt->fetchAll();
}

// 如果有选中的模块，获取对应的项目
$selected_module = $_GET['module_id'] ?? '';
if (!empty($selected_module)) {
    $projects_stmt = $pdo->prepare("SELECT * FROM projects WHERE module_id = ? ORDER BY project_name");
    $projects_stmt->execute([$selected_module]);
    $projects = $projects_stmt->fetchAll();
}

// 获取统计信息
$total_questions = $pdo->query("SELECT COUNT(*) FROM questions")->fetchColumn();
$total_courses = $pdo->query("SELECT COUNT(*) FROM courses")->fetchColumn();
$total_modules = $pdo->query("SELECT COUNT(*) FROM modules")->fetchColumn();
$total_projects = $pdo->query("SELECT COUNT(*) FROM projects")->fetchColumn();

// 获取各课程的题目数量
$course_stats = $pdo->query("
    SELECT c.id, c.course_name, COUNT(q.id) as question_count
    FROM courses c
    LEFT JOIN modules m ON c.id = m.course_id
    LEFT JOIN projects p ON m.id = p.module_id
    LEFT JOIN questions q ON p.id = q.project_id
    GROUP BY c.id, c.course_name
    ORDER BY question_count DESC
")->fetchAll();
?>

<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
    <title>批量导出题目 - 在线刷题系统</title>
    <link rel="stylesheet" href="../config/style.css">
    <style>
        .export-container {
            max-width: 1000px;
            margin: 50px auto;
            padding: 30px;
        }
        
        .export-card {
            background: white;
            padding: 30px;
            border-radius: 12px;
            box-shadow: var(--shadow);
            margin-bottom: 24px;
        }
        
        .stats-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 16px;
            margin: 24px 0;
        }
        
        .stat-card {
            background: white;
            padding: 20px;
            border-radius: 12px;
            text-align: center;
            box-shadow: var(--shadow);
            border-left: 4px solid var(--primary-color);
        }
        
        .stat-number {
            font-size: 24px;
            font-weight: 700;
            color: var(--primary-color);
            margin-bottom: 8px;
        }
        
        .export-options {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
            gap: 20px;
            margin: 24px 0;
        }
        
        .option-card {
            background: var(--bg-tertiary);
            padding: 25px;
            border-radius: 12px;
            border: 2px solid transparent;
            transition: all 0.3s;
            cursor: pointer;
        }
        
        .option-card:hover {
            border-color: var(--primary-color);
            transform: translateY(-2px);
        }
        
        .option-card.selected {
            border-color: var(--primary-color);
            background: #e3f2fd;
        }
        
        .option-icon {
            font-size: 40px;
            margin-bottom: 15px;
            text-align: center;
        }
        
        .option-title {
            font-size: 18px;
            font-weight: 600;
            margin-bottom: 10px;
            text-align: center;
        }
        
        .option-desc {
            color: var(--text-secondary);
            text-align: center;
            line-height: 1.5;
        }
        
        .filter-section {
            background: var(--bg-tertiary);
            padding: 20px;
            border-radius: 8px;
            margin: 20px 0;
        }
        
        .filter-row {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 16px;
            margin-bottom: 16px;
        }
        
        .format-options {
            display: flex;
            gap: 16px;
            margin: 20px 0;
            justify-content: center;
        }
        
        .format-option {
            display: flex;
            align-items: center;
            gap: 8px;
            padding: 12px 20px;
            background: white;
            border: 2px solid var(--border-color);
            border-radius: 8px;
            cursor: pointer;
            transition: all 0.3s;
        }
        
        .format-option.selected {
            border-color: var(--primary-color);
            background: #e3f2fd;
        }
        
        .hierarchy-path {
            background: var(--bg-tertiary);
            padding: 6px 12px;
            border-radius: 6px;
            font-size: 12px;
            margin-bottom: 8px;
            display: inline-block;
        }
        
        .course-stats {
            margin-top: 24px;
        }
        
        .course-stat-item {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 12px 16px;
            border-bottom: 1px solid var(--border-color);
        }
        
        .course-stat-item:last-child {
            border-bottom: none;
        }
        
        @media (max-width: 768px) {
            .export-options {
                grid-template-columns: 1fr;
            }
            
            .filter-row {
                grid-template-columns: 1fr;
            }
            
            .format-options {
                flex-direction: column;
                align-items: center;
            }
        }
    </style>
</head>
<body>
    <nav class="navbar">
        <div class="container">
            <div class="nav-content">
                <a href="index.php" class="nav-brand">← 返回后台</a>
                <span class="nav-brand">批量导出题目</span>
            </div>
        </div>
    </nav>

    <div class="container">
        <div class="export-container">
            <div class="export-card">
                <h1>批量导出题目</h1>
                <p>将题目数据导出为CSV或JSON格式文件</p>
                
                <!-- 统计信息 -->
                <div class="stats-grid">
                    <div class="stat-card">
                        <div class="stat-number"><?php echo $total_questions; ?></div>
                        <div>题目总数</div>
                    </div>
                    <div class="stat-card">
                        <div class="stat-number"><?php echo $total_courses; ?></div>
                        <div>课程数量</div>
                    </div>
                    <div class="stat-card">
                        <div class="stat-number"><?php echo $total_modules; ?></div>
                        <div>模块数量</div>
                    </div>
                    <div class="stat-card">
                        <div class="stat-number"><?php echo $total_projects; ?></div>
                        <div>项目数量</div>
                    </div>
                </div>

                <!-- 导出范围选择 -->
                <h3>选择导出范围</h3>
                <div class="export-options">
                    <div class="option-card" onclick="selectExportType('all')" id="optionAll">
                        <div class="option-icon">📚</div>
                        <div class="option-title">全部题目</div>
                        <div class="option-desc">
                            导出系统中的所有题目<br>
                            <small>共 <?php echo $total_questions; ?> 道题目</small>
                        </div>
                    </div>
                    
                    <div class="option-card" onclick="selectExportType('course')" id="optionCourse">
                        <div class="option-icon">📖</div>
                        <div class="option-title">按课程导出</div>
                        <div class="option-desc">
                            导出指定课程的所有题目<br>
                            <small>可选择具体课程</small>
                        </div>
                    </div>
                    
                    <div class="option-card" onclick="selectExportType('module')" id="optionModule">
                        <div class="option-icon">📚</div>
                        <div class="option-title">按模块导出</div>
                        <div class="option-desc">
                            导出指定模块的所有题目<br>
                            <small>可选择具体模块</small>
                        </div>
                    </div>
                    
                    <div class="option-card" onclick="selectExportType('project')" id="optionProject">
                        <div class="option-icon">🎯</div>
                        <div class="option-title">按项目导出</div>
                        <div class="option-desc">
                            导出指定项目的所有题目<br>
                            <small>可选择具体项目</small>
                        </div>
                    </div>
                </div>

                <!-- 筛选条件 -->
                <div class="filter-section" id="filterSection" style="display: none;">
                    <h4>筛选条件</h4>
                    <form id="filterForm">
                        <div class="filter-row">
                            <div class="form-group" id="courseFilter" style="display: none;">
                                <label class="form-label">选择课程：</label>
                                <select name="course_id" class="form-input" id="courseSelect" onchange="onCourseChange()">
                                    <option value="">请选择课程</option>
                                    <?php foreach ($courses as $course): ?>
                                        <option value="<?php echo $course['id']; ?>" 
                                            <?php echo $selected_course == $course['id'] ? 'selected' : ''; ?>>
                                            <?php echo htmlspecialchars($course['course_name']); ?>
                                        </option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                            
                            <div class="form-group" id="moduleFilter" style="display: none;">
                                <label class="form-label">选择模块：</label>
                                <select name="module_id" class="form-input" id="moduleSelect" onchange="onModuleChange()">
                                    <option value="">请选择模块</option>
                                    <?php foreach ($modules as $module): ?>
                                        <option value="<?php echo $module['id']; ?>" 
                                            <?php echo $selected_module == $module['id'] ? 'selected' : ''; ?>>
                                            <?php echo htmlspecialchars($module['module_name']); ?>
                                        </option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                            
                            <div class="form-group" id="projectFilter" style="display: none;">
                                <label class="form-label">选择项目：</label>
                                <select name="project_id" class="form-input" id="projectSelect">
                                    <option value="">请选择项目</option>
                                    <?php foreach ($projects as $project): ?>
                                        <option value="<?php echo $project['id']; ?>">
                                            <div class="hierarchy-path">
                                                📖 <?php echo htmlspecialchars($project['course_name'] ?? ''); ?> 
                                                → 📚 <?php echo htmlspecialchars($project['module_name'] ?? ''); ?> 
                                                → 🎯 <?php echo htmlspecialchars($project['project_name']); ?>
                                            </div>
                                        </option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                        </div>
                    </form>
                </div>

                <!-- 导出格式选择 -->
                <h3>选择导出格式</h3>
                <div class="format-options">
                    <label class="format-option selected" id="formatCsv">
                        <input type="radio" name="export_format" value="csv" checked style="display: none;">
                        <span>📊 CSV格式</span>
                        <small>（适合Excel和数据分析）</small>
                    </label>
                    
                    <label class="format-option" id="formatJson">
                        <input type="radio" name="export_format" value="json" style="display: none;">
                        <span>🔤 JSON格式</span>
                        <small>（适合程序处理）</small>
                    </label>
                </div>

                <!-- 导出按钮 -->
                <div class="text-center mt-4">
                    <button type="button" class="btn btn-primary btn-lg" onclick="startExport()">
                        📥 开始导出
                    </button>
                    <a href="import_questions.php" class="btn btn-outline btn-lg">📤 导入题目</a>
                </div>
            </div>

            <!-- 课程题目统计 -->
            <div class="export-card">
                <h3>各课程题目统计</h3>
                <div class="course-stats">
                    <?php foreach ($course_stats as $course): ?>
                        <div class="course-stat-item">
                            <div>
                                <strong><?php echo htmlspecialchars($course['course_name']); ?></strong>
                                <small style="color: var(--text-secondary); margin-left: 8px;">ID: <?php echo $course['id']; ?></small>
                            </div>
                            <div>
                                <span class="badge" style="background: var(--primary-color); color: white; padding: 4px 8px; border-radius: 12px;">
                                    <?php echo $course['question_count']; ?> 题
                                </span>
                                <button type="button" class="btn btn-outline btn-sm" onclick="exportCourse(<?php echo $course['id']; ?>)">
                                    导出此课程
                                </button>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>
            </div>
        </div>
    </div>

    <script>
        let selectedExportType = 'all';
        
        // 选择导出类型
        function selectExportType(type) {
            selectedExportType = type;
            
            // 更新选项卡片样式
            document.querySelectorAll('.option-card').forEach(card => {
                card.classList.remove('selected');
            });
            document.getElementById('option' + type.charAt(0).toUpperCase() + type.slice(1)).classList.add('selected');
            
            // 显示/隐藏筛选条件
            const filterSection = document.getElementById('filterSection');
            const courseFilter = document.getElementById('courseFilter');
            const moduleFilter = document.getElementById('moduleFilter');
            const projectFilter = document.getElementById('projectFilter');
            
            filterSection.style.display = 'block';
            courseFilter.style.display = 'none';
            moduleFilter.style.display = 'none';
            projectFilter.style.display = 'none';
            
            switch (type) {
                case 'course':
                    courseFilter.style.display = 'block';
                    break;
                case 'module':
                    courseFilter.style.display = 'block';
                    moduleFilter.style.display = 'block';
                    loadModules();
                    break;
                case 'project':
                    courseFilter.style.display = 'block';
                    moduleFilter.style.display = 'block';
                    projectFilter.style.display = 'block';
                    loadModules();
                    loadProjects();
                    break;
                default:
                    filterSection.style.display = 'none';
            }
        }
        
        // 课程选择变化
        function onCourseChange() {
            const courseId = document.getElementById('courseSelect').value;
            if (courseId && (selectedExportType === 'module' || selectedExportType === 'project')) {
                loadModules(courseId);
            }
        }
        
        // 模块选择变化
        function onModuleChange() {
            const moduleId = document.getElementById('moduleSelect').value;
            if (moduleId && selectedExportType === 'project') {
                loadProjects(moduleId);
            }
        }
        
        // 加载模块
        function loadModules(courseId = null) {
            if (!courseId) {
                courseId = document.getElementById('courseSelect').value;
            }
            
            if (!courseId) {
                document.getElementById('moduleSelect').innerHTML = '<option value="">请选择模块</option>';
                return;
            }
            
            fetch('get_modules.php?course_id=' + courseId)
                .then(response => response.json())
                .then(modules => {
                    const moduleSelect = document.getElementById('moduleSelect');
                    moduleSelect.innerHTML = '<option value="">请选择模块</option>';
                    modules.forEach(module => {
                        const option = document.createElement('option');
                        option.value = module.id;
                        option.textContent = module.module_name;
                        moduleSelect.appendChild(option);
                    });
                });
        }
        
        // 加载项目
        function loadProjects(moduleId = null) {
            if (!moduleId) {
                moduleId = document.getElementById('moduleSelect').value;
            }
            
            if (!moduleId) {
                document.getElementById('projectSelect').innerHTML = '<option value="">请选择项目</option>';
                return;
            }
            
            fetch('get_projects.php?module_id=' + moduleId)
                .then(response => response.json())
                .then(projects => {
                    const projectSelect = document.getElementById('projectSelect');
                    projectSelect.innerHTML = '<option value="">请选择项目</option>';
                    projects.forEach(project => {
                        const option = document.createElement('option');
                        option.value = project.id;
                        option.textContent = project.project_name;
                        projectSelect.appendChild(option);
                    });
                });
        }
        
        // 开始导出
        function startExport() {
            const format = document.querySelector('input[name="export_format"]:checked').value;
            let url = 'export_questions.php?format=' + format + '&type=' + selectedExportType;
            
            // 添加筛选参数
            if (selectedExportType === 'course') {
                const courseId = document.getElementById('courseSelect').value;
                if (!courseId) {
                    alert('请选择要导出的课程！');
                    return;
                }
                url += '&course_id=' + courseId;
            } else if (selectedExportType === 'module') {
                const moduleId = document.getElementById('moduleSelect').value;
                if (!moduleId) {
                    alert('请选择要导出的模块！');
                    return;
                }
                url += '&module_id=' + moduleId;
            } else if (selectedExportType === 'project') {
                const projectId = document.getElementById('projectSelect').value;
                if (!projectId) {
                    alert('请选择要导出的项目！');
                    return;
                }
                url += '&project_id=' + projectId;
            }
            
            // 开始下载
            window.location.href = url;
        }
        
        // 导出指定课程
        function exportCourse(courseId) {
            const format = document.querySelector('input[name="export_format"]:checked').value;
            const url = `export_questions.php?format=${format}&type=course&course_id=${courseId}`;
            window.location.href = url;
        }
        
        // 格式选择
        document.querySelectorAll('.format-option').forEach(option => {
            option.addEventListener('click', function() {
                document.querySelectorAll('.format-option').forEach(opt => {
                    opt.classList.remove('selected');
                });
                this.classList.add('selected');
                const radio = this.querySelector('input[type="radio"]');
                radio.checked = true;
            });
        });
        
        // 页面加载时默认选择全部题目
        window.addEventListener('load', function() {
            selectExportType('all');
            
            // 如果有URL参数，恢复筛选状态
            const urlParams = new URLSearchParams(window.location.search);
            const courseId = urlParams.get('course_id');
            const moduleId = urlParams.get('module_id');
            
            if (courseId) {
                document.getElementById('courseSelect').value = courseId;
                if (moduleId) {
                    selectExportType('module');
                    // 需要异步加载模块和项目
                    setTimeout(() => {
                        loadModules(courseId);
                        setTimeout(() => {
                            document.getElementById('moduleSelect').value = moduleId;
                            loadProjects(moduleId);
                        }, 100);
                    }, 100);
                } else {
                    selectExportType('course');
                }
            }
        });
    </script>
</body>
</html>