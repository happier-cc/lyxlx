<?php
require_once '../config/database.php';

// 检查管理员权限
if (!isset($_SESSION['user_id']) || $_SESSION['role'] != 'admin') {
    header("Location: login.php");
    exit();
}

// 获取统计信息 - 更新为新的三级结构
$users_count = $pdo->query("SELECT COUNT(*) FROM users")->fetchColumn();
$courses_count = $pdo->query("SELECT COUNT(*) FROM courses")->fetchColumn();
$modules_count = $pdo->query("SELECT COUNT(*) FROM modules")->fetchColumn();
$projects_count = $pdo->query("SELECT COUNT(*) FROM projects")->fetchColumn();
$questions_count = $pdo->query("SELECT COUNT(*) FROM questions")->fetchColumn();
$wrong_count = $pdo->query("SELECT COUNT(*) FROM wrong_questions")->fetchColumn();
$today_users = $pdo->query("SELECT COUNT(*) FROM users WHERE DATE(created_at) = CURDATE()")->fetchColumn();
?>

<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
    <title>管理员后台 - 在线刷题系统</title>
    <link rel="stylesheet" href="../config/style.css">
    <style>
        .admin-header {
            background: linear-gradient(135deg, var(--primary-color), var(--secondary-color));
            color: white;
            padding: 30px 0;
            margin: 0 -16px 32px;
            padding-left: 16px;
            padding-right: 16px;
        }
        
        .admin-stats {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(150px, 1fr));
            gap: 16px;
            margin: 24px 0;
        }
        
        .admin-stat {
            background: rgba(255, 255, 255, 0.2);
            padding: 20px;
            border-radius: 12px;
            text-align: center;
            backdrop-filter: blur(10px);
        }
        
        .admin-stat-number {
            font-size: 24px;
            font-weight: 700;
            margin-bottom: 8px;
        }
        
        .admin-menu {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 20px;
            margin: 32px 0;
        }
        
        .menu-card {
            background: white;
            padding: 25px;
            border-radius: 12px;
            text-align: center;
            box-shadow: var(--shadow);
            transition: transform 0.3s ease;
            text-decoration: none;
            color: var(--text-primary);
            border: 2px solid transparent;
        }
        
        .menu-card:hover {
            transform: translateY(-5px);
            border-color: var(--primary-color);
        }
        
        .menu-icon {
            font-size: 40px;
            margin-bottom: 15px;
        }
        
        .menu-title {
            font-size: 18px;
            font-weight: 600;
            margin-bottom: 10px;
        }
        
        .menu-desc {
            color: var(--text-secondary);
            font-size: 14px;
        }
        
        .quick-actions {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 16px;
            margin: 32px 0;
        }
        
        .action-card {
            background: white;
            padding: 20px;
            border-radius: 12px;
            box-shadow: var(--shadow);
            border-left: 4px solid var(--success-color);
        }
        
        .action-title {
            font-size: 16px;
            font-weight: 600;
            margin-bottom: 10px;
            color: var(--text-primary);
        }
        
        .action-buttons {
            display: flex;
            gap: 10px;
            flex-wrap: wrap;
        }
        
        .btn {
            padding: 8px 16px;
            border: none;
            border-radius: 6px;
            text-decoration: none;
            font-size: 14px;
            cursor: pointer;
            transition: background 0.3s;
            display: inline-block;
            text-align: center;
        }
        
        .btn-primary {
            background: var(--primary-color);
            color: white;
        }
        
        .btn-primary:hover {
            background: var(--secondary-color);
        }
        
        .btn-success {
            background: var(--success-color);
            color: white;
        }
        
        .btn-success:hover {
            background: #28a745;
        }
        
        @media (max-width: 768px) {
            .admin-menu {
                grid-template-columns: 1fr;
            }
            
            .quick-actions {
                grid-template-columns: 1fr;
            }
            
            .action-buttons {
                flex-direction: column;
            }
            
            .btn {
                width: 100%;
            }
        }
    </style>
</head>
<body>
    <nav class="navbar">
        <div class="container">
            <div class="nav-content">
                <a href="index.php" class="nav-brand">⚙️ 管理后台</a>
                <div class="nav-menu">
                    <span style="color: var(--text-secondary);">欢迎, <?php echo htmlspecialchars($_SESSION['username']); ?></span>
                    <a href="../user/index.php" class="nav-link">前台首页</a>
                    <a href="../user/logout.php" class="nav-link">退出登录</a>
                </div>
            </div>
        </div>
    </nav>

    <div class="container">
        <div class="admin-header">
            <h1>系统管理后台</h1>
            <p>管理系统内容、用户和数据</p>
            
            <div class="admin-stats">
                <div class="admin-stat">
                    <div class="admin-stat-number"><?php echo $users_count; ?></div>
                    <div>用户总数</div>
                </div>
                <div class="admin-stat">
                    <div class="admin-stat-number"><?php echo $courses_count; ?></div>
                    <div>课程数量</div>
                </div>
                <div class="admin-stat">
                    <div class="admin-stat-number"><?php echo $modules_count; ?></div>
                    <div>模块数量</div>
                </div>
                <div class="admin-stat">
                    <div class="admin-stat-number"><?php echo $projects_count; ?></div>
                    <div>项目数量</div>
                </div>
                <div class="admin-stat">
                    <div class="admin-stat-number"><?php echo $questions_count; ?></div>
                    <div>题目数量</div>
                </div>
                <div class="admin-stat">
                    <div class="admin-stat-number"><?php echo $wrong_count; ?></div>
                    <div>错题记录</div>
                </div>
                <div class="admin-stat">
                    <div class="admin-stat-number"><?php echo $today_users; ?></div>
                    <div>今日注册</div>
                </div>
            </div>
        </div>


        <div class="admin-menu">
            <a href="manage_courses.php" class="menu-card">
                <div class="menu-icon">📖</div>
                <div class="menu-title">课程管理</div>
                <div class="menu-desc">管理课程和分类</div>
            </a>
            
            <a href="manage_modules.php" class="menu-card">
                <div class="menu-icon">📚</div>
                <div class="menu-title">模块管理</div>
                <div class="menu-desc">管理课程模块</div>
            </a>
            
            <a href="manage_projects.php" class="menu-card">
                <div class="menu-icon">🎯</div>
                <div class="menu-title">项目管理</div>
                <div class="menu-desc">管理刷题项目</div>
            </a>
            
            <a href="manage_questions.php" class="menu-card">
                <div class="menu-icon">❓</div>
                <div class="menu-title">题目管理</div>
                <div class="menu-desc">添加、编辑和删除题目</div>
            </a>
            
            <a href="import_questions.php" class="menu-card">
                <div class="menu-icon">📥</div>
                <div class="menu-title">批量导入</div>
                <div class="menu-desc">批量导入题目数据</div>
            </a>
            
            <a href="manage_users.php" class="menu-card">
                <div class="menu-icon">👥</div>
                <div class="menu-title">用户管理</div>
                <div class="menu-desc">管理用户账号和权限</div>
            </a>
            
            <a href="view_statistics.php" class="menu-card">
                <div class="menu-icon">📊</div>
                <div class="menu-title">数据统计</div>
                <div class="menu-desc">查看学习数据和报表</div>
            </a>
            <a href="manage_settings.php" class="menu-card">
                <div class="menu-icon">⚙️</div>
                <div class="menu-title">系统设置</div>
                <div class="menu-desc">管理系统功能和配置</div>
            </a>
            <a href="user_study_records.php" class="menu-card">
                <div class="menu-icon">📊</div>
                <div class="menu-title">学习记录</div>
                <div class="menu-desc">查看用户学习进度</div>
            </a>
            <a href="user_study_summary.php" class="menu-card">
                <div class="menu-icon">👥</div>
                <div class="menu-title">用户汇总</div>
                <div class="menu-desc">用户学习统计概览</div>
            </a>
            
            <a href="wrong_questions_rank.php" class="menu-card">
                <div class="menu-icon">🏆</div>
                <div class="menu-title">错题排行</div>
                <div class="menu-desc">错题数据统计分析</div>
            </a>            
        </div>
    </div>
</body>
</html>