<?php
// download_user_template.php
require_once '../config/database.php';

if (!isset($_SESSION['user_id']) || $_SESSION['role'] != 'admin') {
    header("Location: login.php");
    exit();
}

// 设置HTTP头
header('Content-Type: text/csv; charset=utf-8');
header('Content-Disposition: attachment; filename="用户导入模板_' . date('YmdHis') . '.csv"');

// 输出CSV文件内容
$output = fopen('php://output', 'w');

// 添加BOM头，确保Excel打开时中文不乱码
fwrite($output, "\xEF\xBB\xBF");

// 写入表头
fputcsv($output, ['用户名', '角色']);

// 写入示例数据（包含汉字用户名）
fputcsv($output, ['张三', 'user']);
fputcsv($output, ['李四', 'user']);
fputcsv($output, ['王老师', 'admin']);
fputcsv($output, ['student_小明', 'user']);
fputcsv($output, ['赵同学', 'user']);
fputcsv($output, ['管理员', 'admin']);

fclose($output);
exit;