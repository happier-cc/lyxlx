<?php
require_once '../config/database.php';

header('Content-Type: application/json');

if (!isset($_SESSION['user_id']) || $_SESSION['role'] != 'admin') {
    http_response_code(403);
    echo json_encode(['error' => '无权限访问']);
    exit();
}

$course_id = $_GET['course_id'] ?? '';

if (empty($course_id)) {
    echo json_encode([]);
    exit();
}

$stmt = $pdo->prepare("SELECT id, module_name FROM modules WHERE course_id = ? ORDER BY module_name");
$stmt->execute([$course_id]);
$modules = $stmt->fetchAll(PDO::FETCH_ASSOC);

echo json_encode($modules);