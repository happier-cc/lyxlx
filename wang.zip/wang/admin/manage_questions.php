<?php
require_once '../config/database.php';

if (!isset($_SESSION['user_id']) || $_SESSION['role'] != 'admin') {
    header("Location: login.php");
    exit();
}

$selected_project = $_GET['project_id'] ?? 'all';

// 添加题目
if (isset($_POST['add_question'])) {
    $project_id = $_POST['project_id'];
    $question_text = trim($_POST['question_text']);
    $option_a = trim($_POST['option_a']);
    $option_b = trim($_POST['option_b']);
    $option_c = trim($_POST['option_c']);
    $option_d = trim($_POST['option_d']);
    $correct_answer = $_POST['correct_answer'];
    $explanation = trim($_POST['explanation']);
    
    if (!empty($question_text) && !empty($option_a) && !empty($option_b) && !empty($correct_answer)) {
        $stmt = $pdo->prepare("INSERT INTO questions (project_id, question_text, option_a, option_b, option_c, option_d, correct_answer, explanation) VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
        $stmt->execute([$project_id, $question_text, $option_a, $option_b, $option_c, $option_d, $correct_answer, $explanation]);
        $success = "题目添加成功！";
    } else {
        $error = "请填写完整的题目信息！";
    }
}

// 编辑题目
if (isset($_POST['edit_question'])) {
    $question_id = $_POST['question_id'];
    $project_id = $_POST['project_id'];
    $question_text = trim($_POST['question_text']);
    $option_a = trim($_POST['option_a']);
    $option_b = trim($_POST['option_b']);
    $option_c = trim($_POST['option_c']);
    $option_d = trim($_POST['option_d']);
    $correct_answer = $_POST['correct_answer'];
    $explanation = trim($_POST['explanation']);
    
    if (!empty($question_text) && !empty($option_a) && !empty($option_b) && !empty($correct_answer)) {
        $stmt = $pdo->prepare("UPDATE questions SET project_id = ?, question_text = ?, option_a = ?, option_b = ?, option_c = ?, option_d = ?, correct_answer = ?, explanation = ? WHERE id = ?");
        $stmt->execute([$project_id, $question_text, $option_a, $option_b, $option_c, $option_d, $correct_answer, $explanation, $question_id]);
        $success = "题目更新成功！";
    } else {
        $error = "请填写完整的题目信息！";
    }
}

// 删除题目
if (isset($_GET['delete'])) {
    $question_id = $_GET['delete'];
    
    $stmt = $pdo->prepare("DELETE FROM questions WHERE id = ?");
    $stmt->execute([$question_id]);
    $success = "题目删除成功！";
}

// 获取所有项目（包含课程和模块信息）
$projects = $pdo->query("
    SELECT p.*, m.module_name, c.course_name 
    FROM projects p 
    LEFT JOIN modules m ON p.module_id = m.id 
    LEFT JOIN courses c ON m.course_id = c.id 
    ORDER BY c.course_name, m.module_name, p.project_name
")->fetchAll();

// 获取题目
if ($selected_project == 'all') {
    $questions = $pdo->query("
        SELECT q.*, p.project_name, m.module_name, c.course_name 
        FROM questions q 
        JOIN projects p ON q.project_id = p.id 
        JOIN modules m ON p.module_id = m.id 
        JOIN courses c ON m.course_id = c.id 
        ORDER BY c.course_name, m.module_name, p.project_name, q.id
    ")->fetchAll();
} else {
    $questions_stmt = $pdo->prepare("
        SELECT q.*, p.project_name, m.module_name, c.course_name 
        FROM questions q 
        JOIN projects p ON q.project_id = p.id 
        JOIN modules m ON p.module_id = m.id 
        JOIN courses c ON m.course_id = c.id 
        WHERE q.project_id = ? 
        ORDER BY q.id
    ");
    $questions_stmt->execute([$selected_project]);
    $questions = $questions_stmt->fetchAll();
}

// 获取编辑的题目信息
$editing_question = null;
if (isset($_GET['edit'])) {
    $edit_id = $_GET['edit'];
    $stmt = $pdo->prepare("SELECT * FROM questions WHERE id = ?");
    $stmt->execute([$edit_id]);
    $editing_question = $stmt->fetch();
}
?>

<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
    <title>题目管理 - 在线刷题系统</title>
    <link rel="stylesheet" href="../config/style.css">
    <style>
        .filter-section {
            margin-bottom: 24px;
        }
        
        .form-section {
            margin-bottom: 32px;
        }
        
        .options-grid {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 16px;
        }
        
        .question-list {
            display: grid;
            gap: 16px;
        }
        
        .question-item {
            background: white;
            padding: 20px;
            border-radius: 12px;
            box-shadow: var(--shadow);
            border-left: 4px solid var(--primary-color);
        }
        
        .question-header {
            display: flex;
            justify-content: space-between;
            align-items: flex-start;
            margin-bottom: 12px;
        }
        
        .question-text {
            font-weight: 600;
            color: var(--text-primary);
            flex: 1;
        }
        
        .question-actions {
            display: flex;
            gap: 8px;
        }
        
        .options-preview {
            margin: 12px 0;
        }
        
        .option-preview {
            padding: 8px 12px;
            margin-bottom: 4px;
            border-radius: 6px;
            background: var(--bg-tertiary);
        }
        
        .option-correct {
            background: #d1fae5;
            border-left: 3px solid var(--success-color);
        }
        
        .question-meta {
            display: flex;
            gap: 16px;
            font-size: 14px;
            color: var(--text-secondary);
            margin-top: 12px;
        }
        
        .hierarchy-path {
            background: var(--bg-tertiary);
            padding: 6px 12px;
            border-radius: 6px;
            font-size: 13px;
            margin-bottom: 8px;
        }
        
        @media (max-width: 768px) {
            .options-grid {
                grid-template-columns: 1fr;
            }
            
            .question-header {
                flex-direction: column;
                gap: 12px;
            }
            
            .question-actions {
                width: 100%;
                justify-content: flex-start;
            }
        }
    </style>
</head>
<body>
    <nav class="navbar">
        <div class="container">
            <div class="nav-content">
                <a href="index.php" class="nav-brand">← 返回后台</a>
                <span class="nav-brand">题目管理</span>
            </div>
        </div>
    </nav>

    <div class="container">
        <?php if (isset($success)): ?>
            <div class="alert alert-success"><?php echo $success; ?></div>
        <?php endif; ?>
        
        <?php if (isset($error)): ?>
            <div class="alert alert-error"><?php echo $error; ?></div>
        <?php endif; ?>

        <div class="filter-section">
            <div class="card">
                <h3>筛选题目</h3>
                <form method="get">
                    <select name="project_id" class="form-input form-select" onchange="this.form.submit()">
                        <option value="all" <?php echo $selected_project == 'all' ? 'selected' : ''; ?>>所有项目</option>
                        <?php foreach ($projects as $project): ?>
                            <option value="<?php echo $project['id']; ?>" <?php echo $selected_project == $project['id'] ? 'selected' : ''; ?>>
                                <?php echo htmlspecialchars($project['course_name'] . ' / ' . $project['module_name'] . ' / ' . $project['project_name']); ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </form>
                <div class="mt-2">
                    <a href="import_questions.php" class="btn btn-success btn-sm">📥 批量导入</a>
                    <a href="manage_projects.php" class="btn btn-outline btn-sm">🎯 管理项目</a>
                </div>
            </div>
        </div>

        <div class="form-section">
            <div class="card">
                <h2><?php echo $editing_question ? '编辑题目' : '添加新题目'; ?></h2>
                <form method="post">
                    <?php if ($editing_question): ?>
                        <input type="hidden" name="question_id" value="<?php echo $editing_question['id']; ?>">
                    <?php endif; ?>
                    
                    <div class="form-group">
                        <label for="project_id" class="form-label">所属项目：</label>
                        <select id="project_id" name="project_id" class="form-input form-select" required>
                            <option value="">选择项目</option>
                            <?php foreach ($projects as $project): ?>
                                <option value="<?php echo $project['id']; ?>" 
                                    <?php echo ($editing_question['project_id'] ?? '') == $project['id'] ? 'selected' : ''; ?>>
                                    <?php echo htmlspecialchars($project['course_name'] . ' / ' . $project['module_name'] . ' / ' . $project['project_name']); ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    
                    <div class="form-group">
                        <label for="question_text" class="form-label">题目内容：</label>
                        <textarea id="question_text" name="question_text" class="form-input form-textarea" 
                                  placeholder="请输入题目内容" required><?php echo $editing_question ? htmlspecialchars($editing_question['question_text']) : ''; ?></textarea>
                    </div>
                    
                    <div class="options-grid">
                        <div class="form-group">
                            <label for="option_a" class="form-label">选项 A：</label>
                            <input type="text" id="option_a" name="option_a" class="form-input" 
                                   value="<?php echo $editing_question ? htmlspecialchars($editing_question['option_a']) : ''; ?>" 
                                   placeholder="选项A内容" required>
                        </div>
                        
                        <div class="form-group">
                            <label for="option_b" class="form-label">选项 B：</label>
                            <input type="text" id="option_b" name="option_b" class="form-input" 
                                   value="<?php echo $editing_question ? htmlspecialchars($editing_question['option_b']) : ''; ?>" 
                                   placeholder="选项B内容" required>
                        </div>
                        
                        <div class="form-group">
                            <label for="option_c" class="form-label">选项 C：</label>
                            <input type="text" id="option_c" name="option_c" class="form-input" 
                                   value="<?php echo $editing_question ? htmlspecialchars($editing_question['option_c']) : ''; ?>" 
                                   placeholder="选项C内容（可选）">
                        </div>
                        
                        <div class="form-group">
                            <label for="option_d" class="form-label">选项 D：</label>
                            <input type="text" id="option_d" name="option_d" class="form-input" 
                                   value="<?php echo $editing_question ? htmlspecialchars($editing_question['option_d']) : ''; ?>" 
                                   placeholder="选项D内容（可选）">
                        </div>
                    </div>
                    
                    <div class="form-group">
                        <label for="correct_answer" class="form-label">正确答案：</label>
                        <select id="correct_answer" name="correct_answer" class="form-input form-select" required>
                            <option value="">选择正确答案</option>
                            <option value="A" <?php echo ($editing_question['correct_answer'] ?? '') == 'A' ? 'selected' : ''; ?>>A</option>
                            <option value="B" <?php echo ($editing_question['correct_answer'] ?? '') == 'B' ? 'selected' : ''; ?>>B</option>
                            <option value="C" <?php echo ($editing_question['correct_answer'] ?? '') == 'C' ? 'selected' : ''; ?>>C</option>
                            <option value="D" <?php echo ($editing_question['correct_answer'] ?? '') == 'D' ? 'selected' : ''; ?>>D</option>
                        </select>
                    </div>
                    
                    <div class="form-group">
                        <label for="explanation" class="form-label">题目解析：</label>
                        <textarea id="explanation" name="explanation" class="form-input form-textarea" 
                                  placeholder="请输入题目解析（可选）"><?php echo $editing_question ? htmlspecialchars($editing_question['explanation']) : ''; ?></textarea>
                    </div>
                    
                    <div class="form-group">
                        <?php if ($editing_question): ?>
                            <button type="submit" name="edit_question" class="btn btn-primary">更新题目</button>
                            <a href="manage_questions.php?project_id=<?php echo $selected_project; ?>" class="btn btn-outline">取消编辑</a>
                        <?php else: ?>
                            <button type="submit" name="add_question" class="btn btn-primary">添加题目</button>
                        <?php endif; ?>
                    </div>
                </form>
            </div>
        </div>

        <div class="card">
            <h2>题目列表 (<?php echo count($questions); ?> 题)</h2>
            
            <?php if (empty($questions)): ?>
                <div class="text-center" style="padding: 40px; color: var(--text-secondary);">
                    <p>暂无题目</p>
                    <a href="manage_questions.php?action=add" class="btn btn-primary mt-2">添加第一道题目</a>
                </div>
            <?php else: ?>
                <div class="question-list">
                    <?php foreach ($questions as $question): ?>
                        <div class="question-item">
                            <div class="hierarchy-path">
                                📖 <?php echo htmlspecialchars($question['course_name']); ?> 
                                → 📚 <?php echo htmlspecialchars($question['module_name']); ?> 
                                → 🎯 <?php echo htmlspecialchars($question['project_name']); ?>
                            </div>
                            
                            <div class="question-header">
                                <div class="question-text">
                                    <?php echo htmlspecialchars($question['question_text']); ?>
                                </div>
                                <div class="question-actions">
                                    <a href="manage_questions.php?project_id=<?php echo $selected_project; ?>&edit=<?php echo $question['id']; ?>" class="btn btn-outline btn-sm">编辑</a>
                                    <a href="manage_questions.php?project_id=<?php echo $selected_project; ?>&delete=<?php echo $question['id']; ?>" 
                                       class="btn btn-error btn-sm"
                                       onclick="return confirm('确定要删除这个题目吗？')">删除</a>
                                </div>
                            </div>
                            
                            <div class="options-preview">
                                <?php foreach (['A', 'B', 'C', 'D'] as $option): ?>
                                    <?php if (!empty($question['option_' . strtolower($option)])): ?>
                                        <div class="option-preview <?php echo $question['correct_answer'] == $option ? 'option-correct' : ''; ?>">
                                            <strong><?php echo $option; ?>.</strong> 
                                            <?php echo htmlspecialchars($question['option_' . strtolower($option)]); ?>
                                            <?php if ($question['correct_answer'] == $option): ?>
                                                <span style="color: var(--success-color); margin-left: 8px;">✓ 正确答案</span>
                                            <?php endif; ?>
                                        </div>
                                    <?php endif; ?>
                                <?php endforeach; ?>
                            </div>
                            
                            <?php if ($question['explanation']): ?>
                                <div style="background: #fef3c7; padding: 12px; border-radius: 6px; margin-top: 8px;">
                                    <strong>解析：</strong>
                                    <?php echo htmlspecialchars($question['explanation']); ?>
                                </div>
                            <?php endif; ?>
                            
                            <div class="question-meta">
                                <span>项目：<?php echo htmlspecialchars($question['project_name']); ?></span>
                                <span>ID：<?php echo $question['id']; ?></span>
                                <span>创建：<?php echo date('Y-m-d', strtotime($question['created_at'])); ?></span>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>
            <?php endif; ?>
        </div>
    </div>
</body>
</html>