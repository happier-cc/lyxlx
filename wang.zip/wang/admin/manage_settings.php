<?php
require_once '../config/database.php';

if (!isset($_SESSION['user_id']) || $_SESSION['role'] != 'admin') {
    header("Location: login.php");
    exit();
}

$message = '';
$message_type = '';

// 获取当前设置
$settings = [];
try {
    $settings_stmt = $pdo->query("SELECT setting_key, setting_value, description FROM system_settings");
    $settings_data = $settings_stmt->fetchAll();
    foreach ($settings_data as $setting) {
        $settings[$setting['setting_key']] = $setting['setting_value'];
    }
} catch (PDOException $e) {
    $message = "系统设置表不存在，请先运行更新脚本";
    $message_type = 'error';
}

// 处理设置更新
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $registration_enabled = isset($_POST['registration_enabled']) ? '1' : '0';
    $site_enabled = isset($_POST['site_enabled']) ? '1' : '0';
    
    try {
        // 更新注册设置
        $stmt = $pdo->prepare("
            INSERT INTO system_settings (setting_key, setting_value, description) 
            VALUES ('registration_enabled', ?, '用户注册功能开关（1开启，0关闭）')
            ON DUPLICATE KEY UPDATE setting_value = VALUES(setting_value)
        ");
        $stmt->execute([$registration_enabled]);
        
        // 更新网站开关设置
        $stmt = $pdo->prepare("
            INSERT INTO system_settings (setting_key, setting_value, description) 
            VALUES ('site_enabled', ?, '网站开关（1开启，0关闭）')
            ON DUPLICATE KEY UPDATE setting_value = VALUES(setting_value)
        ");
        $stmt->execute([$site_enabled]);
        
        $settings['registration_enabled'] = $registration_enabled;
        $settings['site_enabled'] = $site_enabled;
        $message = "系统设置更新成功！";
        $message_type = 'success';
    } catch (PDOException $e) {
        $message = "更新失败：" . $e->getMessage();
        $message_type = 'error';
    }
}
?>

<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>系统设置 - 在线刷题系统</title>
    <link rel="stylesheet" href="../config/style.css">
    <style>
        .settings-container {
            max-width: 800px;
            margin: 50px auto;
            padding: 30px;
        }
        .settings-section {
            background: white;
            padding: 25px;
            border-radius: 12px;
            margin-bottom: 20px;
            box-shadow: var(--shadow);
        }
        .settings-section h3 {
            margin-top: 0;
            color: var(--primary-color);
            border-bottom: 2px solid var(--border-color);
            padding-bottom: 10px;
        }
        .setting-item {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 15px 0;
            border-bottom: 1px solid var(--border-color);
        }
        .setting-info {
            flex: 1;
        }
        .setting-title {
            font-weight: 600;
            margin-bottom: 5px;
        }
        .setting-desc {
            color: var(--text-secondary);
            font-size: 14px;
        }
        .toggle-switch {
            position: relative;
            display: inline-block;
            width: 60px;
            height: 34px;
        }
        .toggle-switch input {
            opacity: 0;
            width: 0;
            height: 0;
        }
        .toggle-slider {
            position: absolute;
            cursor: pointer;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background-color: #ccc;
            transition: .4s;
            border-radius: 34px;
        }
        .toggle-slider:before {
            position: absolute;
            content: "";
            height: 26px;
            width: 26px;
            left: 4px;
            bottom: 4px;
            background-color: white;
            transition: .4s;
            border-radius: 50%;
        }
        input:checked + .toggle-slider {
            background-color: var(--success-color);
        }
        input:checked + .toggle-slider:before {
            transform: translateX(26px);
        }
        .info-box {
            background: var(--bg-tertiary);
            padding: 20px;
            border-radius: 8px;
            margin-top: 20px;
        }
        .status-badge {
            display: inline-block;
            padding: 4px 12px;
            border-radius: 20px;
            font-size: 12px;
            font-weight: 600;
            margin-left: 10px;
        }
        .status-on {
            background: var(--success-color);
            color: white;
        }
        .status-off {
            background: var(--error-color);
            color: white;
        }
        .warning-box {
            background: #fff3cd;
            border: 1px solid #ffeaa7;
            border-radius: 8px;
            padding: 15px;
            margin: 15px 0;
        }
    </style>
</head>
<body>
    <nav class="navbar">
        <div class="container">
            <div class="nav-content">
                <a href="index.php" class="nav-brand">← 返回后台</a>
                <span class="nav-brand">系统设置</span>
            </div>
        </div>
    </nav>

    <div class="container">
        <div class="settings-container">
            <div class="card">
                <h1>系统设置</h1>
                <p>管理系统功能和配置选项</p>
                
                <?php if ($message): ?>
                    <div class="alert alert-<?php echo $message_type; ?>">
                        <?php echo htmlspecialchars($message); ?>
                    </div>
                <?php endif; ?>

                <?php if (!isset($settings['registration_enabled']) || !isset($settings['site_enabled'])): ?>
                    <div class="alert alert-error">
                        <strong>系统设置表未初始化！</strong>
                        <p>请先运行系统更新脚本以启用设置功能。</p>
                        <a href="../init/update_system_settings.php" class="btn btn-primary mt-2">运行更新脚本</a>
                    </div>
                <?php else: ?>
                    <form method="post">
                        <!-- 网站开关设置 -->
                        <div class="settings-section">
                            <h3>🌐 网站状态设置</h3>
                            
                            <div class="warning-box">
                                <strong>⚠️ 注意：</strong>
                                关闭网站后，所有用户（包括已登录用户）将无法访问系统，只有管理员可以登录后台管理。
                            </div>
                            
                            <div class="setting-item">
                                <div class="setting-info">
                                    <div class="setting-title">
                                        网站访问功能
                                        <span class="status-badge <?php echo $settings['site_enabled'] == '1' ? 'status-on' : 'status-off'; ?>">
                                            <?php echo $settings['site_enabled'] == '1' ? '已开启' : '已关闭'; ?>
                                        </span>
                                    </div>
                                    <div class="setting-desc">
                                        控制整个网站的访问权限。关闭后，所有页面将显示维护信息（管理员除外）。
                                    </div>
                                </div>
                                <label class="toggle-switch">
                                    <input type="checkbox" name="site_enabled" value="1" 
                                           <?php echo $settings['site_enabled'] == '1' ? 'checked' : ''; ?>>
                                    <span class="toggle-slider"></span>
                                </label>
                            </div>
                        </div>

                        <!-- 用户注册设置 -->
                        <div class="settings-section">
                            <h3>🔐 用户注册设置</h3>
                            
                            <div class="setting-item">
                                <div class="setting-info">
                                    <div class="setting-title">
                                        用户注册功能
                                        <span class="status-badge <?php echo $settings['registration_enabled'] == '1' ? 'status-on' : 'status-off'; ?>">
                                            <?php echo $settings['registration_enabled'] == '1' ? '已开启' : '已关闭'; ?>
                                        </span>
                                    </div>
                                    <div class="setting-desc">
                                        控制是否允许新用户注册账号。关闭后，注册页面将显示提示信息。
                                    </div>
                                </div>
                                <label class="toggle-switch">
                                    <input type="checkbox" name="registration_enabled" value="1" 
                                           <?php echo $settings['registration_enabled'] == '1' ? 'checked' : ''; ?>>
                                    <span class="toggle-slider"></span>
                                </label>
                            </div>
                        </div>

                        <div class="settings-section">
                            <h3>💡 设置说明</h3>
                            <div class="info-box">
                                <h4>网站状态功能说明：</h4>
                                <ul>
                                    <li><strong>开启状态</strong>：所有用户可以正常访问系统</li>
                                    <li><strong>关闭状态</strong>：网站显示维护页面，只有管理员可以登录后台</li>
                                    <li>关闭网站不影响管理员后台的访问</li>
                                    <li>适用于系统维护、升级等场景</li>
                                </ul>
                                
                                <h4>用户注册功能说明：</h4>
                                <ul>
                                    <li><strong>开启状态</strong>：允许新用户通过注册页面创建账号</li>
                                    <li><strong>关闭状态</strong>：注册页面将显示维护提示，阻止新用户注册</li>
                                    <li>关闭注册不影响现有用户的正常使用</li>
                                    <li>管理员仍可在后台手动添加用户</li>
                                </ul>
                            </div>
                        </div>

                        <div class="text-center mt-4">
                            <button type="submit" class="btn btn-primary">保存设置</button>
                            <a href="index.php" class="btn btn-outline">取消</a>
                        </div>
                    </form>
                <?php endif; ?>
            </div>
        </div>
    </div>
</body>
</html>