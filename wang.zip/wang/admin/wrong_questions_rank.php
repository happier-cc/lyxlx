<?php
require_once '../config/database.php';

if (!isset($_SESSION['user_id']) || $_SESSION['role'] != 'admin') {
    header("Location: login.php");
    exit();
}

// 获取时间范围参数
$time_range = $_GET['time_range'] ?? 'all';
$course_id = $_GET['course_id'] ?? 'all';
$module_id = $_GET['module_id'] ?? 'all';
$project_id = $_GET['project_id'] ?? 'all';
$rank_by = $_GET['rank_by'] ?? 'rate';

// 首先检查 wrong_questions 表的结构
try {
    $check_table = $pdo->query("DESCRIBE wrong_questions");
    $table_columns = $check_table->fetchAll(PDO::FETCH_COLUMN);
} catch (PDOException $e) {
    die("数据库错误：无法访问 wrong_questions 表");
}

// 根据表结构设置时间条件
if (in_array('created_at', $table_columns)) {
    $time_conditions = [
        'all' => '',
        'today' => "AND wq.created_at >= CURDATE()",
        'week' => "AND wq.created_at >= DATE_SUB(CURDATE(), INTERVAL 7 DAY)",
        'month' => "AND wq.created_at >= DATE_SUB(CURDATE(), INTERVAL 30 DAY)"
    ];
} else {
    $time_conditions = [
        'all' => '',
        'today' => "",
        'week' => "",
        'month' => ""
    ];
}

$time_condition = $time_conditions[$time_range];

// 设置课程、模块、项目条件
$course_condition = '';
if ($course_id != 'all') {
    $course_condition = "AND c.id = " . intval($course_id);
}

$module_condition = '';
if ($module_id != 'all') {
    $module_condition = "AND m.id = " . intval($module_id);
}

$project_condition = '';
if ($project_id != 'all') {
    $project_condition = "AND p.id = " . intval($project_id);
}

// 处理导出请求
if (isset($_GET['export_questions'])) {
    exportWrongQuestionsRank($pdo, $time_range, $course_id, $module_id, $project_id, $rank_by);
    exit();
}

// 获取所有课程、模块和项目（用于筛选）
$courses = $pdo->query("SELECT * FROM courses ORDER BY course_name")->fetchAll();

// 根据选择的课程获取模块
$modules = [];
if (!empty($course_id) && $course_id != 'all') {
    $modules_stmt = $pdo->prepare("SELECT * FROM modules WHERE course_id = ? ORDER BY module_name");
    $modules_stmt->execute([$course_id]);
    $modules = $modules_stmt->fetchAll();
}

// 根据选择的模块获取项目
$projects = [];
if (!empty($module_id) && $module_id != 'all') {
    $projects_stmt = $pdo->prepare("SELECT * FROM projects WHERE module_id = ? ORDER BY project_name");
    $projects_stmt->execute([$module_id]);
    $projects = $projects_stmt->fetchAll();
}

// 1. 获取每个项目的错题排行
$project_rank_sql = "
    SELECT 
        p.id as project_id,
        p.project_name,
        m.module_name,
        c.course_name,
        COUNT(wq.id) as wrong_count,
        COUNT(DISTINCT wq.user_id) as user_count,
        CASE 
            WHEN COUNT(DISTINCT wq.user_id) > 0 
            THEN ROUND(COUNT(wq.id) * 1.0 / COUNT(DISTINCT wq.user_id), 1)
            ELSE 0 
        END as avg_wrong_per_user
    FROM wrong_questions wq
    JOIN projects p ON wq.project_id = p.id
    JOIN modules m ON p.module_id = m.id
    JOIN courses c ON m.course_id = c.id
    WHERE 1=1 {$time_condition} {$course_condition} {$module_condition} {$project_condition}
    GROUP BY p.id, p.project_name, m.module_name, c.course_name
    ORDER BY wrong_count DESC
";

$project_rank_stmt = $pdo->prepare($project_rank_sql);
$project_rank_stmt->execute();
$project_ranks = $project_rank_stmt->fetchAll();

// 2. 获取所有题目的错题排行
$order_by = ($rank_by === 'count') ? "ORDER BY wrong_count DESC" : "ORDER BY wrong_rate DESC, wrong_count DESC";

// 使用更稳定的查询进行题目排行
$question_rank_sql = "
    SELECT 
        q.id as question_id,
        q.question_text,
        q.option_a,
        q.option_b,
        q.option_c,
        q.option_d,
        q.correct_answer,
        q.explanation,
        p.project_name,
        m.module_name,
        c.course_name,
        COUNT(wq.id) as wrong_count,
        COUNT(DISTINCT wq.user_id) as wrong_user_count,
        (
            SELECT COUNT(DISTINCT up.user_id) 
            FROM user_progress up 
            WHERE up.project_id = p.id
            {$time_condition}
        ) as total_attempt_users,
        CASE 
            WHEN (
                SELECT COUNT(DISTINCT up.user_id) 
                FROM user_progress up 
                WHERE up.project_id = p.id
                {$time_condition}
            ) > 0 
            THEN ROUND(
                (COUNT(DISTINCT wq.user_id) * 100.0 / 
                (
                    SELECT COUNT(DISTINCT up.user_id) 
                    FROM user_progress up 
                    WHERE up.project_id = p.id
                    {$time_condition}
                )), 
                1
            )
            ELSE 0 
        END as wrong_rate
    FROM wrong_questions wq
    JOIN questions q ON wq.question_id = q.id
    JOIN projects p ON q.project_id = p.id
    JOIN modules m ON p.module_id = m.id
    JOIN courses c ON m.course_id = c.id
    WHERE 1=1 {$time_condition} {$course_condition} {$module_condition} {$project_condition}
    GROUP BY q.id, q.question_text, q.option_a, q.option_b, q.option_c, q.option_d, q.correct_answer, q.explanation, p.project_name, m.module_name, c.course_name
    HAVING wrong_count > 0 AND total_attempt_users >= 3
    {$order_by}
    LIMIT 50
";

$question_rank_stmt = $pdo->prepare($question_rank_sql);
$question_rank_stmt->execute();
$question_ranks = $question_rank_stmt->fetchAll();

// 3. 获取用户的错题排行 - 修复这里，添加缺失的表关联
$user_rank_sql = "
    SELECT 
        u.id as user_id,
        u.username,
        COUNT(wq.id) as wrong_count,
        COUNT(DISTINCT wq.project_id) as project_count,
        MAX(wq.created_at) as last_wrong_time
    FROM wrong_questions wq
    JOIN users u ON wq.user_id = u.id
    JOIN projects p ON wq.project_id = p.id
    JOIN modules m ON p.module_id = m.id
    JOIN courses c ON m.course_id = c.id
    WHERE u.status = 'active' {$time_condition} {$course_condition} {$module_condition} {$project_condition}
    GROUP BY u.id, u.username
    HAVING wrong_count > 0
    ORDER BY wrong_count DESC
    LIMIT 50
";

$user_rank_stmt = $pdo->prepare($user_rank_sql);
$user_rank_stmt->execute();
$user_ranks = $user_rank_stmt->fetchAll();

// 修复统计信息的查询 - 添加正确的表关联
$total_wrong_sql = "
    SELECT COUNT(*) 
    FROM wrong_questions wq
    JOIN projects p ON wq.project_id = p.id
    JOIN modules m ON p.module_id = m.id
    JOIN courses c ON m.course_id = c.id
    WHERE 1=1 {$time_condition} {$course_condition} {$module_condition} {$project_condition}
";
$total_wrong_count = $pdo->query($total_wrong_sql)->fetchColumn();

$total_users_with_wrong_sql = "
    SELECT COUNT(DISTINCT wq.user_id) 
    FROM wrong_questions wq
    JOIN projects p ON wq.project_id = p.id
    JOIN modules m ON p.module_id = m.id
    JOIN courses c ON m.course_id = c.id
    WHERE 1=1 {$time_condition} {$course_condition} {$module_condition} {$project_condition}
";
$total_users_with_wrong = $pdo->query($total_users_with_wrong_sql)->fetchColumn();

$total_projects_with_wrong_sql = "
    SELECT COUNT(DISTINCT wq.project_id) 
    FROM wrong_questions wq
    JOIN projects p ON wq.project_id = p.id
    JOIN modules m ON p.module_id = m.id
    JOIN courses c ON m.course_id = c.id
    WHERE 1=1 {$time_condition} {$course_condition} {$module_condition} {$project_condition}
";
$total_projects_with_wrong = $pdo->query($total_projects_with_wrong_sql)->fetchColumn();

$avg_wrong_per_user = $total_users_with_wrong > 0 ? round($total_wrong_count / $total_users_with_wrong, 1) : 0;

// 导出函数也需要修复
function exportWrongQuestionsRank($pdo, $time_range, $course_id, $module_id, $project_id, $rank_by) {
    // 检查表结构
    try {
        $check_table = $pdo->query("DESCRIBE wrong_questions");
        $table_columns = $check_table->fetchAll(PDO::FETCH_COLUMN);
    } catch (PDOException $e) {
        die("数据库错误：无法访问 wrong_questions 表");
    }
    
    // 根据表结构设置时间条件
    if (in_array('created_at', $table_columns)) {
        $time_conditions = [
            'all' => '',
            'today' => "AND wq.created_at >= CURDATE()",
            'week' => "AND wq.created_at >= DATE_SUB(CURDATE(), INTERVAL 7 DAY)",
            'month' => "AND wq.created_at >= DATE_SUB(CURDATE(), INTERVAL 30 DAY)"
        ];
    } else {
        $time_conditions = [
            'all' => '',
            'today' => "",
            'week' => "",
            'month' => ""
        ];
    }
    
    $time_condition = $time_conditions[$time_range] ?? '';
    
    // 设置课程、模块、项目条件
    $course_condition = '';
    if ($course_id != 'all') {
        $course_condition = "AND c.id = " . intval($course_id);
    }

    $module_condition = '';
    if ($module_id != 'all') {
        $module_condition = "AND m.id = " . intval($module_id);
    }

    $project_condition = '';
    if ($project_id != 'all') {
        $project_condition = "AND p.id = " . intval($project_id);
    }
    
    // 设置排序方式
    $order_by = ($rank_by === 'count') ? "ORDER BY wrong_count DESC" : "ORDER BY wrong_rate DESC, wrong_count DESC";
    
    // 导出查询
    $export_sql = "
        SELECT 
            q.id as question_id,
            q.question_text,
            q.option_a,
            q.option_b,
            q.option_c,
            q.option_d,
            q.correct_answer,
            q.explanation,
            p.project_name,
            m.module_name,
            c.course_name,
            COUNT(wq.id) as wrong_count,
            COUNT(DISTINCT wq.user_id) as wrong_user_count,
            (
                SELECT COUNT(DISTINCT up.user_id) 
                FROM user_progress up 
                WHERE up.project_id = p.id
                {$time_condition}
            ) as total_attempt_users,
            CASE 
                WHEN (
                    SELECT COUNT(DISTINCT up.user_id) 
                    FROM user_progress up 
                    WHERE up.project_id = p.id
                    {$time_condition}
                ) > 0 
                THEN ROUND(
                    (COUNT(DISTINCT wq.user_id) * 100.0 / 
                    (
                        SELECT COUNT(DISTINCT up.user_id) 
                        FROM user_progress up 
                        WHERE up.project_id = p.id
                        {$time_condition}
                    )), 
                    1
                )
                ELSE 0 
            END as wrong_rate
        FROM wrong_questions wq
        JOIN questions q ON wq.question_id = q.id
        JOIN projects p ON q.project_id = p.id
        JOIN modules m ON p.module_id = m.id
        JOIN courses c ON m.course_id = c.id
        WHERE 1=1 {$time_condition} {$course_condition} {$module_condition} {$project_condition}
        GROUP BY q.id, q.question_text, q.option_a, q.option_b, q.option_c, q.option_d, q.correct_answer, q.explanation, p.project_name, m.module_name, c.course_name
        HAVING wrong_count > 0 AND total_attempt_users >= 3
        {$order_by}
        LIMIT 50
    ";
    
    $stmt = $pdo->prepare($export_sql);
    $stmt->execute();
    $questions = $stmt->fetchAll();
    
    // 设置HTTP头
    header('Content-Type: text/csv; charset=utf-8');
    header('Content-Disposition: attachment; filename="高频错题排行_' . date('Ymd_His') . '.csv"');
    
    // 创建输出流
    $output = fopen('php://output', 'w');
    
    // 添加BOM头，确保Excel正确显示中文
    fwrite($output, "\xEF\xBB\xBF");
    
    // 写入表头
    fputcsv($output, [
        '排名', '题目内容', '选项A', '选项B', '选项C', '选项D', 
        '正确答案', '解析', '课程', '模块', '项目', '错题次数', '错题用户数', '作答用户数', '错误率%'
    ]);
    
    // 写入数据
    foreach ($questions as $index => $question) {
        fputcsv($output, [
            $index + 1,
            $question['question_text'],
            $question['option_a'] ?? '',
            $question['option_b'] ?? '',
            $question['option_c'] ?? '',
            $question['option_d'] ?? '',
            $question['correct_answer'],
            $question['explanation'] ?? '',
            $question['course_name'],
            $question['module_name'],
            $question['project_name'],
            $question['wrong_count'],
            $question['wrong_user_count'],
            $question['total_attempt_users'],
            $question['wrong_rate']
        ]);
    }
    
    fclose($output);
    exit();
}
?>

<!-- 后面的HTML代码保持不变 -->

<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
    <title>错题排行 - 在线刷题系统</title>
    <link rel="stylesheet" href="../config/style.css">
    <style>
        /* 原有的CSS样式保持不变，只添加新的层次路径样式 */
        .hierarchy-path {
            background: var(--bg-tertiary);
            padding: 6px 12px;
            border-radius: 6px;
            font-size: 12px;
            margin-bottom: 8px;
            display: inline-block;
        }
        
        .hierarchy-badge {
            display: inline-block;
            padding: 4px 8px;
            background: var(--bg-tertiary);
            color: var(--text-secondary);
            border-radius: 6px;
            font-size: 12px;
            margin-left: 8px;
        }
        
        /* 其他样式保持不变 */
        .stats-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 16px;
            margin-bottom: 24px;
        }
        
        .stat-card {
            background: white;
            padding: 20px;
            border-radius: 12px;
            box-shadow: var(--shadow);
            text-align: center;
            border-left: 4px solid var(--primary-color);
        }
        
        .stat-number {
            font-size: 32px;
            font-weight: 700;
            color: var(--primary-color);
            margin-bottom: 8px;
        }
        
        .stat-label {
            color: var(--text-secondary);
            font-size: 14px;
        }
        
        .filter-card {
            background: white;
            padding: 20px;
            border-radius: 12px;
            box-shadow: var(--shadow);
            margin-bottom: 24px;
        }
        
        .filter-form {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 16px;
            align-items: end;
        }
        
        .rank-section {
            background: white;
            padding: 24px;
            border-radius: 12px;
            box-shadow: var(--shadow);
            margin-bottom: 24px;
        }
        
        .section-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 16px;
            flex-wrap: wrap;
            gap: 12px;
        }
        
        .section-title {
            font-size: 18px;
            font-weight: 600;
            color: var(--text-primary);
        }
        
        .export-btn {
            background: var(--success-color);
            color: white;
            border: none;
            padding: 8px 16px;
            border-radius: 6px;
            cursor: pointer;
            text-decoration: none;
            display: inline-flex;
            align-items: center;
            gap: 6px;
            font-size: 14px;
        }
        
        .export-btn:hover {
            background: #059669;
        }
        
        .time-warning {
            background: #fef3c7;
            border: 1px solid #fde68a;
            padding: 10px 15px;
            border-radius: 8px;
            margin: 10px 0;
            font-size: 14px;
            color: #92400e;
        }
        
        .rank-table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 16px;
        }
        
        .rank-table th {
            background: var(--bg-primary);
            padding: 12px;
            text-align: left;
            font-weight: 600;
            color: var(--text-primary);
            border-bottom: 2px solid var(--border-color);
        }
        
        .rank-table td {
            padding: 12px;
            border-bottom: 1px solid var(--border-color);
            vertical-align: top;
        }
        
        .rank-table tr:hover {
            background: var(--bg-tertiary);
        }
        
        .rank-number {
            font-weight: 700;
            color: var(--primary-color);
            text-align: center;
            width: 50px;
        }
        
        .rank-1 { color: #ffd700; font-weight: 700; }
        .rank-2 { color: #c0c0c0; font-weight: 700; }
        .rank-3 { color: #cd7f32; font-weight: 700; }
        
        .badge {
            display: inline-block;
            padding: 4px 8px;
            border-radius: 12px;
            font-size: 12px;
            font-weight: 600;
        }
        
        .badge-high { background: #fee2e2; color: #dc2626; }
        .badge-medium { background: #fef3c7; color: #d97706; }
        .badge-low { background: #d1fae5; color: #059669; }
        
        .empty-state {
            text-align: center;
            padding: 40px 20px;
            color: var(--text-secondary);
        }
        
        .time-badge {
            display: inline-block;
            padding: 4px 12px;
            background: var(--primary-color);
            color: white;
            border-radius: 20px;
            font-size: 12px;
            margin-left: 8px;
        }
        
        .question-content {
            max-width: 400px;
        }
        
        .question-text {
            font-weight: 600;
            margin-bottom: 8px;
            color: var(--text-primary);
        }
        
        .question-options {
            font-size: 13px;
            color: var(--text-secondary);
            line-height: 1.4;
        }
        
        .option-item {
            margin: 2px 0;
        }
        
        .correct-answer {
            color: var(--success-color);
            font-weight: 600;
            margin-top: 4px;
            padding: 4px 8px;
            background: #d1fae5;
            border-radius: 4px;
            display: inline-block;
        }
        
        .rate-info {
            font-size: 11px;
            color: var(--text-secondary);
            margin-top: 2px;
        }
        
        .rank-toggle {
            display: flex;
            gap: 8px;
            margin-bottom: 16px;
        }
        
        .rank-toggle-btn {
            padding: 6px 12px;
            border: 1px solid var(--border-color);
            background: white;
            border-radius: 6px;
            cursor: pointer;
            font-size: 13px;
        }
        
        .rank-toggle-btn.active {
            background: var(--primary-color);
            color: white;
            border-color: var(--primary-color);
        }
        
        .rank-toggle-btn:hover:not(.active) {
            background: var(--bg-tertiary);
        }
        
        @media (max-width: 768px) {
            .filter-form {
                grid-template-columns: 1fr;
            }
            
            .stats-grid {
                grid-template-columns: 1fr 1fr;
            }
            
            .rank-table {
                font-size: 14px;
            }
            
            .rank-table th,
            .rank-table td {
                padding: 8px 4px;
            }
            
            .question-content {
                max-width: 250px;
            }
            
            .section-header {
                flex-direction: column;
                align-items: flex-start;
            }
        }
    </style>
</head>
<body>
    <nav class="navbar">
        <div class="container">
            <div class="nav-content">
                <a href="index.php" class="nav-brand">← 返回后台</a>
                <span class="nav-brand">错题排行分析</span>
            </div>
        </div>
    </nav>

    <div class="container">
        <div class="filter-card">
            <h3>筛选条件</h3>
            <form method="get" class="filter-form">
                <div class="form-group">
                    <label class="form-label">时间范围：</label>
                    <select name="time_range" class="form-input">
                        <option value="all" <?php echo $time_range == 'all' ? 'selected' : ''; ?>>全部时间</option>
                        <option value="today" <?php echo $time_range == 'today' ? 'selected' : ''; ?>>今天</option>
                        <option value="week" <?php echo $time_range == 'week' ? 'selected' : ''; ?>>最近7天</option>
                        <option value="month" <?php echo $time_range == 'month' ? 'selected' : ''; ?>>最近30天</option>
                    </select>
                </div>
                
                <div class="form-group">
                    <label class="form-label">课程筛选：</label>
                    <select name="course_id" class="form-input" id="course_id">
                        <option value="all" <?php echo $course_id == 'all' ? 'selected' : ''; ?>>所有课程</option>
                        <?php foreach ($courses as $course): ?>
                            <option value="<?php echo $course['id']; ?>" <?php echo $course_id == $course['id'] ? 'selected' : ''; ?>>
                                <?php echo htmlspecialchars($course['course_name']); ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>
                
                <div class="form-group">
                    <label class="form-label">模块筛选：</label>
                    <select name="module_id" class="form-input" id="module_id">
                        <option value="all" <?php echo $module_id == 'all' ? 'selected' : ''; ?>>所有模块</option>
                        <?php foreach ($modules as $module): ?>
                            <option value="<?php echo $module['id']; ?>" <?php echo $module_id == $module['id'] ? 'selected' : ''; ?>>
                                <?php echo htmlspecialchars($module['module_name']); ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>
                
                <div class="form-group">
                    <label class="form-label">项目筛选：</label>
                    <select name="project_id" class="form-input" id="project_id">
                        <option value="all" <?php echo $project_id == 'all' ? 'selected' : ''; ?>>所有项目</option>
                        <?php foreach ($projects as $project): ?>
                            <option value="<?php echo $project['id']; ?>" <?php echo $project_id == $project['id'] ? 'selected' : ''; ?>>
                                <?php echo htmlspecialchars($project['project_name']); ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>
                
                <input type="hidden" name="rank_by" value="<?php echo $rank_by; ?>">
                
                <div class="form-group">
                    <button type="submit" class="btn btn-primary">应用筛选</button>
                    <a href="wrong_questions_rank.php" class="btn btn-outline">重置</a>
                </div>
            </form>
            
            <?php if (!in_array('created_at', $table_columns)): ?>
                <div class="time-warning">
                    ⚠️ 注意：当前数据库缺少时间字段，时间筛选功能暂时不可用。请使用"全部时间"查看所有数据。
                </div>
            <?php endif; ?>
        </div>

        <!-- 统计信息 -->
        <div class="stats-grid">
            <div class="stat-card">
                <div class="stat-number"><?php echo $total_wrong_count; ?></div>
                <div class="stat-label">总错题数</div>
            </div>
            <div class="stat-card">
                <div class="stat-number"><?php echo $total_users_with_wrong; ?></div>
                <div class="stat-label">有错题用户数</div>
            </div>
            <div class="stat-card">
                <div class="stat-number"><?php echo $total_projects_with_wrong; ?></div>
                <div class="stat-label">涉及项目数</div>
            </div>
            <div class="stat-card">
                <div class="stat-number"><?php echo $avg_wrong_per_user; ?></div>
                <div class="stat-label">人均错题数</div>
            </div>
        </div>

        <!-- 项目错题排行 -->
        <div class="rank-section">
            <h3>
                项目错题排行
                <span class="time-badge"><?php echo getTimeRangeText($time_range); ?></span>
            </h3>
            
            <?php if (empty($project_ranks)): ?>
                <div class="empty-state">
                    <p>暂无错题数据</p>
                </div>
            <?php else: ?>
                <table class="rank-table">
                    <thead>
                        <tr>
                            <th width="60">排名</th>
                            <th>学习路径</th>
                            <th width="100">错题数量</th>
                            <th width="120">错题用户数</th>
                            <th width="120">人均错题数</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($project_ranks as $index => $project): ?>
                            <tr>
                                <td class="rank-number">
                                    <span class="rank-<?php echo $index + 1; ?>">
                                        <?php echo $index + 1; ?>
                                    </span>
                                </td>
                                <td>
                                    <div class="hierarchy-path">
                                        📖 <?php echo htmlspecialchars($project['course_name']); ?> 
                                        → 📚 <?php echo htmlspecialchars($project['module_name']); ?> 
                                        → 🎯 <?php echo htmlspecialchars($project['project_name']); ?>
                                    </div>
                                    <a href="manage_questions.php?project_id=<?php echo $project['project_id']; ?>" class="hierarchy-badge">
                                        查看题目
                                    </a>
                                </td>
                                <td>
                                    <strong><?php echo $project['wrong_count']; ?></strong>
                                    <?php echo getWrongLevelBadge($project['wrong_count']); ?>
                                </td>
                                <td><?php echo $project['user_count']; ?> 人</td>
                                <td><?php echo $project['avg_wrong_per_user']; ?> 题/人</td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            <?php endif; ?>
        </div>

        <!-- 高频错题排行 -->
        <div class="rank-section">
            <div class="section-header">
                <h3>
                    <?php if ($rank_by === 'count'): ?>
                        高频错题排行 (按错题次数 Top 50)
                    <?php else: ?>
                        高错误率题目排行 (按错误率 Top 50)
                    <?php endif; ?>
                    <span class="time-badge"><?php echo getTimeRangeText($time_range); ?></span>
                </h3>
                <div>
                    <div class="rank-toggle">
                        <button type="button" class="rank-toggle-btn <?php echo $rank_by === 'rate' ? 'active' : ''; ?>" 
                                onclick="changeRankType('rate')">按错误率排行</button>
                        <button type="button" class="rank-toggle-btn <?php echo $rank_by === 'count' ? 'active' : ''; ?>" 
                                onclick="changeRankType('count')">按错题次数排行</button>
                    </div>
                    <a href="?export_questions=1&time_range=<?php echo $time_range; ?>&course_id=<?php echo $course_id; ?>&module_id=<?php echo $module_id; ?>&project_id=<?php echo $project_id; ?>&rank_by=<?php echo $rank_by; ?>" 
                       class="export-btn">
                        📥 导出CSV
                    </a>
                </div>
            </div>
            
            <?php if (empty($question_ranks)): ?>
                <div class="empty-state">
                    <p>暂无错题数据</p>
                </div>
            <?php else: ?>
                <table class="rank-table">
                    <thead>
                        <tr>
                            <th width="60">排名</th>
                            <th>题目内容</th>
                            <th width="120">学习路径</th>
                            <th width="100">错题次数</th>
                            <th width="120">错题用户数</th>
                            <th width="120">错误率</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($question_ranks as $index => $question): ?>
                            <tr>
                                <td class="rank-number">
                                    <span class="rank-<?php echo $index + 1; ?>">
                                        <?php echo $index + 1; ?>
                                    </span>
                                </td>
                                <td>
                                    <div class="question-content">
                                        <div class="question-text">
                                            <?php echo htmlspecialchars($question['question_text']); ?>
                                        </div>
                                        <div class="question-options">
                                            <?php if (!empty($question['option_a'])): ?>
                                                <div class="option-item"><strong>A.</strong> <?php echo htmlspecialchars($question['option_a']); ?></div>
                                            <?php endif; ?>
                                            <?php if (!empty($question['option_b'])): ?>
                                                <div class="option-item"><strong>B.</strong> <?php echo htmlspecialchars($question['option_b']); ?></div>
                                            <?php endif; ?>
                                            <?php if (!empty($question['option_c'])): ?>
                                                <div class="option-item"><strong>C.</strong> <?php echo htmlspecialchars($question['option_c']); ?></div>
                                            <?php endif; ?>
                                            <?php if (!empty($question['option_d'])): ?>
                                                <div class="option-item"><strong>D.</strong> <?php echo htmlspecialchars($question['option_d']); ?></div>
                                            <?php endif; ?>
                                        </div>
                                        <div class="correct-answer">
                                            正确答案: <?php echo $question['correct_answer']; ?>
                                        </div>
                                        <?php if (!empty($question['explanation'])): ?>
                                            <div style="margin-top: 4px; font-size: 12px; color: var(--text-secondary);">
                                                <strong>解析:</strong> <?php echo htmlspecialchars($question['explanation']); ?>
                                            </div>
                                        <?php endif; ?>
                                    </div>
                                </td>
                                <td>
                                    <div class="hierarchy-path">
                                        📖 <?php echo htmlspecialchars($question['course_name']); ?><br>
                                        📚 <?php echo htmlspecialchars($question['module_name']); ?><br>
                                        🎯 <?php echo htmlspecialchars($question['project_name']); ?>
                                    </div>
                                </td>
                                <td>
                                    <strong><?php echo $question['wrong_count']; ?></strong>
                                    <?php echo getWrongLevelBadge($question['wrong_count']); ?>
                                </td>
                                <td>
                                    <?php echo $question['wrong_user_count']; ?> 人
                                    <?php if (isset($question['total_attempt_users']) && $question['total_attempt_users'] > 0): ?>
                                        <div class="rate-info">
                                            / <?php echo $question['total_attempt_users']; ?> 人作答
                                        </div>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <span class="badge <?php echo getWrongRateBadgeClass($question['wrong_rate']); ?>">
                                        <?php echo $question['wrong_rate']; ?>%
                                    </span>
                                    <?php if (isset($question['total_attempt_users']) && $question['total_attempt_users'] > 0): ?>
                                        <div class="rate-info">
                                            <?php echo $question['wrong_user_count']; ?>/<?php echo $question['total_attempt_users']; ?>
                                        </div>
                                    <?php endif; ?>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            <?php endif; ?>
        </div>

        <!-- 用户错题排行 -->
        <div class="rank-section">
            <h3>
                用户错题排行 (Top 50)
                <span class="time-badge"><?php echo getTimeRangeText($time_range); ?></span>
            </h3>
            
            <?php if (empty($user_ranks)): ?>
                <div class="empty-state">
                    <p>暂无用户错题数据</p>
                </div>
            <?php else: ?>
                <table class="rank-table">
                    <thead>
                        <tr>
                            <th width="60">排名</th>
                            <th>用户名</th>
                            <th width="100">错题数量</th>
                            <th width="120">涉及项目数</th>
                            <th width="150">最后错题时间</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($user_ranks as $index => $user): ?>
                            <tr>
                                <td class="rank-number">
                                    <span class="rank-<?php echo $index + 1; ?>">
                                        <?php echo $index + 1; ?>
                                    </span>
                                </td>
                                <td>
                                    <?php echo htmlspecialchars($user['username']); ?>
                                    <a href="../user/profile.php?user_id=<?php echo $user['user_id']; ?>" class="hierarchy-badge">
                                        查看详情
                                    </a>
                                </td>
                                <td>
                                    <strong><?php echo $user['wrong_count']; ?></strong>
                                    <?php echo getWrongLevelBadge($user['wrong_count']); ?>
                                </td>
                                <td><?php echo $user['project_count']; ?> 个</td>
                                <td>
                                    <?php echo $user['last_wrong_time'] ? date('m-d H:i', strtotime($user['last_wrong_time'])) : '无'; ?>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            <?php endif; ?>
        </div>

        <div class="card">
            <h3>数据说明</h3>
            <ul style="color: var(--text-secondary); line-height: 1.6;">
                <li><strong>项目错题排行：</strong>按项目统计错题数量，帮助识别难点项目</li>
                <li><strong>高错误率题目排行：</strong>统计错误率最高的题目，错误率 = 错题人数 ÷ 做过该题的人数 × 100%</li>
                <li><strong>高频错题排行：</strong>统计被做错次数最多的题目，反映题目的影响范围</li>
                <li><strong>用户错题排行：</strong>统计错题数量最多的用户，帮助识别需要重点关注的学生</li>
                <li><strong>导出功能：</strong>可将题目排行导出为CSV文件，方便进一步分析</li>
                <li>数据实时更新，可根据时间范围、课程、模块和项目进行筛选</li>
                <li>建议教师根据排行数据针对性地进行教学调整</li>
            </ul>
        </div>
    </div>

    <script>
        function changeRankType(type) {
            const url = new URL(window.location.href);
            url.searchParams.set('rank_by', type);
            window.location.href = url.toString();
        }

        // 动态加载模块和项目
        document.getElementById('course_id').addEventListener('change', function() {
            var courseId = this.value;
            var moduleSelect = document.getElementById('module_id');
            var projectSelect = document.getElementById('project_id');
            
            // 重置模块和项目
            moduleSelect.innerHTML = '<option value="all">所有模块</option>';
            projectSelect.innerHTML = '<option value="all">所有项目</option>';
            
            if (courseId && courseId !== 'all') {
                fetch('get_modules.php?course_id=' + courseId)
                    .then(response => response.json())
                    .then(modules => {
                        modules.forEach(module => {
                            var option = document.createElement('option');
                            option.value = module.id;
                            option.textContent = module.module_name;
                            moduleSelect.appendChild(option);
                        });
                    });
            }
        });

        document.getElementById('module_id').addEventListener('change', function() {
            var moduleId = this.value;
            var projectSelect = document.getElementById('project_id');
            
            // 重置项目
            projectSelect.innerHTML = '<option value="all">所有项目</option>';
            
            if (moduleId && moduleId !== 'all') {
                fetch('get_projects.php?module_id=' + moduleId)
                    .then(response => response.json())
                    .then(projects => {
                        projects.forEach(project => {
                            var option = document.createElement('option');
                            option.value = project.id;
                            option.textContent = project.project_name;
                            projectSelect.appendChild(option);
                        });
                    });
            }
        });
    </script>
</body>
</html>

<?php
// 辅助函数：获取时间范围文本
function getTimeRangeText($time_range) {
    $texts = [
        'all' => '全部时间',
        'today' => '今天',
        'week' => '最近7天',
        'month' => '最近30天'
    ];
    return $texts[$time_range] ?? '全部时间';
}

// 辅助函数：获取错题数量级别徽章
function getWrongLevelBadge($count) {
    if ($count >= 50) {
        return '<span class="badge badge-high">高频</span>';
    } elseif ($count >= 20) {
        return '<span class="badge badge-medium">中频</span>';
    } else {
        return '<span class="badge badge-low">低频</span>';
    }
}

// 辅助函数：获取错误率徽章类名
function getWrongRateBadgeClass($rate) {
    if ($rate >= 30) {
        return 'badge-high';
    } elseif ($rate >= 15) {
        return 'badge-medium';
    } else {
        return 'badge-low';
    }
}