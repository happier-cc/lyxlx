<?php
require_once '../config/database.php';

if (!isset($_SESSION['user_id']) || $_SESSION['role'] != 'admin') {
    header("Location: login.php");
    exit();
}

// 检查表是否存在
function tableExists($pdo, $tableName) {
    try {
        $result = $pdo->query("SELECT 1 FROM $tableName LIMIT 1");
        return true;
    } catch (Exception $e) {
        return false;
    }
}

$user_study_history_exists = tableExists($pdo, 'user_study_history');
$user_progress_exists = tableExists($pdo, 'user_progress');
$wrong_questions_exists = tableExists($pdo, 'wrong_questions');
$favorite_questions_exists = tableExists($pdo, 'favorite_questions');

// 获取筛选条件
$user_id = $_GET['user_id'] ?? '';
$course_id = $_GET['course_id'] ?? '';
$module_id = $_GET['module_id'] ?? '';
$project_id = $_GET['project_id'] ?? '';
$date_range = $_GET['date_range'] ?? '';
$record_type = $_GET['record_type'] ?? 'current'; // 默认为当前进度

// 如果历史记录表不存在，强制使用当前进度
if (!$user_study_history_exists && $record_type === 'history') {
    $record_type = 'current';
}

// 构建查询条件
$where_conditions = [];
$params = [];

if (!empty($user_id)) {
    $where_conditions[] = "u.id = ?";
    $params[] = $user_id;
}

if (!empty($course_id)) {
    $where_conditions[] = "c.id = ?";
    $params[] = $course_id;
}

if (!empty($module_id)) {
    $where_conditions[] = "m.id = ?";
    $params[] = $module_id;
}

if (!empty($project_id)) {
    $where_conditions[] = "p.id = ?";
    $params[] = $project_id;
}

// 根据记录类型选择正确的表别名
$table_alias = ($record_type === 'current') ? 'up' : 'ush';

if (!empty($date_range)) {
    switch ($date_range) {
        case 'today':
            $where_conditions[] = "DATE({$table_alias}.completed_at) = CURDATE()";
            break;
        case 'week':
            $where_conditions[] = "{$table_alias}.completed_at >= DATE_SUB(CURDATE(), INTERVAL 7 DAY)";
            break;
        case 'month':
            $where_conditions[] = "{$table_alias}.completed_at >= DATE_SUB(CURDATE(), INTERVAL 30 DAY)";
            break;
    }
}

$where_sql = '';
if (!empty($where_conditions)) {
    $where_sql = "WHERE " . implode(" AND ", $where_conditions);
}

// 初始化变量
$study_records = [];
$message = '';
$message_type = '';

// 根据记录类型选择数据源
if ($record_type === 'current') {
    // 查看当前进度（每个用户每个项目的最新记录）
    if ($user_progress_exists) {
        $study_records_sql = "
            SELECT 
                u.id as user_id,
                u.username,
                p.id as project_id,
                p.project_name,
                m.id as module_id,
                m.module_name,
                c.id as course_id,
                c.course_name,
                up.score,
                up.completed_at,
                up.started_at,
                up.study_duration,
                up.attempt_count,
                '当前进度' as record_type,
                (SELECT COUNT(*) FROM questions q WHERE q.project_id = p.id) as total_questions,
                " . ($wrong_questions_exists ? "(SELECT COUNT(*) FROM wrong_questions wq WHERE wq.user_id = u.id AND wq.project_id = p.id) as wrong_count" : "0 as wrong_count") . ",
                " . ($favorite_questions_exists ? "(SELECT COUNT(*) FROM favorite_questions fq WHERE fq.user_id = u.id AND fq.project_id = p.id) as favorite_count" : "0 as favorite_count") . "
            FROM user_progress up
            JOIN users u ON up.user_id = u.id
            JOIN projects p ON up.project_id = p.id
            JOIN modules m ON p.module_id = m.id
            JOIN courses c ON m.course_id = c.id
            $where_sql
            ORDER BY up.completed_at DESC
        ";
    } else {
        $message = "用户进度表不存在，请先创建 user_progress 表";
        $message_type = 'error';
    }
} else {
    // 查看历史记录（所有学习记录）
    if ($user_study_history_exists) {
        $study_records_sql = "
            SELECT 
                u.id as user_id,
                u.username,
                p.id as project_id,
                p.project_name,
                m.id as module_id,
                m.module_name,
                c.id as course_id,
                c.course_name,
                ush.score,
                ush.completed_at,
                ush.study_duration,
                ush.id as history_id,
                '历史记录' as record_type,
                (SELECT COUNT(*) FROM questions q WHERE q.project_id = p.id) as total_questions,
                " . ($wrong_questions_exists ? "(SELECT COUNT(*) FROM wrong_questions wq WHERE wq.user_id = u.id AND wq.project_id = p.id) as wrong_count" : "0 as wrong_count") . ",
                " . ($favorite_questions_exists ? "(SELECT COUNT(*) FROM favorite_questions fq WHERE fq.user_id = u.id AND fq.project_id = p.id) as favorite_count" : "0 as favorite_count") . "
            FROM user_study_history ush
            JOIN users u ON ush.user_id = u.id
            JOIN projects p ON ush.project_id = p.id
            JOIN modules m ON p.module_id = m.id
            JOIN courses c ON m.course_id = c.id
            $where_sql
            ORDER BY ush.completed_at DESC
        ";
    } else {
        $message = "用户学习历史表不存在，请先创建 user_study_history 表";
        $message_type = 'error';
    }
}

// 执行查询
if (isset($study_records_sql)) {
    try {
        $study_stmt = $pdo->prepare($study_records_sql);
        $study_stmt->execute($params);
        $study_records = $study_stmt->fetchAll();
    } catch (PDOException $e) {
        $message = "查询失败: " . $e->getMessage();
        $message_type = 'error';
    }
}

// 获取所有用户和课程（用于筛选）
$users = $pdo->query("SELECT id, username FROM users ORDER BY username")->fetchAll();
$courses = $pdo->query("SELECT id, course_name FROM courses ORDER BY course_name")->fetchAll();

// 根据选择的课程获取模块
$modules = [];
if (!empty($course_id)) {
    $modules_stmt = $pdo->prepare("SELECT id, module_name FROM modules WHERE course_id = ? ORDER BY module_name");
    $modules_stmt->execute([$course_id]);
    $modules = $modules_stmt->fetchAll();
}

// 根据选择的模块获取项目
$projects = [];
if (!empty($module_id)) {
    $projects_stmt = $pdo->prepare("SELECT id, project_name FROM projects WHERE module_id = ? ORDER BY project_name");
    $projects_stmt->execute([$module_id]);
    $projects = $projects_stmt->fetchAll();
}

// 统计信息
$total_records = count($study_records);
$unique_users = $total_records > 0 ? count(array_unique(array_column($study_records, 'user_id'))) : 0;
$unique_projects = $total_records > 0 ? count(array_unique(array_column($study_records, 'project_id'))) : 0;
$avg_score = $total_records > 0 ? round(array_sum(array_column($study_records, 'score')) / $total_records, 1) : 0;
$total_study_time = $total_records > 0 ? array_sum(array_column($study_records, 'study_duration')) : 0;
$avg_study_time = $total_records > 0 ? round($total_study_time / $total_records, 1) : 0;

// 统计尝试次数（仅对当前进度有效）
$total_attempts = 0;
if ($record_type === 'current' && $total_records > 0) {
    $total_attempts = array_sum(array_column($study_records, 'attempt_count'));
} else {
    $total_attempts = $total_records;
}
?>

<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>用户学习记录 - 在线刷题系统</title>
    <link rel="stylesheet" href="../config/style.css">
    <style>
        .study-container {
            max-width: 1400px;
            margin: 50px auto;
            padding: 30px;
        }
        .filter-section {
            background: white;
            padding: 25px;
            border-radius: 12px;
            margin-bottom: 20px;
            box-shadow: var(--shadow);
        }
        .filter-row {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 16px;
            margin-bottom: 16px;
        }
        .stats-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(150px, 1fr));
            gap: 16px;
            margin: 24px 0;
        }
        .stat-card {
            background: white;
            padding: 20px;
            border-radius: 12px;
            text-align: center;
            box-shadow: var(--shadow);
            border-left: 4px solid var(--primary-color);
        }
        .stat-number {
            font-size: 24px;
            font-weight: 700;
            color: var(--primary-color);
            margin-bottom: 8px;
        }
        .records-table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
            background: white;
            border-radius: 12px;
            overflow: hidden;
            box-shadow: var(--shadow);
        }
        .records-table th,
        .records-table td {
            padding: 12px;
            text-align: left;
            border-bottom: 1px solid var(--border-color);
        }
        .records-table th {
            background: var(--bg-tertiary);
            font-weight: 600;
        }
        .records-table tr:hover {
            background: #f8f9fa;
        }
        .score-badge {
            padding: 4px 8px;
            border-radius: 12px;
            font-size: 12px;
            font-weight: 600;
        }
        .score-excellent {
            background: #d1fae5;
            color: #065f46;
        }
        .score-good {
            background: #fef3c7;
            color: #92400e;
        }
        .score-poor {
            background: #fee2e2;
            color: #991b1b;
        }
        .time-badge {
            padding: 4px 8px;
            border-radius: 12px;
            font-size: 12px;
            font-weight: 600;
            background: #e3f2fd;
            color: #1976d2;
        }
        .empty-state {
            text-align: center;
            padding: 60px 20px;
            color: var(--text-secondary);
        }
        .export-buttons {
            display: flex;
            gap: 10px;
            margin: 20px 0;
            flex-wrap: wrap;
        }
        .progress-cell {
            min-width: 120px;
        }
        .progress-bar {
            height: 8px;
            background: var(--bg-tertiary);
            border-radius: 4px;
            overflow: hidden;
            margin: 4px 0;
        }
        .progress-fill {
            height: 100%;
            background: linear-gradient(135deg, var(--primary-color), var(--secondary-color));
        }
        .time-info {
            font-size: 12px;
            color: var(--text-secondary);
            margin-top: 4px;
        }
        .duration-fast {
            background: #d1fae5;
            color: #065f46;
        }
        .duration-normal {
            background: #fef3c7;
            color: #92400e;
        }
        .duration-slow {
            background: #fee2e2;
            color: #991b1b;
        }
        .record-type-badge {
            padding: 4px 8px;
            border-radius: 12px;
            font-size: 11px;
            font-weight: 600;
        }
        .record-current {
            background: #d1fae5;
            color: #065f46;
        }
        .record-history {
            background: #e3f2fd;
            color: #1976d2;
        }
        .attempt-badge {
            padding: 4px 8px;
            border-radius: 12px;
            font-size: 11px;
            font-weight: 600;
            background: #f3e8ff;
            color: #7c3aed;
        }
        .hierarchy-path {
            background: var(--bg-tertiary);
            padding: 6px 12px;
            border-radius: 6px;
            font-size: 12px;
            margin-bottom: 8px;
            display: inline-block;
        }
        .table-status {
            background: #fff3cd;
            border: 1px solid #ffeaa7;
            border-radius: 8px;
            padding: 15px;
            margin: 15px 0;
        }
        @media (max-width: 768px) {
            .records-table {
                font-size: 14px;
            }
            .records-table th,
            .records-table td {
                padding: 8px 4px;
            }
            .filter-row {
                grid-template-columns: 1fr;
            }
        }
    </style>
</head>
<body>
    <nav class="navbar">
        <div class="container">
            <div class="nav-content">
                <a href="index.php" class="nav-brand">← 返回后台</a>
                <span class="nav-brand">用户学习记录</span>
            </div>
        </div>
    </nav>

    <div class="container">
        <div class="study-container">
            <div class="card">
                <h1>用户学习记录</h1>
                <p>查看所有用户的学习进度和刷题情况</p>

                <!-- 表状态提示 -->
                <?php if (!$user_study_history_exists || !$user_progress_exists): ?>
                <div class="table-status">
                    <h4>⚠️ 数据库表状态</h4>
                    <p>以下表不存在，可能会影响功能：</p>
                    <ul>
                        <?php if (!$user_study_history_exists): ?>
                            <li><code>user_study_history</code> - 用户学习历史记录表</li>
                        <?php endif; ?>
                        <?php if (!$user_progress_exists): ?>
                            <li><code>user_progress</code> - 用户进度表</li>
                        <?php endif; ?>
                    </ul>
                    <p>请执行SQL语句创建这些表。</p>
                </div>
                <?php endif; ?>

                <?php if ($message): ?>
                    <div class="alert alert-<?php echo $message_type; ?>">
                        <?php echo $message; ?>
                    </div>
                <?php endif; ?>

                <!-- 筛选表单 -->
                <div class="filter-section">
                    <h3>筛选条件</h3>
                    <form method="get">
                        <div class="filter-row">
                            <div class="form-group">
                                <label for="user_id">选择用户：</label>
                                <select id="user_id" name="user_id" class="form-input">
                                    <option value="">所有用户</option>
                                    <?php foreach ($users as $user): ?>
                                        <option value="<?php echo $user['id']; ?>" <?php echo $user_id == $user['id'] ? 'selected' : ''; ?>>
                                            <?php echo htmlspecialchars($user['username']); ?>
                                        </option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                            <div class="form-group">
                                <label for="course_id">选择课程：</label>
                                <select id="course_id" name="course_id" class="form-input">
                                    <option value="">所有课程</option>
                                    <?php foreach ($courses as $course): ?>
                                        <option value="<?php echo $course['id']; ?>" <?php echo $course_id == $course['id'] ? 'selected' : ''; ?>>
                                            <?php echo htmlspecialchars($course['course_name']); ?>
                                        </option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                            <div class="form-group">
                                <label for="module_id">选择模块：</label>
                                <select id="module_id" name="module_id" class="form-input">
                                    <option value="">所有模块</option>
                                    <?php foreach ($modules as $module): ?>
                                        <option value="<?php echo $module['id']; ?>" <?php echo $module_id == $module['id'] ? 'selected' : ''; ?>>
                                            <?php echo htmlspecialchars($module['module_name']); ?>
                                        </option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                            <div class="form-group">
                                <label for="project_id">选择项目：</label>
                                <select id="project_id" name="project_id" class="form-input">
                                    <option value="">所有项目</option>
                                    <?php foreach ($projects as $project): ?>
                                        <option value="<?php echo $project['id']; ?>" <?php echo $project_id == $project['id'] ? 'selected' : ''; ?>>
                                            <?php echo htmlspecialchars($project['project_name']); ?>
                                        </option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                            <div class="form-group">
                                <label for="date_range">时间范围：</label>
                                <select id="date_range" name="date_range" class="form-input">
                                    <option value="">所有时间</option>
                                    <option value="today" <?php echo $date_range == 'today' ? 'selected' : ''; ?>>今天</option>
                                    <option value="week" <?php echo $date_range == 'week' ? 'selected' : ''; ?>>最近7天</option>
                                    <option value="month" <?php echo $date_range == 'month' ? 'selected' : ''; ?>>最近30天</option>
                                </select>
                            </div>
                            <div class="form-group">
                                <label for="record_type">记录类型：</label>
                                <select id="record_type" name="record_type" class="form-input" <?php echo !$user_study_history_exists ? 'disabled' : ''; ?>>
                                    <option value="current" <?php echo $record_type == 'current' ? 'selected' : ''; ?>>当前进度（最新记录）</option>
                                    <option value="history" <?php echo $record_type == 'history' && $user_study_history_exists ? 'selected' : ''; ?>>历史记录（所有尝试）</option>
                                </select>
                                <?php if (!$user_study_history_exists): ?>
                                    <small style="color: var(--error-color);">历史记录功能不可用，请先创建 user_study_history 表</small>
                                <?php endif; ?>
                            </div>
                        </div>
                        <div class="form-group">
                            <button type="submit" class="btn btn-primary">筛选</button>
                            <a href="user_study_records.php" class="btn btn-outline">重置</a>
                        </div>
                    </form>
                </div>

                <!-- 统计信息 -->
                <?php if ($total_records > 0): ?>
                <div class="stats-grid">
                    <div class="stat-card">
                        <div class="stat-number"><?php echo $total_records; ?></div>
                        <div><?php echo $record_type === 'current' ? '进度记录' : '历史记录'; ?></div>
                    </div>
                    <div class="stat-card">
                        <div class="stat-number"><?php echo $unique_users; ?></div>
                        <div>活跃用户</div>
                    </div>
                    <div class="stat-card">
                        <div class="stat-number"><?php echo $unique_projects; ?></div>
                        <div>涉及项目</div>
                    </div>
                    <div class="stat-card">
                        <div class="stat-number"><?php echo $avg_score; ?>分</div>
                        <div>平均得分</div>
                    </div>
                    <div class="stat-card">
                        <div class="stat-number"><?php echo $avg_study_time; ?>分</div>
                        <div>平均用时</div>
                    </div>
                    <?php if ($record_type === 'current'): ?>
                    <div class="stat-card">
                        <div class="stat-number"><?php echo $total_attempts; ?></div>
                        <div>总尝试次数</div>
                    </div>
                    <?php endif; ?>
                </div>
                <?php endif; ?>

                <!-- 导出按钮 -->
                <div class="export-buttons">
                    <?php if ($total_records > 0): ?>
                    <a href="export_study_records.php?<?php echo http_build_query($_GET); ?>" class="btn btn-success">
                        📊 导出学习记录
                    </a>
                    <?php endif; ?>
                    <a href="user_study_summary.php" class="btn btn-primary">
                        👥 用户学习汇总
                    </a>
                </div>

                <!-- 学习记录表格 -->
                <?php if (empty($study_records)): ?>
                    <div class="empty-state">
                        <div style="font-size: 64px; margin-bottom: 20px;">📚</div>
                        <h3>暂无学习记录</h3>
                        <p>没有找到符合筛选条件的学习记录</p>
                        <?php if (!$user_progress_exists && $record_type === 'current'): ?>
                            <p style="color: var(--error-color); margin-top: 10px;">
                                用户进度表不存在，无法显示当前进度记录
                            </p>
                        <?php endif; ?>
                    </div>
                <?php else: ?>
                    <div style="overflow-x: auto;">
                        <table class="records-table">
                            <thead>
                                <tr>
                                    <th>记录类型</th>
                                    <th>用户</th>
                                    <th>学习路径</th>
                                    <th>得分</th>
                                    <th>题目进度</th>
                                    <th>错题数</th>
                                    <th>收藏数</th>
                                    <th>学习时长</th>
                                    <th>完成时间</th>
                                    <?php if ($record_type === 'current'): ?>
                                    <th>尝试次数</th>
                                    <?php endif; ?>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($study_records as $record): 
                                    $score_class = '';
                                    if ($record['score'] >= 80) {
                                        $score_class = 'score-excellent';
                                    } elseif ($record['score'] >= 60) {
                                        $score_class = 'score-good';
                                    } else {
                                        $score_class = 'score-poor';
                                    }
                                    
                                    $duration_class = '';
                                    if ($record['study_duration'] <= 15) {
                                        $duration_class = 'duration-fast';
                                    } elseif ($record['study_duration'] <= 30) {
                                        $duration_class = 'duration-normal';
                                    } else {
                                        $duration_class = 'duration-slow';
                                    }
                                ?>
                                    <tr>
                                        <td>
                                            <span class="record-type-badge record-<?php echo $record_type; ?>">
                                                <?php echo $record['record_type']; ?>
                                            </span>
                                        </td>
                                        <td>
                                            <strong><?php echo htmlspecialchars($record['username']); ?></strong>
                                            <br><small>ID: <?php echo $record['user_id']; ?></small>
                                        </td>
                                        <td>
                                            <div class="hierarchy-path">
                                                📖 <?php echo htmlspecialchars($record['course_name']); ?> 
                                                → 📚 <?php echo htmlspecialchars($record['module_name']); ?> 
                                                → 🎯 <?php echo htmlspecialchars($record['project_name']); ?>
                                            </div>
                                            <small>
                                                课程ID: <?php echo $record['course_id']; ?> |
                                                模块ID: <?php echo $record['module_id']; ?> |
                                                项目ID: <?php echo $record['project_id']; ?>
                                            </small>
                                        </td>
                                        <td>
                                            <span class="score-badge <?php echo $score_class; ?>">
                                                <?php echo $record['score']; ?>分
                                            </span>
                                        </td>
                                        <td class="progress-cell">
                                            <div><?php echo $record['total_questions']; ?> 题</div>
                                            <div class="progress-bar">
                                                <div class="progress-fill" style="width: 100%"></div>
                                            </div>
                                            <small>已完成</small>
                                        </td>
                                        <td>
                                            <?php if ($record['wrong_count'] > 0): ?>
                                                <span style="color: var(--error-color);"><?php echo $record['wrong_count']; ?> 题</span>
                                            <?php else: ?>
                                                <span style="color: var(--success-color);">0 题</span>
                                            <?php endif; ?>
                                        </td>
                                        <td>
                                            <?php if ($record['favorite_count'] > 0): ?>
                                                <span style="color: #e74c3c;"><?php echo $record['favorite_count']; ?> 题</span>
                                            <?php else: ?>
                                                <span>0 题</span>
                                            <?php endif; ?>
                                        </td>
                                        <td>
                                            <span class="time-badge <?php echo $duration_class; ?>">
                                                <?php echo $record['study_duration']; ?> 分钟
                                            </span>
                                        </td>
                                        <td>
                                            <?php if ($record['completed_at']): ?>
                                                <?php echo date('Y-m-d H:i', strtotime($record['completed_at'])); ?>
                                                <div class="time-info">
                                                    <?php echo date('m-d', strtotime($record['completed_at'])); ?>
                                                </div>
                                            <?php else: ?>
                                                <span style="color: var(--text-secondary);">-</span>
                                            <?php endif; ?>
                                        </td>
                                        <?php if ($record_type === 'current' && isset($record['attempt_count'])): ?>
                                        <td>
                                            <span class="attempt-badge">
                                                <?php echo $record['attempt_count']; ?> 次
                                            </span>
                                        </td>
                                        <?php endif; ?>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>

                    <!-- 分页信息 -->
                    <div style="margin-top: 20px; text-align: center; color: var(--text-secondary);">
                        共 <?php echo $total_records; ?> 条记录，
                        <?php if ($record_type === 'current'): ?>
                            总尝试次数 <?php echo $total_attempts; ?> 次，
                        <?php endif; ?>
                        总学习时长 <?php echo round($total_study_time / 60, 1); ?> 小时
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <script>
        // 动态加载模块和项目
        document.getElementById('course_id').addEventListener('change', function() {
            var courseId = this.value;
            var moduleSelect = document.getElementById('module_id');
            var projectSelect = document.getElementById('project_id');
            
            // 重置模块和项目
            moduleSelect.innerHTML = '<option value="">所有模块</option>';
            projectSelect.innerHTML = '<option value="">所有项目</option>';
            
            if (courseId) {
                fetch('get_modules.php?course_id=' + courseId)
                    .then(response => response.json())
                    .then(modules => {
                        modules.forEach(module => {
                            var option = document.createElement('option');
                            option.value = module.id;
                            option.textContent = module.module_name;
                            moduleSelect.appendChild(option);
                        });
                    });
            }
        });

        document.getElementById('module_id').addEventListener('change', function() {
            var moduleId = this.value;
            var projectSelect = document.getElementById('project_id');
            
            // 重置项目
            projectSelect.innerHTML = '<option value="">所有项目</option>';
            
            if (moduleId) {
                fetch('get_projects.php?module_id=' + moduleId)
                    .then(response => response.json())
                    .then(projects => {
                        projects.forEach(project => {
                            var option = document.createElement('option');
                            option.value = project.id;
                            option.textContent = project.project_name;
                            projectSelect.appendChild(option);
                        });
                    });
            }
        });
    </script>
</body>
</html>