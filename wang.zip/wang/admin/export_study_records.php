<?php
require_once '../config/database.php';

if (!isset($_SESSION['user_id']) || $_SESSION['role'] != 'admin') {
    header("Location: login.php");
    exit();
}

// 检查表是否存在
function tableExists($pdo, $tableName) {
    try {
        $result = $pdo->query("SELECT 1 FROM $tableName LIMIT 1");
        return true;
    } catch (Exception $e) {
        return false;
    }
}

$user_study_history_exists = tableExists($pdo, 'user_study_history');
$user_progress_exists = tableExists($pdo, 'user_progress');

// 获取筛选条件
$user_id = $_GET['user_id'] ?? '';
$course_id = $_GET['course_id'] ?? '';
$module_id = $_GET['module_id'] ?? '';
$project_id = $_GET['project_id'] ?? '';
$date_range = $_GET['date_range'] ?? '';
$record_type = $_GET['record_type'] ?? 'current';

// 如果历史记录表不存在，强制使用当前进度
if (!$user_study_history_exists && $record_type === 'history') {
    $record_type = 'current';
}

// 构建查询条件
$where_conditions = [];
$params = [];

if (!empty($user_id)) {
    $where_conditions[] = "u.id = ?";
    $params[] = $user_id;
}

if (!empty($course_id)) {
    $where_conditions[] = "c.id = ?";
    $params[] = $course_id;
}

if (!empty($module_id)) {
    $where_conditions[] = "m.id = ?";
    $params[] = $module_id;
}

if (!empty($project_id)) {
    $where_conditions[] = "p.id = ?";
    $params[] = $project_id;
}

// 根据记录类型选择正确的表别名
$table_alias = ($record_type === 'current') ? 'up' : 'ush';

if (!empty($date_range)) {
    switch ($date_range) {
        case 'today':
            $where_conditions[] = "DATE({$table_alias}.completed_at) = CURDATE()";
            break;
        case 'week':
            $where_conditions[] = "{$table_alias}.completed_at >= DATE_SUB(CURDATE(), INTERVAL 7 DAY)";
            break;
        case 'month':
            $where_conditions[] = "{$table_alias}.completed_at >= DATE_SUB(CURDATE(), INTERVAL 30 DAY)";
            break;
    }
}

$where_sql = '';
if (!empty($where_conditions)) {
    $where_sql = "WHERE " . implode(" AND ", $where_conditions);
}

// 根据记录类型选择数据源
if ($record_type === 'current') {
    // 查看当前进度（每个用户每个项目的最新记录）
    if ($user_progress_exists) {
        $export_sql = "
            SELECT 
                u.id as '用户ID',
                u.username as '用户名',
                p.id as '项目ID',
                p.project_name as '项目名称',
                m.id as '模块ID',
                m.module_name as '模块名称',
                c.id as '课程ID',
                c.course_name as '课程名称',
                up.score as '得分',
                up.completed_at as '完成时间',
                up.started_at as '开始时间',
                up.study_duration as '学习时长(分钟)',
                up.attempt_count as '尝试次数',
                '当前进度' as '记录类型',
                (SELECT COUNT(*) FROM questions q WHERE q.project_id = p.id) as '总题目数'
            FROM user_progress up
            JOIN users u ON up.user_id = u.id
            JOIN projects p ON up.project_id = p.id
            JOIN modules m ON p.module_id = m.id
            JOIN courses c ON m.course_id = c.id
            $where_sql
            ORDER BY up.completed_at DESC
        ";
    } else {
        header('Content-Type: text/html; charset=utf-8');
        echo "用户进度表不存在，无法导出数据";
        exit();
    }
} else {
    // 查看历史记录（所有学习记录）
    if ($user_study_history_exists) {
        $export_sql = "
            SELECT 
                u.id as '用户ID',
                u.username as '用户名',
                p.id as '项目ID',
                p.project_name as '项目名称',
                m.id as '模块ID',
                m.module_name as '模块名称',
                c.id as '课程ID',
                c.course_name as '课程名称',
                ush.score as '得分',
                ush.completed_at as '完成时间',
                ush.study_duration as '学习时长(分钟)',
                ush.total_questions as '总题目数',
                ush.correct_answers as '正确题数',
                ROUND(ush.correct_answers / ush.total_questions * 100, 1) as '正确率(%)',
                '历史记录' as '记录类型'
            FROM user_study_history ush
            JOIN users u ON ush.user_id = u.id
            JOIN projects p ON ush.project_id = p.id
            JOIN modules m ON p.module_id = m.id
            JOIN courses c ON m.course_id = c.id
            $where_sql
            ORDER BY ush.completed_at DESC
        ";
    } else {
        header('Content-Type: text/html; charset=utf-8');
        echo "用户学习历史表不存在，无法导出数据";
        exit();
    }
}

try {
    $stmt = $pdo->prepare($export_sql);
    $stmt->execute($params);
    $records = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    if (empty($records)) {
        header('Content-Type: text/html; charset=utf-8');
        echo "没有找到符合条件的数据";
        exit();
    }
    
    // 设置文件名
    $filename = '用户学习记录_' . date('Ymd_His') . '.csv';
    
    // 设置HTTP头
    header('Content-Type: text/csv; charset=utf-8');
    header('Content-Disposition: attachment; filename="' . $filename . '"');
    
    // 打开输出流
    $output = fopen('php://output', 'w');
    
    // 添加BOM头，确保Excel正确识别UTF-8编码
    fwrite($output, "\xEF\xBB\xBF");
    
    // 写入CSV标题行
    if (!empty($records)) {
        fputcsv($output, array_keys($records[0]));
    }
    
    // 写入数据行
    foreach ($records as $record) {
        // 格式化日期时间
        if (isset($record['完成时间']) && $record['完成时间']) {
            $record['完成时间'] = date('Y-m-d H:i:s', strtotime($record['完成时间']));
        }
        if (isset($record['开始时间']) && $record['开始时间']) {
            $record['开始时间'] = date('Y-m-d H:i:s', strtotime($record['开始时间']));
        }
        
        fputcsv($output, $record);
    }
    
    fclose($output);
    
} catch (PDOException $e) {
    header('Content-Type: text/html; charset=utf-8');
    echo "导出失败: " . $e->getMessage();
    exit();
}
?>