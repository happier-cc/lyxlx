<?php
// import_users.php - 直接导入处理（API方式）
require_once '../config/database.php';

if (!isset($_SESSION['user_id']) || $_SESSION['role'] != 'admin') {
    header('Content-Type: application/json');
    echo json_encode(['success' => false, 'message' => '无权限访问']);
    exit();
}

// ... 前面的代码保持不变 ...

/**
 * 导入用户到数据库
 */
function importUsers($users_data, $pdo) {
    $imported = 0;
    $skipped = 0;
    $debug_info = [];
    
    $pdo->beginTransaction();
    
    try {
        foreach ($users_data as $index => $user) {
            $line = $index + 2;
            
            // 检查用户是否已存在
            $check_stmt = $pdo->prepare("SELECT id FROM users WHERE username = ?");
            $check_stmt->execute([$user['username']]);
            
            if ($check_stmt->fetch()) {
                $skipped++;
                $debug_info[] = "跳过第{$line}行：用户 {$user['username']} 已存在";
                continue;
            }
            
            // 插入新用户 - 使用 password_hash() 加密
            $default_password = '123456';
            $encrypted_password = password_hash($default_password, PASSWORD_DEFAULT);
            
            $insert_stmt = $pdo->prepare("
                INSERT INTO users (username, password, role, created_at) 
                VALUES (?, ?, ?, NOW())
            ");
            
            $role = $user['role'] ?: 'user';
            
            $insert_stmt->execute([
                $user['username'],
                $encrypted_password,
                $role
            ]);
            
            $imported++;
            $debug_info[] = "导入第{$line}行：用户 {$user['username']}，使用password_hash加密";
        }
        
        $pdo->commit();
        
        return [
            'success' => true,
            'imported' => $imported,
            'skipped' => $skipped,
            'total' => count($users_data),
            'message' => "成功导入 {$imported} 个用户，跳过 {$skipped} 个已存在用户",
            'debug' => $debug_info
        ];
        
    } catch (Exception $e) {
        $pdo->rollBack();
        return ['success' => false, 'message' => '数据库错误：' . $e->getMessage()];
    }
}
?>