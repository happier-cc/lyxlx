<?php
session_start();
require_once '../config/database.php';

// 检查管理员权限
if (!isset($_SESSION['user_id']) || $_SESSION['role'] != 'admin') {
    header("Location: login.php");
    exit();
}

// 获取筛选条件
$course_filter = isset($_GET['course_id']) && $_GET['course_id'] ? $_GET['course_id'] : 'all';

// 获取课程名称（用于文件名）
$course_name = '所有课程';
if ($course_filter != 'all') {
    $course_name_sql = "SELECT course_name FROM courses WHERE id = ?";
    $course_name_stmt = $pdo->prepare($course_name_sql);
    $course_name_stmt->execute([$course_filter]);
    $course_data = $course_name_stmt->fetch();
    $course_name = $course_data ? $course_data['course_name'] : '未知课程';
}

// 设置 CSV 文件头
header('Content-Type: text/csv; charset=utf-8');
header('Content-Disposition: attachment; filename="用户学习汇总_' . ($course_filter != 'all' ? $course_name . '_' : '') . date('Ymd_His') . '.csv"');

// 创建输出流
$output = fopen('php://output', 'w');

// 添加 UTF-8 BOM 确保 Excel 正确显示中文
fputs($output, $bom = (chr(0xEF) . chr(0xBB) . chr(0xBF)));

// 构建基础查询获取用户列表
$base_sql = "
    SELECT 
        u.id,
        u.username,
        u.role,
        u.created_at as register_time,
        u.last_login,
        MAX(up.completed_at) as last_study_time
    FROM users u
    LEFT JOIN user_progress up ON u.id = up.user_id AND up.completed = TRUE
";

// 如果选择了特定课程，添加关联条件
if ($course_filter != 'all') {
    $base_sql .= "
        LEFT JOIN projects p ON up.project_id = p.id
        LEFT JOIN modules m ON p.module_id = m.id
        WHERE m.course_id = :course_id
    ";
}

$base_sql .= " GROUP BY u.id ORDER BY last_study_time DESC";

// 执行基础查询获取用户列表
if ($course_filter != 'all') {
    $base_stmt = $pdo->prepare($base_sql);
    $base_stmt->execute(['course_id' => $course_filter]);
} else {
    $base_stmt = $pdo->query($base_sql);
}
$user_list = $base_stmt->fetchAll();

// 辅助函数：格式化学习时长
function formatStudyTimeForExport($seconds) {
    if (!$seconds) return '0分钟';
    
    $hours = floor($seconds / 3600);
    $minutes = floor(($seconds % 3600) / 60);
    
    if ($hours > 0) {
        return $hours . '小时' . $minutes . '分钟';
    } else {
        return $minutes . '分钟';
    }
}

// 辅助函数：计算学习频率
function calculateStudyFrequency($registerTime, $lastStudyTime, $totalAttempts) {
    if (!$registerTime || !$lastStudyTime || $totalAttempts <= 0) {
        return 'N/A';
    }
    
    $registerTimestamp = strtotime($registerTime);
    $lastStudyTimestamp = strtotime($lastStudyTime);
    
    if ($registerTimestamp === false || $lastStudyTimestamp === false) {
        return 'N/A';
    }
    
    $totalDays = max(1, ($lastStudyTimestamp - $registerTimestamp) / (60 * 60 * 24));
    $frequency = $totalDays / $totalAttempts;
    
    return round($frequency, 1);
}

// CSV 文件标题行 - 根据是否筛选课程调整
$headers = array(
    '用户ID',
    '用户名',
    '角色',
    '注册时间',
    '最后登录时间'
);

if ($course_filter != 'all') {
    $headers[] = '课程完成项目数';
    $headers[] = '课程总项目数';
    $headers[] = '课程完成率';
} else {
    $headers[] = '完成课程数';
    $headers[] = '完成模块数';
}

$headers = array_merge($headers, array(
    '完成项目数',
    '总学习次数',
    '平均得分',
    '总学习时长(秒)',
    '总学习时长',
    '最后学习时间',
    '错题总数',
    '收藏总数',
    '有错题项目数',
    '有收藏项目数',
    '学习历史记录数',
    '平均每次尝试得分',
    '学习频率(天/次)'
));

fputcsv($output, $headers);

// 获取课程总项目数（仅筛选课程时）
$total_course_projects = 0;
if ($course_filter != 'all') {
    $total_projects_sql = "SELECT COUNT(*) as count 
                           FROM projects p 
                           JOIN modules m ON p.module_id = m.id 
                           WHERE m.course_id = ?";
    $total_projects_stmt = $pdo->prepare($total_projects_sql);
    $total_projects_stmt->execute([$course_filter]);
    $total_projects_data = $total_projects_stmt->fetch();
    $total_course_projects = $total_projects_data['count'];
}

// 写入数据行
foreach ($user_list as $user) {
    // 根据是否筛选课程构建不同的统计查询
    if ($course_filter != 'all') {
        $stat_sql = "
            SELECT 
                COUNT(DISTINCT p.id) as completed_projects,
                SUM(up.attempt_count) as total_attempts,
                AVG(up.score) as avg_score,
                SUM(up.study_duration) as total_study_time,
                (SELECT COUNT(*) 
                 FROM wrong_questions wq 
                 JOIN projects p2 ON wq.project_id = p2.id
                 JOIN modules m2 ON p2.module_id = m2.id
                 WHERE wq.user_id = :user_id AND m2.course_id = :course_id) as total_wrong,
                (SELECT COUNT(*) 
                 FROM favorite_questions fq 
                 JOIN projects p3 ON fq.project_id = p3.id
                 JOIN modules m3 ON p3.module_id = m3.id
                 WHERE fq.user_id = :user_id2 AND m3.course_id = :course_id2) as total_favorites,
                (SELECT COUNT(DISTINCT p4.id) 
                 FROM wrong_questions wq2 
                 JOIN projects p4 ON wq2.project_id = p4.id
                 JOIN modules m4 ON p4.module_id = m4.id
                 WHERE wq2.user_id = :user_id3 AND m4.course_id = :course_id3) as wrong_projects,
                (SELECT COUNT(DISTINCT p5.id) 
                 FROM favorite_questions fq2 
                 JOIN projects p5 ON fq2.project_id = p5.id
                 JOIN modules m5 ON p5.module_id = m5.id
                 WHERE fq2.user_id = :user_id4 AND m5.course_id = :course_id4) as favorite_projects,
                (SELECT COUNT(*) 
                 FROM user_study_history ush 
                 JOIN projects p6 ON ush.project_id = p6.id
                 JOIN modules m6 ON p6.module_id = m6.id
                 WHERE ush.user_id = :user_id5 AND m6.course_id = :course_id5) as history_count,
                (SELECT COUNT(DISTINCT p7.id)
                 FROM user_progress up7 
                 JOIN projects p7 ON up7.project_id = p7.id
                 JOIN modules m7 ON p7.module_id = m7.id
                 WHERE up7.user_id = :user_id6 AND m7.course_id = :course_id6 AND up7.completed = TRUE) as course_completed_projects
            FROM users u
            LEFT JOIN user_progress up ON u.id = up.user_id AND up.completed = TRUE
            LEFT JOIN projects p ON up.project_id = p.id
            LEFT JOIN modules m ON p.module_id = m.id AND m.course_id = :course_id8
            WHERE u.id = :user_id7
            GROUP BY u.id
        ";
        
        $stat_stmt = $pdo->prepare($stat_sql);
        $stat_params = [
            'user_id' => $user['id'],
            'user_id2' => $user['id'],
            'user_id3' => $user['id'],
            'user_id4' => $user['id'],
            'user_id5' => $user['id'],
            'user_id6' => $user['id'],
            'user_id7' => $user['id'],
            'course_id' => $course_filter,
            'course_id2' => $course_filter,
            'course_id3' => $course_filter,
            'course_id4' => $course_filter,
            'course_id5' => $course_filter,
            'course_id6' => $course_filter,
            'course_id8' => $course_filter
        ];
        $stat_stmt->execute($stat_params);
    } else {
        // 全部课程的数据
        $stat_sql = "
            SELECT 
                COUNT(DISTINCT up.project_id) as completed_projects,
                SUM(up.attempt_count) as total_attempts,
                AVG(up.score) as avg_score,
                SUM(up.study_duration) as total_study_time,
                (SELECT COUNT(*) FROM wrong_questions wq WHERE wq.user_id = u.id) as total_wrong,
                (SELECT COUNT(*) FROM favorite_questions fq WHERE fq.user_id = u.id) as total_favorites,
                (SELECT COUNT(DISTINCT project_id) FROM wrong_questions wq WHERE wq.user_id = u.id) as wrong_projects,
                (SELECT COUNT(DISTINCT project_id) FROM favorite_questions fq WHERE fq.user_id = u.id) as favorite_projects,
                (SELECT COUNT(*) FROM user_study_history ush WHERE ush.user_id = u.id) as history_count,
                (SELECT COUNT(DISTINCT c.id) 
                 FROM courses c 
                 JOIN modules m ON c.id = m.course_id 
                 JOIN projects p ON m.id = p.module_id 
                 JOIN user_progress up2 ON p.id = up2.project_id 
                 WHERE up2.user_id = u.id AND up2.completed = TRUE) as completed_courses,
                (SELECT COUNT(DISTINCT m.id) 
                 FROM modules m 
                 JOIN projects p ON m.id = p.module_id 
                 JOIN user_progress up2 ON p.id = up2.project_id 
                 WHERE up2.user_id = u.id AND up2.completed = TRUE) as completed_modules
            FROM users u
            LEFT JOIN user_progress up ON u.id = up.user_id AND up.completed = TRUE
            WHERE u.id = :user_id
            GROUP BY u.id
        ";
        
        $stat_stmt = $pdo->prepare($stat_sql);
        $stat_stmt->execute(['user_id' => $user['id']]);
    }
    
    $stat = $stat_stmt->fetch();
    if (!$stat) continue;
    
    // 计算额外指标
    $avg_attempt_score = ($stat['total_attempts'] > 0 && $stat['avg_score'] > 0) 
        ? round($stat['avg_score'], 1) 
        : 0;
    
    $study_frequency = calculateStudyFrequency(
        $user['register_time'], 
        $user['last_study_time'], 
        $stat['total_attempts']
    );
    
    // 格式化角色
    $role_text = ($user['role'] == 'admin') ? '管理员' : '普通用户';
    
    // 格式化时间
    $register_time_formatted = $user['register_time'] 
        ? date('Y-m-d H:i:s', strtotime($user['register_time'])) 
        : '';
    
    $last_login_formatted = $user['last_login'] 
        ? date('Y-m-d H:i:s', strtotime($user['last_login'])) 
        : '从未登录';
    
    $last_study_formatted = $user['last_study_time'] 
        ? date('Y-m-d H:i:s', strtotime($user['last_study_time'])) 
        : '未学习';
    
    // 计算课程完成率
    $course_completion_rate = 0;
    if ($course_filter != 'all' && $total_course_projects > 0) {
        $course_completed = $stat['course_completed_projects'] ?? 0;
        $course_completion_rate = round(($course_completed / $total_course_projects) * 100, 1);
    }
    
    // 准备数据行
    $row = array(
        $user['id'],
        $user['username'],
        $role_text,
        $register_time_formatted,
        $last_login_formatted
    );
    
    // 添加课程相关数据
    if ($course_filter != 'all') {
        $row[] = $stat['course_completed_projects'] ?? 0;
        $row[] = $total_course_projects;
        $row[] = $course_completion_rate . '%';
    } else {
        $row[] = $stat['completed_courses'] ?? 0;
        $row[] = $stat['completed_modules'] ?? 0;
    }
    
    // 添加通用统计数据
    $row = array_merge($row, array(
        $stat['completed_projects'] ?: 0,
        $stat['total_attempts'] ?: 0,
        $stat['avg_score'] ? round($stat['avg_score'], 1) : 0,
        $stat['total_study_time'] ?: 0,
        formatStudyTimeForExport($stat['total_study_time']),
        $last_study_formatted,
        $stat['total_wrong'] ?: 0,
        $stat['total_favorites'] ?: 0,
        $stat['wrong_projects'] ?: 0,
        $stat['favorite_projects'] ?: 0,
        $stat['history_count'] ?: 0,
        $avg_attempt_score,
        $study_frequency
    ));
    
    fputcsv($output, $row);
}

// 添加汇总统计信息
fputcsv($output, array('')); // 空行分隔
fputcsv($output, array('汇总统计'));
fputcsv($output, array('统计项', '数值'));

// 计算统计数据
$total_users = count($user_list);

// 重新查询获取详细统计数据用于汇总
if ($course_filter != 'all') {
    $summary_sql = "
        SELECT 
            COUNT(DISTINCT u.id) as total_users,
            COUNT(DISTINCT CASE WHEN up.completed_at IS NOT NULL THEN u.id END) as active_users,
            COUNT(DISTINCT up.project_id) as total_completed_projects,
            SUM(up.attempt_count) as total_attempts,
            AVG(up.score) as avg_score,
            SUM(up.study_duration) as total_study_time,
            (SELECT COUNT(*) 
             FROM wrong_questions wq 
             JOIN projects p ON wq.project_id = p.id
             JOIN modules m ON p.module_id = m.id
             WHERE m.course_id = :course_id) as total_wrong,
            (SELECT COUNT(*) 
             FROM favorite_questions fq 
             JOIN projects p ON fq.project_id = p.id
             JOIN modules m ON p.module_id = m.id
             WHERE m.course_id = :course_id2) as total_favorites
        FROM users u
        LEFT JOIN user_progress up ON u.id = up.user_id AND up.completed = TRUE
        LEFT JOIN projects p ON up.project_id = p.id
        LEFT JOIN modules m ON p.module_id = m.id AND m.course_id = :course_id3
    ";
    
    $summary_stmt = $pdo->prepare($summary_sql);
    $summary_stmt->execute([
        'course_id' => $course_filter,
        'course_id2' => $course_filter,
        'course_id3' => $course_filter
    ]);
} else {
    $summary_sql = "
        SELECT 
            COUNT(DISTINCT u.id) as total_users,
            COUNT(DISTINCT CASE WHEN up.completed_at IS NOT NULL THEN u.id END) as active_users,
            COUNT(DISTINCT up.project_id) as total_completed_projects,
            SUM(up.attempt_count) as total_attempts,
            AVG(up.score) as avg_score,
            SUM(up.study_duration) as total_study_time,
            (SELECT COUNT(*) FROM wrong_questions) as total_wrong,
            (SELECT COUNT(*) FROM favorite_questions) as total_favorites
        FROM users u
        LEFT JOIN user_progress up ON u.id = up.user_id AND up.completed = TRUE
    ";
    $summary_stmt = $pdo->query($summary_sql);
}

$summary_data = $summary_stmt->fetch();

$summary_rows = array(
    array('筛选课程', $course_name),
    array('总用户数', $total_users),
    array('活跃用户数', $summary_data['active_users'] ?? 0),
    array('总完成项目数', $summary_data['total_completed_projects'] ?? 0),
    array('总学习次数', $summary_data['total_attempts'] ?? 0),
    array('总错题数', $summary_data['total_wrong'] ?? 0),
    array('总收藏数', $summary_data['total_favorites'] ?? 0),
    array('总学习时长', formatStudyTimeForExport($summary_data['total_study_time'] ?? 0)),
    array('平均得分', round($summary_data['avg_score'] ?? 0, 1))
);

if ($course_filter != 'all') {
    $summary_rows[] = array('课程总项目数', $total_course_projects);
    if ($total_course_projects > 0) {
        $completion_rate = round(($summary_data['total_completed_projects'] ?? 0) / $total_course_projects * 100, 1);
        $summary_rows[] = array('课程总完成率', $completion_rate . '%');
    }
}

$summary_rows[] = array('活跃用户比例', $total_users > 0 ? round(($summary_data['active_users'] ?? 0) / $total_users * 100, 1) . '%' : '0%');
$summary_rows[] = array('导出时间', date('Y-m-d H:i:s'));
$summary_rows[] = array('数据范围', $course_filter != 'all' ? '按课程筛选' : '全部课程');

foreach ($summary_rows as $summary_row) {
    fputcsv($output, $summary_row);
}

fclose($output);
exit();