<?php
require_once '../config/database.php';

if (!isset($_SESSION['user_id']) || $_SESSION['role'] != 'admin') {
    header("Location: login.php");
    exit();
}

// 获取导出参数
$export_type = $_GET['type'] ?? 'all'; // all, course, module, project
$course_id = $_GET['course_id'] ?? '';
$module_id = $_GET['module_id'] ?? '';
$project_id = $_GET['project_id'] ?? '';
$format = $_GET['format'] ?? 'csv'; // csv, json

// 构建查询条件
$where_conditions = [];
$params = [];

if ($export_type == 'course' && !empty($course_id)) {
    $where_conditions[] = "c.id = ?";
    $params[] = $course_id;
} elseif ($export_type == 'module' && !empty($module_id)) {
    $where_conditions[] = "m.id = ?";
    $params[] = $module_id;
} elseif ($export_type == 'project' && !empty($project_id)) {
    $where_conditions[] = "p.id = ?";
    $params[] = $project_id;
}

$where_sql = '';
if (!empty($where_conditions)) {
    $where_sql = "WHERE " . implode(" AND ", $where_conditions);
}

// 获取题目数据
$questions_sql = "
    SELECT 
        q.id,
        q.question_text,
        q.option_a,
        q.option_b,
        q.option_c,
        q.option_d,
        q.correct_answer,
        q.explanation,
        p.project_name,
        m.module_name,
        c.course_name,
        q.created_at
    FROM questions q
    JOIN projects p ON q.project_id = p.id
    JOIN modules m ON p.module_id = m.id
    JOIN courses c ON m.course_id = c.id
    $where_sql
    ORDER BY c.course_name, m.module_name, p.project_name, q.id
";

$stmt = $pdo->prepare($questions_sql);
$stmt->execute($params);
$questions = $stmt->fetchAll();

// 获取导出范围描述
$export_description = "全部题目";
if ($export_type == 'course' && !empty($course_id)) {
    $course_stmt = $pdo->prepare("SELECT course_name FROM courses WHERE id = ?");
    $course_stmt->execute([$course_id]);
    $course = $course_stmt->fetch();
    $export_description = "课程: " . ($course['course_name'] ?? '未知课程');
} elseif ($export_type == 'module' && !empty($module_id)) {
    $module_stmt = $pdo->prepare("SELECT m.module_name, c.course_name FROM modules m JOIN courses c ON m.course_id = c.id WHERE m.id = ?");
    $module_stmt->execute([$module_id]);
    $module = $module_stmt->fetch();
    $export_description = "课程: " . ($module['course_name'] ?? '未知课程') . " - 模块: " . ($module['module_name'] ?? '未知模块');
} elseif ($export_type == 'project' && !empty($project_id)) {
    $project_stmt = $pdo->prepare("SELECT p.project_name, m.module_name, c.course_name FROM projects p JOIN modules m ON p.module_id = m.id JOIN courses c ON m.course_id = c.id WHERE p.id = ?");
    $project_stmt->execute([$project_id]);
    $project = $project_stmt->fetch();
    $export_description = "课程: " . ($project['course_name'] ?? '未知课程') . " - 模块: " . ($project['module_name'] ?? '未知模块') . " - 项目: " . ($project['project_name'] ?? '未知项目');
}

// 设置HTTP头
if ($format == 'csv') {
    header('Content-Type: text/csv; charset=utf-8');
    header('Content-Disposition: attachment; filename="题目导出_' . date('Ymd_His') . '.csv"');
} else {
    header('Content-Type: application/json; charset=utf-8');
    header('Content-Disposition: attachment; filename="题目导出_' . date('Ymd_His') . '.json"');
}

// 创建输出流
$output = fopen('php://output', 'w');

if ($format == 'csv') {
    // 添加BOM头，确保Excel正确显示中文
    fwrite($output, "\xEF\xBB\xBF");
    
    // 写入表头
    fputcsv($output, [
        '题目ID', '题目内容', '选项A', '选项B', '选项C', '选项D', 
        '正确答案', '解析', '课程', '模块', '项目', '创建时间'
    ]);
    
    // 写入数据
    foreach ($questions as $question) {
        fputcsv($output, [
            $question['id'],
            $question['question_text'],
            $question['option_a'],
            $question['option_b'],
            $question['option_c'],
            $question['option_d'],
            $question['correct_answer'],
            $question['explanation'],
            $question['course_name'],
            $question['module_name'],
            $question['project_name'],
            $question['created_at']
        ]);
    }
} else {
    // JSON格式导出
    $export_data = [
        'meta' => [
            'export_time' => date('Y-m-d H:i:s'),
            'export_range' => $export_description,
            'total_questions' => count($questions)
        ],
        'questions' => $questions
    ];
    
    fwrite($output, json_encode($export_data, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE));
}

fclose($output);
exit();