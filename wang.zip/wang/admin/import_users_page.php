<?php
// import_users_page.php
require_once '../config/database.php';

if (!isset($_SESSION['user_id']) || $_SESSION['role'] != 'admin') {
    header("Location: login.php");
    exit();
}

// 处理文件上传
$message = '';
$message_type = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_FILES['user_file'])) {
    $file = $_FILES['user_file'];
    
    // 检查文件类型
    $allowed_types = ['application/vnd.ms-excel', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet', 'text/csv'];
    if (!in_array($file['type'], $allowed_types)) {
        $message = '只支持Excel或CSV文件格式';
        $message_type = 'error';
    } elseif ($file['error'] !== UPLOAD_ERR_OK) {
        $message = '文件上传失败，错误代码：' . $file['error'];
        $message_type = 'error';
    } else {
        // 处理文件导入
        $result = importUsersFromFile($file['tmp_name'], $pdo);
        
        if ($result['success']) {
            $message = "成功导入 {$result['imported']} 个用户，跳过 {$result['skipped']} 个重复用户";
            $message_type = 'success';
        } else {
            $message = "导入失败：" . $result['message'];
            $message_type = 'error';
        }
    }
}

/**
 * 从文件导入用户数据
 */
function importUsersFromFile($file_path, $pdo) {
    try {
        // 检测文件类型并读取数据
        $file_extension = pathinfo($_FILES['user_file']['name'], PATHINFO_EXTENSION);
        $users_data = [];
        
        if ($file_extension === 'csv') {
            $users_data = readCSVFile($file_path);
        } else {
            $users_data = readExcelFile($file_path);
        }
        
        if (empty($users_data)) {
            return ['success' => false, 'message' => '文件为空或格式不正确'];
        }
        
        // 验证数据格式
        $validation_result = validateUserData($users_data);
        if (!$validation_result['valid']) {
            return ['success' => false, 'message' => $validation_result['message']];
        }
        
        // 导入数据
        $imported = 0;
        $skipped = 0;
        
        $pdo->beginTransaction();
        
        foreach ($users_data as $user_data) {
            // 检查用户是否已存在
            $stmt = $pdo->prepare("SELECT id FROM users WHERE username = ?");
            $stmt->execute([$user_data['username']]);
            
            if ($stmt->fetch()) {
                $skipped++;
                continue;
            }
            
            // 插入新用户
            $stmt = $pdo->prepare("
                INSERT INTO users (username, password, role, created_at) 
                VALUES (?, ?, ?, NOW())
            ");
            
            // 默认密码为123456（使用password_hash加密）
            $default_password = password_hash('750750', PASSWORD_DEFAULT);
            $stmt->execute([
                $user_data['username'],
                $default_password,
                $user_data['role'] ?? 'user'
            ]);
            
            $imported++;
        }
        
        $pdo->commit();
        
        return [
            'success' => true,
            'imported' => $imported,
            'skipped' => $skipped
        ];
        
    } catch (Exception $e) {
        $pdo->rollBack();
        return ['success' => false, 'message' => $e->getMessage()];
    }
}

/**
 * 读取CSV文件
 */
function readCSVFile($file_path) {
    $users_data = [];
    if (($handle = fopen($file_path, "r")) !== FALSE) {
        $headers = fgetcsv($handle); // 读取表头
        
        while (($data = fgetcsv($handle)) !== FALSE) {
            if (count($data) >= 1) {
                $users_data[] = [
                    'username' => $data[0] ?? '',
                    'role' => $data[1] ?? 'user'
                ];
            }
        }
        fclose($handle);
    }
    return $users_data;
}

/**
 * 读取Excel文件（简化版本）
 */
function readExcelFile($file_path) {
    // 简化处理：如果是Excel文件，这里需要安装PhpSpreadsheet库
    // 这里暂时返回空数组，实际使用时需要实现Excel解析
    return [];
}

/**
 * 验证用户数据格式
 */
function validateUserData($users_data) {
    foreach ($users_data as $index => $user_data) {
        $line_number = $index + 2; // 表头在第1行，数据从第2行开始
        
        if (empty($user_data['username'])) {
            return [
                'valid' => false,
                'message' => "第{$line_number}行数据不完整：用户名为必填项"
            ];
        }
        
        // 检查用户名长度（支持汉字，每个汉字算3个字符）
        $username_length = mb_strlen($user_data['username'], 'UTF-8');
        if ($username_length < 2 || $username_length > 20) {
            return [
                'valid' => false,
                'message' => "第{$line_number}行用户名长度必须在2-20个字符之间"
            ];
        }
        
        // 检查用户名格式（允许汉字、字母、数字、下划线）
        if (!preg_match('/^[\x{4e00}-\x{9fa5}a-zA-Z0-9_]+$/u', $user_data['username'])) {
            return [
                'valid' => false,
                'message' => "第{$line_number}行用户名只能包含汉字、字母、数字和下划线"
            ];
        }
        
        if (isset($user_data['role']) && !in_array($user_data['role'], ['user', 'admin'])) {
            return [
                'valid' => false,
                'message' => "第{$line_number}行角色不正确：{$user_data['role']}（只能是user或admin）"
            ];
        }
    }
    
    return ['valid' => true];
}
?>

<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>导入用户数据 - 在线刷题系统</title>
    <link rel="stylesheet" href="../config/style.css">
    <style>
        .import-container {
            max-width: 800px;
            margin: 50px auto;
            padding: 30px;
        }
        .import-option {
            background: white;
            padding: 25px;
            border-radius: 12px;
            margin-bottom: 20px;
            box-shadow: var(--shadow);
        }
        .import-option h3 {
            margin-top: 0;
            color: var(--primary-color);
        }
        .form-group {
            margin-bottom: 20px;
        }
        .form-group label {
            display: block;
            margin-bottom: 8px;
            font-weight: 600;
        }
        .form-group input[type="file"] {
            width: 100%;
            padding: 10px;
            border: 2px dashed var(--border-color);
            border-radius: 6px;
            background: var(--bg-tertiary);
        }
        .btn-import {
            background: var(--success-color);
            color: white;
            padding: 12px 30px;
            border: none;
            border-radius: 6px;
            cursor: pointer;
            font-size: 16px;
            transition: background 0.3s;
        }
        .btn-import:hover {
            background: #28a745;
        }
        .info-box {
            background: var(--bg-tertiary);
            padding: 20px;
            border-radius: 8px;
            margin-top: 20px;
        }
        .message {
            padding: 15px;
            border-radius: 6px;
            margin: 20px 0;
        }
        .message.success {
            background: #d4edda;
            color: #155724;
            border: 1px solid #c3e6cb;
        }
        .message.error {
            background: #f8d7da;
            color: #721c24;
            border: 1px solid #f5c6cb;
        }
        .template-download {
            background: var(--primary-color);
            color: white;
            padding: 10px 20px;
            border-radius: 6px;
            text-decoration: none;
            display: inline-block;
            margin: 10px 0;
        }
        .template-download:hover {
            background: var(--secondary-color);
            color: white;
        }
        .requirements {
            background: #fff3cd;
            border: 1px solid #ffeaa7;
            padding: 15px;
            border-radius: 6px;
            margin: 15px 0;
        }
    </style>
</head>
<body>
    <nav class="navbar">
        <div class="container">
            <div class="nav-content">
                <a href="index.php" class="nav-brand">← 返回后台</a>
                <span class="nav-brand">导入用户数据</span>
            </div>
        </div>
    </nav>

    <div class="container">
        <div class="import-container">
            <div class="card">
                <h1>导入用户数据</h1>
                <p>通过Excel或CSV文件批量导入用户账号</p>
                
                <?php if ($message): ?>
                    <div class="message <?php echo $message_type; ?>">
                        <?php echo htmlspecialchars($message); ?>
                    </div>
                <?php endif; ?>
                
                <div class="import-option">
                    <h3>📤 上传用户数据文件</h3>
                    <form method="POST" enctype="multipart/form-data">
                        <div class="form-group">
                            <label for="user_file">选择文件：</label>
                            <input type="file" id="user_file" name="user_file" accept=".csv,.xls,.xlsx" required>
                            <small>支持格式：CSV、Excel (.xls, .xlsx)</small>
                        </div>
                        
                        <button type="submit" class="btn-import">开始导入</button>
                    </form>
                </div>
                
                <div class="import-option">
                    <h3>📋 文件格式要求</h3>
                    <div class="requirements">
                        <p><strong>CSV/Excel文件应包含以下列：</strong></p>
                        <ul>
                            <li><strong>用户名</strong> (必填) - 用户的登录用户名（2-20个字符，支持汉字、字母、数字、下划线）</li>
                            <li><strong>角色</strong> (可选) - user 或 admin，默认为 user</li>
                        </ul>
                        <p><strong>注意：</strong>所有用户的初始密码将设置为 123456</p>
                    </div>
                    
                    <a href="download_user_template.php" class="template-download">📥 下载导入模板</a>
                </div>
                
                <div class="info-box">
                    <h4>💡 导入说明：</h4>
                    <ul>
                        <li>文件第一行应为表头（用户名,角色）</li>
                        <li>系统会自动跳过已存在的用户名</li>
                        <li>导入过程中遇到错误会停止并显示具体错误信息</li>
                        <li>建议先下载模板文件，按照模板格式准备数据</li>
                        <li>大量数据导入可能需要较长时间，请耐心等待</li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
</body>
</html>