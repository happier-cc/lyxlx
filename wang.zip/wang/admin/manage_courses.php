<?php
require_once '../config/database.php';

if (!isset($_SESSION['user_id']) || $_SESSION['role'] != 'admin') {
    header("Location: login.php");
    exit();
}

// 添加课程
if (isset($_POST['add_course'])) {
    $course_name = trim($_POST['course_name']);
    $description = trim($_POST['description']);
    
    if (!empty($course_name)) {
        $stmt = $pdo->prepare("INSERT INTO courses (course_name, description) VALUES (?, ?)");
        $stmt->execute([$course_name, $description]);
        $success = "课程添加成功！";
    } else {
        $error = "课程名称不能为空！";
    }
}

// 编辑课程
if (isset($_POST['edit_course'])) {
    $course_id = $_POST['course_id'];
    $course_name = trim($_POST['course_name']);
    $description = trim($_POST['description']);
    
    if (!empty($course_name)) {
        $stmt = $pdo->prepare("UPDATE courses SET course_name = ?, description = ? WHERE id = ?");
        $stmt->execute([$course_name, $description, $course_id]);
        $success = "课程更新成功！";
    } else {
        $error = "课程名称不能为空！";
    }
}

// 删除课程
if (isset($_GET['delete'])) {
    $course_id = $_GET['delete'];
    
    // 检查是否有模块关联
    $check_stmt = $pdo->prepare("SELECT COUNT(*) FROM modules WHERE course_id = ?");
    $check_stmt->execute([$course_id]);
    $module_count = $check_stmt->fetchColumn();
    
    if ($module_count > 0) {
        $error = "无法删除该课程，因为有关联的模块存在！";
    } else {
        $stmt = $pdo->prepare("DELETE FROM courses WHERE id = ?");
        $stmt->execute([$course_id]);
        $success = "课程删除成功！";
    }
}

// 获取所有课程
$courses = $pdo->query("SELECT * FROM courses ORDER BY id")->fetchAll();

// 获取编辑的课程信息
$editing_course = null;
if (isset($_GET['edit'])) {
    $edit_id = $_GET['edit'];
    $stmt = $pdo->prepare("SELECT * FROM courses WHERE id = ?");
    $stmt->execute([$edit_id]);
    $editing_course = $stmt->fetch();
}
?>

<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
    <title>课程管理 - 在线刷题系统</title>
    <link rel="stylesheet" href="../config/style.css">
    <style>
        .form-section {
            margin-bottom: 32px;
        }
        
        .courses-grid {
            display: grid;
            gap: 16px;
        }
        
        .course-card {
            background: white;
            padding: 20px;
            border-radius: 12px;
            box-shadow: var(--shadow);
            border-left: 4px solid var(--primary-color);
        }
        
        .course-header {
            display: flex;
            justify-content: space-between;
            align-items: flex-start;
            margin-bottom: 12px;
        }
        
        .course-title {
            font-size: 18px;
            font-weight: 600;
            color: var(--text-primary);
        }
        
        .course-actions {
            display: flex;
            gap: 8px;
            flex-wrap: wrap;
        }
        
        .course-stats {
            display: flex;
            gap: 16px;
            margin-top: 12px;
            font-size: 14px;
            color: var(--text-secondary);
        }
        
        .stat-item {
            display: flex;
            align-items: center;
            gap: 4px;
        }
        
        @media (max-width: 640px) {
            .course-header {
                flex-direction: column;
                gap: 12px;
            }
            
            .course-actions {
                width: 100%;
                justify-content: flex-start;
            }
        }
    </style>
</head>
<body>
    <nav class="navbar">
        <div class="container">
            <div class="nav-content">
                <a href="index.php" class="nav-brand">← 返回后台</a>
                <span class="nav-brand">课程管理</span>
            </div>
        </div>
    </nav>

    <div class="container">
        <?php if (isset($success)): ?>
            <div class="alert alert-success"><?php echo $success; ?></div>
        <?php endif; ?>
        
        <?php if (isset($error)): ?>
            <div class="alert alert-error"><?php echo $error; ?></div>
        <?php endif; ?>

        <div class="form-section">
            <div class="card">
                <h2><?php echo $editing_course ? '编辑课程' : '添加新课程'; ?></h2>
                <form method="post">
                    <?php if ($editing_course): ?>
                        <input type="hidden" name="course_id" value="<?php echo $editing_course['id']; ?>">
                    <?php endif; ?>
                    
                    <div class="form-group">
                        <label for="course_name" class="form-label">课程名称：</label>
                        <input type="text" id="course_name" name="course_name" class="form-input" 
                               value="<?php echo $editing_course ? htmlspecialchars($editing_course['course_name']) : ''; ?>" 
                               placeholder="请输入课程名称" required>
                    </div>
                    
                    <div class="form-group">
                        <label for="description" class="form-label">课程描述：</label>
                        <textarea id="description" name="description" class="form-input form-textarea" 
                                  placeholder="请输入课程描述（可选）"><?php echo $editing_course ? htmlspecialchars($editing_course['description']) : ''; ?></textarea>
                    </div>
                    
                    <div class="form-group">
                        <?php if ($editing_course): ?>
                            <button type="submit" name="edit_course" class="btn btn-primary">更新课程</button>
                            <a href="manage_courses.php" class="btn btn-outline">取消编辑</a>
                        <?php else: ?>
                            <button type="submit" name="add_course" class="btn btn-primary">添加课程</button>
                        <?php endif; ?>
                    </div>
                </form>
            </div>
        </div>

        <div class="card">
            <h2>课程列表 (<?php echo count($courses); ?> 个)</h2>
            
            <?php if (empty($courses)): ?>
                <div class="text-center" style="padding: 40px; color: var(--text-secondary);">
                    <p>暂无课程</p>
                    <a href="manage_courses.php?action=add" class="btn btn-primary mt-2">添加第一个课程</a>
                </div>
            <?php else: ?>
                <div class="courses-grid">
                    <?php foreach ($courses as $course): 
                        // 获取该课程的模块数量
                        $module_count_stmt = $pdo->prepare("SELECT COUNT(*) FROM modules WHERE course_id = ?");
                        $module_count_stmt->execute([$course['id']]);
                        $module_count = $module_count_stmt->fetchColumn();
                        
                        // 获取项目数量
                        $project_count_stmt = $pdo->prepare("
                            SELECT COUNT(*) FROM projects p 
                            JOIN modules m ON p.module_id = m.id 
                            WHERE m.course_id = ?
                        ");
                        $project_count_stmt->execute([$course['id']]);
                        $project_count = $project_count_stmt->fetchColumn();
                        
                        // 获取题目数量
                        $question_count_stmt = $pdo->prepare("
                            SELECT COUNT(*) FROM questions q 
                            JOIN projects p ON q.project_id = p.id 
                            JOIN modules m ON p.module_id = m.id 
                            WHERE m.course_id = ?
                        ");
                        $question_count_stmt->execute([$course['id']]);
                        $question_count = $question_count_stmt->fetchColumn();
                    ?>
                        <div class="course-card">
                            <div class="course-header">
                                <div class="course-title"><?php echo htmlspecialchars($course['course_name']); ?></div>
                                <div class="course-actions">
                                    <a href="manage_modules.php?course_id=<?php echo $course['id']; ?>" class="btn btn-primary btn-sm">管理模块</a>
                                    <a href="manage_courses.php?edit=<?php echo $course['id']; ?>" class="btn btn-outline btn-sm">编辑</a>
                                    <a href="manage_courses.php?delete=<?php echo $course['id']; ?>" 
                                       class="btn btn-error btn-sm"
                                       onclick="return confirm('确定要删除这个课程吗？')">删除</a>
                                </div>
                            </div>
                            
                            <?php if ($course['description']): ?>
                                <p style="color: var(--text-secondary); margin-bottom: 12px;">
                                    <?php echo htmlspecialchars($course['description']); ?>
                                </p>
                            <?php endif; ?>
                            
                            <div class="course-stats">
                                <div class="stat-item">
                                    <span>📚</span>
                                    <span><?php echo $module_count; ?> 个模块</span>
                                </div>
                                <div class="stat-item">
                                    <span>🎯</span>
                                    <span><?php echo $project_count; ?> 个项目</span>
                                </div>
                                <div class="stat-item">
                                    <span>❓</span>
                                    <span><?php echo $question_count; ?> 道题目</span>
                                </div>
                                <div class="stat-item">
                                    <span>📅</span>
                                    <span><?php echo date('Y-m-d', strtotime($course['created_at'])); ?></span>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>
            <?php endif; ?>
        </div>
    </div>
</body>
</html>