<?php
// 数据库配置
define('DB_HOST', 'localhost');
define('DB_NAME', 'new');
define('DB_USER', 'root');
define('DB_PASS', 'root');

// 创建数据库连接
try {
    $pdo = new PDO("mysql:host=" . DB_HOST . ";dbname=" . DB_NAME, DB_USER, DB_PASS);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    $pdo->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC);
    $pdo->exec("SET NAMES utf8");
} catch(PDOException $e) {
    die("数据库连接失败: " . $e->getMessage());
}

// 设置时区
date_default_timezone_set('Asia/Shanghai');

// 启动会话
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}
?>