<?php
require_once '../config/database.php';

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

$project_id = $_GET['project_id'] ?? 'all';
$course_id = $_GET['course_id'] ?? 'all';

// 获取错题
if ($project_id == 'all') {
    if ($course_id == 'all') {
        $wrong_stmt = $pdo->prepare("
            SELECT q.*, p.project_name, m.module_name, c.course_name, p.id as actual_project_id, c.id as course_id
            FROM wrong_questions wq 
            JOIN questions q ON wq.question_id = q.id 
            JOIN projects p ON wq.project_id = p.id
            JOIN modules m ON p.module_id = m.id
            JOIN courses c ON m.course_id = c.id
            WHERE wq.user_id = ?
        ");
        $wrong_stmt->execute([$_SESSION['user_id']]);
    } else {
        $wrong_stmt = $pdo->prepare("
            SELECT q.*, p.project_name, m.module_name, c.course_name, p.id as actual_project_id, c.id as course_id
            FROM wrong_questions wq 
            JOIN questions q ON wq.question_id = q.id 
            JOIN projects p ON wq.project_id = p.id
            JOIN modules m ON p.module_id = m.id
            JOIN courses c ON m.course_id = c.id
            WHERE wq.user_id = ? AND c.id = ?
        ");
        $wrong_stmt->execute([$_SESSION['user_id'], $course_id]);
    }
} else {
    $wrong_stmt = $pdo->prepare("
        SELECT q.*, p.project_name, m.module_name, c.course_name, p.id as actual_project_id, c.id as course_id
        FROM wrong_questions wq 
        JOIN questions q ON wq.question_id = q.id 
        JOIN projects p ON wq.project_id = p.id
        JOIN modules m ON p.module_id = m.id
        JOIN courses c ON m.course_id = c.id
        WHERE wq.user_id = ? AND wq.project_id = ?
    ");
    $wrong_stmt->execute([$_SESSION['user_id'], $project_id]);
}

$wrong_questions = $wrong_stmt->fetchAll();

if (empty($wrong_questions)) {
    header("Location: wrong_questions.php");
    exit();
}

// 获取课程/项目信息用于显示标题
$title_info = '';
if ($project_id != 'all') {
    $info_stmt = $pdo->prepare("
        SELECT p.project_name, m.module_name, c.course_name 
        FROM projects p 
        JOIN modules m ON p.module_id = m.id 
        JOIN courses c ON m.course_id = c.id 
        WHERE p.id = ?
    ");
    $info_stmt->execute([$project_id]);
    $info = $info_stmt->fetch();
    if ($info) {
        $title_info = htmlspecialchars($info['course_name'] . ' - ' . $info['module_name'] . ' - ' . $info['project_name']);
    }
} elseif ($course_id != 'all') {
    $info_stmt = $pdo->prepare("SELECT course_name FROM courses WHERE id = ?");
    $info_stmt->execute([$course_id]);
    $info = $info_stmt->fetch();
    if ($info) {
        $title_info = htmlspecialchars($info['course_name']);
    }
}

// 检查收藏状态
$favorite_status = [];
foreach ($wrong_questions as $question) {
    $fav_stmt = $pdo->prepare("SELECT id FROM favorite_questions WHERE user_id = ? AND question_id = ?");
    $fav_stmt->execute([$_SESSION['user_id'], $question['id']]);
    $favorite_status[$question['id']] = $fav_stmt->fetch() ? true : false;
}

// 处理收藏/取消收藏
if (isset($_POST['toggle_favorite'])) {
    $question_id = $_POST['question_id'];
    $is_favorite = $_POST['is_favorite'];
    
    // 获取该题目的实际 project_id
    $project_stmt = $pdo->prepare("SELECT project_id FROM wrong_questions WHERE user_id = ? AND question_id = ?");
    $project_stmt->execute([$_SESSION['user_id'], $question_id]);
    $project_data = $project_stmt->fetch();
    $actual_project_id = $project_data['project_id'];
    
    if ($is_favorite == 'false') {
        // 添加收藏
        $stmt = $pdo->prepare("INSERT INTO favorite_questions (user_id, question_id, project_id) VALUES (?, ?, ?)");
        $stmt->execute([$_SESSION['user_id'], $question_id, $actual_project_id]);
        $favorite_status[$question_id] = true;
    } else {
        // 取消收藏
        $stmt = $pdo->prepare("DELETE FROM favorite_questions WHERE user_id = ? AND question_id = ?");
        $stmt->execute([$_SESSION['user_id'], $question_id]);
        $favorite_status[$question_id] = false;
    }
    
    // 返回JSON响应
    header('Content-Type: application/json');
    echo json_encode(['success' => true, 'is_favorite' => $favorite_status[$question_id]]);
    exit();
}

if ($_SERVER['REQUEST_METHOD'] == 'POST' && !isset($_POST['toggle_favorite'])) {
    $correct_count = 0;
    
    foreach ($wrong_questions as $question) {
        $user_answer = $_POST['answer_' . $question['id']] ?? '';
        $is_correct = ($user_answer == $question['correct_answer']);
        
        if ($is_correct) {
            $correct_count++;
            // 从错题本中删除已做对的题目
            $delete_stmt = $pdo->prepare("DELETE FROM wrong_questions WHERE user_id = ? AND question_id = ?");
            $delete_stmt->execute([$_SESSION['user_id'], $question['id']]);
        }
    }
    
    $total = count($wrong_questions);
    ?>
    <!DOCTYPE html>
    <html lang="zh-CN">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
        <title>错题重做完成 - 多课程在线刷题系统</title>
        <link rel="stylesheet" href="../config/style.css">
        <style>
            .result-card {
                text-align: center;
                padding: 40px 20px;
            }
            
            .result-icon {
                font-size: 64px;
                margin-bottom: 20px;
            }
            
            .result-stats {
                display: grid;
                grid-template-columns: repeat(2, 1fr);
                gap: 16px;
                margin: 24px 0;
            }
            
            .stat-item {
                background: var(--bg-tertiary);
                padding: 16px;
                border-radius: 12px;
                text-align: center;
            }
            
            .stat-value {
                font-size: 24px;
                font-weight: 700;
            }
            
            .stat-correct {
                color: var(--success-color);
            }
            
            .stat-total {
                color: var(--primary-color);
            }
            
            .stat-accuracy {
                color: #dc2626;
            }
        </style>
    </head>
    <body>
        <nav class="navbar">
            <div class="container">
                <div class="nav-content">
                    <a href="wrong_questions.php<?php 
                        $back_url = '';
                        if ($course_id != 'all') $back_url .= '?course_id=' . $course_id;
                        if ($project_id != 'all') $back_url .= (strpos($back_url, '?') === false ? '?' : '&') . 'project_id=' . $project_id;
                        echo $back_url;
                    ?>" class="nav-brand">← 返回错题本</a>
                    <span class="nav-brand">重做结果</span>
                </div>
            </div>
        </nav>

        <div class="container">
            <div class="card result-card">
                <div class="result-icon">🎯</div>
                <h2>错题重做完成！</h2>
                
                <div class="result-stats">
                    <div class="stat-item">
                        <div class="stat-value stat-correct"><?php echo $correct_count; ?></div>
                        <div>做对题数</div>
                    </div>
                    <div class="stat-item">
                        <div class="stat-value stat-total"><?php echo $total; ?></div>
                        <div>总题数</div>
                    </div>
                </div>
                
                <div class="stat-item" style="grid-column: span 2; margin-top: 0;">
                    <div class="stat-value stat-accuracy"><?php echo $total > 0 ? round(($correct_count / $total) * 100, 1) : 0; ?>%</div>
                    <div>正确率</div>
                </div>
                
                <p>已从错题本中移除 <?php echo $correct_count; ?> 道做对的题目</p>
                
                <div class="action-buttons" style="display: grid; gap: 12px; margin-top: 32px;">
                    <a href="wrong_questions.php<?php 
                        $back_url = '';
                        if ($course_id != 'all') $back_url .= '?course_id=' . $course_id;
                        if ($project_id != 'all') $back_url .= (strpos($back_url, '?') === false ? '?' : '&') . 'project_id=' . $project_id;
                        echo $back_url;
                    ?>" class="btn btn-primary btn-full">返回错题本</a>
                    <?php if ($total - $correct_count > 0): ?>
                        <a href="review_wrong.php?course_id=<?php echo $course_id; ?>&project_id=<?php echo $project_id; ?>" class="btn btn-outline btn-full">继续重做</a>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </body>
    </html>
    <?php
    exit();
}
?>

<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
    <title>重做错题<?php echo $title_info ? ' - ' . $title_info : ''; ?> - 多课程在线刷题系统</title>
    <link rel="stylesheet" href="../config/style.css">
    <style>
        .review-header {
            background: linear-gradient(135deg, #dc2626, #ef4444);
            color: white;
            padding: 20px;
            border-radius: 12px;
            margin-bottom: 20px;
            text-align: center;
        }
        
        .question-card {
            background: #fef7f7;
            border: 2px solid #fecaca;
            border-radius: 12px;
            padding: 20px;
            margin-bottom: 16px;
            position: relative;
        }
        
        .project-path {
            background: #e3f2fd;
            padding: 4px 8px;
            border-radius: 6px;
            font-size: 12px;
            margin-bottom: 12px;
        }
        
        .favorite-btn {
            background: none;
            border: none;
            font-size: 20px;
            cursor: pointer;
            transition: transform 0.3s ease;
            display: flex;
            align-items: center;
            justify-content: center;
            width: 36px;
            height: 36px;
            margin: 0 auto;
        }
        
        .favorite-btn:hover {
            transform: scale(1.2);
        }
        
        .favorite-btn.active {
            color: #e74c3c;
        }
        
        .progress-info {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 12px;
            font-size: 14px;
            color: var(--text-secondary);
            position: relative;
        }
        
        .progress-center {
            position: absolute;
            left: 50%;
            transform: translateX(-50%);
            display: flex;
            align-items: center;
        }
        
        .question-counter {
            font-weight: 600;
            color: var(--text-primary);
        }
        
        .progress-bar {
            height: 6px;
            background: var(--bg-tertiary);
            border-radius: 3px;
            overflow: hidden;
            margin-bottom: 20px;
        }
        
        .progress-fill {
            height: 100%;
            background: linear-gradient(135deg, #dc2626, #ef4444);
            transition: width 0.3s ease;
        }
        
        @media (max-width: 640px) {
            .favorite-btn {
                width: 32px;
                height: 32px;
                font-size: 18px;
            }
            
            .progress-info {
                font-size: 13px;
            }
        }
    </style>
</head>
<body>
    <nav class="navbar">
        <div class="container">
            <div class="nav-content">
                <a href="wrong_questions.php<?php 
                    $back_url = '';
                    if ($course_id != 'all') $back_url .= '?course_id=' . $course_id;
                    if ($project_id != 'all') $back_url .= (strpos($back_url, '?') === false ? '?' : '&') . 'project_id=' . $project_id;
                    echo $back_url;
                ?>" class="nav-brand">← 返回错题本</a>
                <span class="nav-brand">重做错题<?php echo $title_info ? '<br><small>' . $title_info . '</small>' : ''; ?></span>
            </div>
        </div>
    </nav>

    <div class="container">
        <div class="review-header">
            <h2>重做错题</h2>
            <p>共 <?php echo count($wrong_questions); ?> 道题目需要复习</p>
            <?php if ($title_info): ?>
                <p><small><?php echo $title_info; ?></small></p>
            <?php endif; ?>
        </div>

        <form method="post" id="reviewForm">
            <?php foreach ($wrong_questions as $index => $question): ?>
                <div class="question-card">
                    <div class="project-path">
                        <?php echo htmlspecialchars($question['course_name']); ?> &gt; 
                        <?php echo htmlspecialchars($question['module_name']); ?> &gt; 
                        <?php echo htmlspecialchars($question['project_name']); ?>
                    </div>
                    
                    <div class="progress-info">
                        <span class="question-counter">题目 <?php echo $index + 1; ?> / <?php echo count($wrong_questions); ?></span>
                        
                        <!-- 收藏按钮居中显示 -->
                        <div class="progress-center">
                            <button type="button" class="favorite-btn <?php echo $favorite_status[$question['id']] ? 'active' : ''; ?>" 
                                    data-question-id="<?php echo $question['id']; ?>" 
                                    data-is-favorite="<?php echo $favorite_status[$question['id']] ? 'true' : 'false'; ?>">
                                <?php echo $favorite_status[$question['id']] ? '❤️' : '🤍'; ?>
                            </button>
                        </div>
                    </div>
                    
                    <div class="progress-bar">
                        <div class="progress-fill" style="width: <?php echo (($index + 1) / count($wrong_questions)) * 100; ?>%"></div>
                    </div>
                    
                    <div class="question-text">
                        <?php echo htmlspecialchars($question['question_text']); ?>
                    </div>
                    
                    <div class="options-grid">
                        <?php foreach (['A', 'B', 'C', 'D'] as $option): ?>
                            <?php if (!empty($question['option_' . strtolower($option)])): ?>
                                <label class="option-item">
                                    <input type="radio" name="answer_<?php echo $question['id']; ?>" value="<?php echo $option; ?>" class="option-input" required>
                                    <span class="option-label">
                                        <strong><?php echo $option; ?>.</strong> 
                                        <?php echo htmlspecialchars($question['option_' . strtolower($option)]); ?>
                                    </span>
                                </label>
                            <?php endif; ?>
                        <?php endforeach; ?>
                    </div>
                </div>
            <?php endforeach; ?>
            
            <div class="text-center">
                <button type="submit" class="btn btn-success btn-full" style="background: linear-gradient(135deg, #dc2626, #ef4444); border: none;">提交答案</button>
            </div>
        </form>
    </div>

    <script>
        // 收藏功能
        document.querySelectorAll('.favorite-btn').forEach(btn => {
            btn.addEventListener('click', function() {
                const questionId = this.dataset.questionId;
                const isFavorite = this.dataset.isFavorite === 'true';
                
                const urlParams = new URLSearchParams(window.location.search);
                const courseId = urlParams.get('course_id') || 'all';
                const projectId = urlParams.get('project_id') || 'all';
                
                let fetchUrl = 'review_wrong.php?';
                if (courseId !== 'all') fetchUrl += 'course_id=' + courseId + '&';
                if (projectId !== 'all') fetchUrl += 'project_id=' + projectId + '&';
                fetchUrl = fetchUrl.replace(/[&]+$/, '');
                
                fetch(fetchUrl, {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/x-www-form-urlencoded',
                    },
                    body: `toggle_favorite=true&question_id=${questionId}&is_favorite=${isFavorite}`
                })
                .then(response => response.json())
                .then(data => {
                    if (data.success) {
                        this.dataset.isFavorite = data.is_favorite ? 'true' : 'false';
                        this.innerHTML = data.is_favorite ? '❤️' : '🤍';
                        this.classList.toggle('active', data.is_favorite);
                    }
                })
                .catch(error => console.error('Error:', error));
            });
        });
    </script>
</body>
</html>