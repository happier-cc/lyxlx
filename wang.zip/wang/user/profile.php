<?php
require_once '../config/database.php';

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

// 获取用户ID
$profile_user_id = $_GET['user_id'] ?? $_SESSION['user_id'];

// 如果是普通用户查看他人资料，重定向到首页
if ($_SESSION['role'] != 'admin' && $profile_user_id != $_SESSION['user_id']) {
    header("Location: index.php");
    exit();
}

// 获取用户信息
$user_stmt = $pdo->prepare("SELECT * FROM users WHERE id = ?");
$user_stmt->execute([$profile_user_id]);
$profile_user = $user_stmt->fetch();

if (!$profile_user) {
    die("<div class='container'><div class='card text-center'><h2>用户不存在！</h2><a href='index.php' class='btn btn-primary'>返回首页</a></div></div>");
}

// 获取用户学习统计
$progress_stats = $pdo->prepare("
    SELECT 
        COUNT(DISTINCT p.id) as total_projects,
        COUNT(DISTINCT up.project_id) as completed_projects,
        AVG(up.score) as avg_score,
        MAX(up.completed_at) as last_study_time
    FROM projects p
    LEFT JOIN user_progress up ON p.id = up.project_id AND up.user_id = ? AND up.completed = TRUE
");
$progress_stats->execute([$profile_user_id]);
$stats = $progress_stats->fetch();

// 获取错题统计
$wrong_stats = $pdo->prepare("
    SELECT 
        COUNT(*) as total_wrong,
        COUNT(DISTINCT project_id) as wrong_projects,
        COUNT(DISTINCT question_id) as wrong_questions,
        MAX(created_at) as last_wrong_time
    FROM wrong_questions 
    WHERE user_id = ?
");
$wrong_stats->execute([$profile_user_id]);
$wrong_data = $wrong_stats->fetch();

// 获取收藏题目统计
$favorite_stats = $pdo->prepare("
    SELECT COUNT(*) as total_favorites
    FROM favorite_questions 
    WHERE user_id = ?
");
$favorite_stats->execute([$profile_user_id]);
$favorite_data = $favorite_stats->fetch();

// 获取最近学习记录
$recent_progress = $pdo->prepare("
    SELECT up.*, p.project_name, m.module_name, c.course_name 
    FROM user_progress up 
    JOIN projects p ON up.project_id = p.id 
    JOIN modules m ON p.module_id = m.id
    JOIN courses c ON m.course_id = c.id
    WHERE up.user_id = ? AND up.completed = TRUE 
    ORDER BY up.completed_at DESC 
    LIMIT 10
");
$recent_progress->execute([$profile_user_id]);
$recent_studies = $recent_progress->fetchAll();

// 获取错题分布
$wrong_distribution = $pdo->prepare("
    SELECT 
        c.id as course_id,
        c.course_name,
        COUNT(wq.id) as wrong_count
    FROM wrong_questions wq
    JOIN projects p ON wq.project_id = p.id
    JOIN modules m ON p.module_id = m.id
    JOIN courses c ON m.course_id = c.id
    WHERE wq.user_id = ?
    GROUP BY c.id, c.course_name
    ORDER BY wrong_count DESC
    LIMIT 10
");
$wrong_distribution->execute([$profile_user_id]);
$wrong_courses = $wrong_distribution->fetchAll();
?>

<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
    <title><?php echo htmlspecialchars($profile_user['username']); ?> - 用户详情</title>
    <link rel="stylesheet" href="../config/style.css">
    <style>
        .profile-header {
            background: linear-gradient(135deg, var(--primary-color), var(--secondary-color));
            color: white;
            padding: 30px 20px;
            border-radius: 12px;
            margin-bottom: 24px;
            text-align: center;
        }
        
        .user-avatar {
            width: 80px;
            height: 80px;
            border-radius: 50%;
            background: rgba(255, 255, 255, 0.2);
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 32px;
            margin: 0 auto 16px;
        }
        
        .username {
            font-size: 24px;
            font-weight: 700;
            margin-bottom: 8px;
        }
        
        .user-role {
            display: inline-block;
            padding: 4px 12px;
            background: rgba(255, 255, 255, 0.2);
            border-radius: 20px;
            font-size: 14px;
        }
        
        /* 响应式统计网格 */
        .stats-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 16px;
            margin-bottom: 24px;
        }
        
        .stat-card {
            background: white;
            padding: 20px;
            border-radius: 12px;
            box-shadow: var(--shadow);
            text-align: center;
            transition: transform 0.2s ease;
        }
        
        .stat-card:hover {
            transform: translateY(-2px);
            box-shadow: 0 8px 16px rgba(0,0,0,0.1);
        }
        
        .stat-number {
            font-size: 32px;
            font-weight: 700;
            color: var(--primary-color);
            margin-bottom: 8px;
        }
        
        .stat-label {
            color: var(--text-secondary);
            font-size: 14px;
        }
        
        .section {
            background: white;
            padding: 24px;
            border-radius: 12px;
            box-shadow: var(--shadow);
            margin-bottom: 24px;
        }
        
        .section-title {
            font-size: 18px;
            font-weight: 600;
            margin-bottom: 16px;
            color: var(--text-primary);
            border-bottom: 2px solid var(--bg-primary);
            padding-bottom: 8px;
        }
        
        /* 学习记录和错题分布的网格布局 */
        .progress-grid, .wrong-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
            gap: 16px;
        }
        
        .progress-item, .wrong-item {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 16px;
            background: var(--bg-tertiary);
            border-radius: 8px;
            border-left: 4px solid var(--primary-color);
            transition: transform 0.2s ease;
        }
        
        .wrong-item {
            border-left-color: var(--error-color);
        }
        
        .progress-item:hover, .wrong-item:hover {
            transform: translateY(-2px);
            box-shadow: 0 4px 8px rgba(0,0,0,0.1);
        }
        
        .course-name {
            font-weight: 600;
            color: var(--text-primary);
            margin-bottom: 4px;
        }
        
        .project-path {
            font-size: 12px;
            color: var(--text-secondary);
        }
        
        .progress-score {
            font-weight: 700;
            color: var(--primary-color);
            font-size: 18px;
        }
        
        .wrong-count {
            font-weight: 700;
            color: var(--error-color);
            font-size: 18px;
        }
        
        .study-time {
            font-size: 12px;
            color: var(--text-secondary);
        }
        
        .progress-content, .wrong-content {
            flex: 1;
        }
        
        .progress-meta, .wrong-meta {
            text-align: right;
        }
        
        .empty-state {
            text-align: center;
            padding: 40px 20px;
            color: var(--text-secondary);
            grid-column: 1 / -1;
        }
        
        .action-buttons {
            display: flex;
            gap: 12px;
            margin-top: 20px;
            flex-wrap: wrap;
        }
        
        /* 移动端适配 */
        @media (max-width: 768px) {
            .stats-grid {
                grid-template-columns: repeat(2, 1fr);
            }
            
            .progress-grid, .wrong-grid {
                grid-template-columns: 1fr;
            }
            
            .profile-header {
                text-align: center;
                padding: 20px;
            }
            
            .action-buttons {
                flex-direction: column;
            }
            
            .action-buttons .btn {
                width: 100%;
                text-align: center;
            }
            
            .progress-item, .wrong-item {
                flex-direction: column;
                align-items: flex-start;
                gap: 12px;
            }
            
            .progress-meta, .wrong-meta {
                text-align: left;
                width: 100%;
                display: flex;
                justify-content: space-between;
                align-items: center;
            }
        }
        
        @media (min-width: 769px) and (max-width: 1024px) {
            .progress-grid, .wrong-grid {
                grid-template-columns: repeat(2, 1fr);
            }
        }
        
        @media (min-width: 1025px) {
            .progress-grid, .wrong-grid {
                grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
            }
        }
        
        @media (max-width: 480px) {
            .stats-grid {
                grid-template-columns: 1fr 1fr;
            }
            
            .stat-card {
                padding: 16px;
            }
            
            .stat-number {
                font-size: 24px;
            }
        }
    </style>
</head>
<body>
    <nav class="navbar">
        <div class="container">
            <div class="nav-content">
                <?php if ($_SESSION['role'] == 'admin'): ?>
                    <a href="../admin/manage_users.php" class="nav-brand">← 返回用户管理</a>
                <?php else: ?>
                    <a href="index.php" class="nav-brand">← 返回学习中心</a>
                <?php endif; ?>
                <span class="nav-brand">用户详情</span>
            </div>
        </div>
    </nav>

    <div class="container">
        <!-- 用户基本信息 -->
        <div class="profile-header">
            <div class="user-avatar">
                <?php echo substr($profile_user['username'], 0, 1); ?>
            </div>
            <div class="username"><?php echo htmlspecialchars($profile_user['username']); ?></div>
            <div class="user-role">
                <?php echo $profile_user['role'] == 'admin' ? '管理员' : '普通用户'; ?>
                <?php if ($profile_user['status'] == 'disabled'): ?>
                    <span style="color: #fecaca; margin-left: 8px;">(已禁用)</span>
                <?php endif; ?>
            </div>
            <div style="margin-top: 12px; font-size: 14px; opacity: 0.8;">
                注册时间：<?php echo date('Y年m月d日', strtotime($profile_user['created_at'])); ?>
                <?php if ($profile_user['last_login']): ?>
                    | 最后登录：<?php echo date('Y年m月d日 H:i', strtotime($profile_user['last_login'])); ?>
                <?php endif; ?>
            </div>
        </div>

        <!-- 学习统计 -->
        <div class="stats-grid">
            <div class="stat-card">
                <div class="stat-number"><?php echo $stats['completed_projects'] ?? 0; ?></div>
                <div class="stat-label">完成项目</div>
            </div>
            <div class="stat-card">
                <div class="stat-number"><?php echo $stats['avg_score'] ? round($stats['avg_score'], 1) : '0'; ?></div>
                <div class="stat-label">平均分数</div>
            </div>
            <div class="stat-card">
                <div class="stat-number"><?php echo $wrong_data['total_wrong'] ?? 0; ?></div>
                <div class="stat-label">错题数量</div>
            </div>
            <div class="stat-card">
                <div class="stat-number"><?php echo $favorite_data['total_favorites'] ?? 0; ?></div>
                <div class="stat-label">收藏题目</div>
            </div>
        </div>

        <!-- 最近学习记录 -->
        <div class="section">
            <div class="section-title">最近学习记录</div>
            <?php if (empty($recent_studies)): ?>
                <div class="empty-state">
                    <p>暂无学习记录</p>
                </div>
            <?php else: ?>
                <div class="progress-grid">
                    <?php foreach ($recent_studies as $progress): ?>
                        <div class="progress-item">
                            <div class="progress-content">
                                <div class="course-name"><?php echo htmlspecialchars($progress['project_name']); ?></div>
                                <div class="project-path">
                                    <?php echo htmlspecialchars($progress['course_name']); ?> &gt; 
                                    <?php echo htmlspecialchars($progress['module_name']); ?>
                                </div>
                                <div class="study-time">
                                    <?php echo date('m月d日 H:i', strtotime($progress['completed_at'])); ?>
                                </div>
                            </div>
                            <div class="progress-meta">
                                <div class="progress-score"><?php echo $progress['score']; ?>分</div>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>
            <?php endif; ?>
        </div>

        <!-- 错题分布 -->
        <div class="section">
            <div class="section-title">错题分布</div>
            <?php if (empty($wrong_courses)): ?>
                <div class="empty-state">
                    <p>暂无错题记录</p>
                </div>
            <?php else: ?>
                <div class="wrong-grid">
                    <?php foreach ($wrong_courses as $course): ?>
                        <div class="wrong-item">
                            <div class="wrong-content">
                                <div class="course-name"><?php echo htmlspecialchars($course['course_name']); ?></div>
                            </div>
                            <div class="wrong-meta">
                                <div class="wrong-count"><?php echo $course['wrong_count']; ?> 题</div>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>
            <?php endif; ?>
        </div>

        <!-- 操作按钮 -->
        <div class="action-buttons">
            <?php if ($_SESSION['role'] == 'admin'): ?>
                <a href="../admin/manage_users.php" class="btn btn-outline">返回用户管理</a>
                <?php if ($profile_user['status'] == 'active'): ?>
                    <a href="../admin/manage_users.php?toggle_status=<?php echo $profile_user['id']; ?>&action=disable" 
                       class="btn btn-warning"
                       onclick="return confirm('确定要禁用该用户吗？')">
                       禁用用户
                    </a>
                <?php else: ?>
                    <a href="../admin/manage_users.php?toggle_status=<?php echo $profile_user['id']; ?>&action=enable" 
                       class="btn btn-success"
                       onclick="return confirm('确定要启用该用户吗？')">
                       启用用户
                    </a>
                <?php endif; ?>
                <?php if ($profile_user['id'] != $_SESSION['user_id']): ?>
                    <a href="../admin/manage_users.php?delete=<?php echo $profile_user['id']; ?>" 
                       class="btn btn-error"
                       onclick="return confirm('确定要删除该用户吗？此操作不可恢复！')">
                       删除用户
                    </a>
                <?php endif; ?>
            <?php else: ?>
                <a href="wrong_questions.php" class="btn btn-primary">查看我的错题</a>
                <a href="favorites.php" class="btn btn-warning">查看我的收藏</a>
                <a href="index.php" class="btn btn-outline">返回学习中心</a>
            <?php endif; ?>
        </div>
    </div>

    <script>
        // 页面加载动画
        document.addEventListener('DOMContentLoaded', function() {
            // 统计卡片动画
            const statCards = document.querySelectorAll('.stat-card');
            statCards.forEach((card, index) => {
                card.style.opacity = '0';
                card.style.transform = 'translateY(20px)';
                setTimeout(() => {
                    card.style.transition = 'all 0.5s ease';
                    card.style.opacity = '1';
                    card.style.transform = 'translateY(0)';
                }, index * 100);
            });
            
            // 进度项动画
            const progressItems = document.querySelectorAll('.progress-item, .wrong-item');
            progressItems.forEach((item, index) => {
                item.style.opacity = '0';
                item.style.transform = 'translateX(-20px)';
                setTimeout(() => {
                    item.style.transition = 'all 0.5s ease';
                    item.style.opacity = '1';
                    item.style.transform = 'translateX(0)';
                }, index * 50 + 300);
            });
        });
    </script>
</body>
</html>