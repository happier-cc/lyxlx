<?php
require_once '../config/database.php';

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

$project_id = $_GET['project_id'] ?? 'all';
$course_id = $_GET['course_id'] ?? 'all';

// 获取收藏题目用于刷题
if ($project_id == 'all') {
    if ($course_id == 'all') {
        $favorites_stmt = $pdo->prepare("
            SELECT q.*, p.project_name, m.module_name, c.course_name, p.id as actual_project_id
            FROM favorite_questions fq 
            JOIN questions q ON fq.question_id = q.id 
            JOIN projects p ON fq.project_id = p.id
            JOIN modules m ON p.module_id = m.id
            JOIN courses c ON m.course_id = c.id
            WHERE fq.user_id = ?
            ORDER BY RAND()
        ");
        $favorites_stmt->execute([$_SESSION['user_id']]);
    } else {
        $favorites_stmt = $pdo->prepare("
            SELECT q.*, p.project_name, m.module_name, c.course_name, p.id as actual_project_id
            FROM favorite_questions fq 
            JOIN questions q ON fq.question_id = q.id 
            JOIN projects p ON fq.project_id = p.id
            JOIN modules m ON p.module_id = m.id
            JOIN courses c ON m.course_id = c.id
            WHERE fq.user_id = ? AND c.id = ?
            ORDER BY RAND()
        ");
        $favorites_stmt->execute([$_SESSION['user_id'], $course_id]);
    }
} else {
    $favorites_stmt = $pdo->prepare("
        SELECT q.*, p.project_name, m.module_name, c.course_name, p.id as actual_project_id
        FROM favorite_questions fq 
        JOIN questions q ON fq.question_id = q.id 
        JOIN projects p ON fq.project_id = p.id
        JOIN modules m ON p.module_id = m.id
        JOIN courses c ON m.course_id = c.id
        WHERE fq.user_id = ? AND fq.project_id = ?
        ORDER BY RAND()
    ");
    $favorites_stmt->execute([$_SESSION['user_id'], $project_id]);
}

$favorite_questions = $favorites_stmt->fetchAll();

if (empty($favorite_questions)) {
    header("Location: favorites.php");
    exit();
}

// 获取课程/项目信息用于显示标题
$title_info = '';
if ($project_id != 'all') {
    $info_stmt = $pdo->prepare("
        SELECT p.project_name, m.module_name, c.course_name 
        FROM projects p 
        JOIN modules m ON p.module_id = m.id 
        JOIN courses c ON m.course_id = c.id 
        WHERE p.id = ?
    ");
    $info_stmt->execute([$project_id]);
    $info = $info_stmt->fetch();
    if ($info) {
        $title_info = htmlspecialchars($info['course_name'] . ' - ' . $info['module_name'] . ' - ' . $info['project_name']);
    }
} elseif ($course_id != 'all') {
    $info_stmt = $pdo->prepare("SELECT course_name FROM courses WHERE id = ?");
    $info_stmt->execute([$course_id]);
    $info = $info_stmt->fetch();
    if ($info) {
        $title_info = htmlspecialchars($info['course_name']);
    }
}

// 处理提交答案
if ($_SERVER['REQUEST_METHOD'] == 'POST' && !isset($_POST['toggle_favorite'])) {
    $correct_count = 0;
    
    foreach ($favorite_questions as $question) {
        $user_answer = $_POST['answer_' . $question['id']] ?? '';
        $is_correct = ($user_answer == $question['correct_answer']);
        
        if ($is_correct) {
            $correct_count++;
        }
    }
    
    $total = count($favorite_questions);
    ?>
    <!DOCTYPE html>
    <html lang="zh-CN">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
        <title>收藏题练习完成 - 多课程在线刷题系统</title>
        <link rel="stylesheet" href="../config/style.css">
        <style>
            .result-card {
                text-align: center;
                padding: 40px 20px;
            }
            
            .result-icon {
                font-size: 64px;
                margin-bottom: 20px;
            }
            
            .result-stats {
                display: grid;
                grid-template-columns: repeat(2, 1fr);
                gap: 16px;
                margin: 24px 0;
            }
            
            .stat-item {
                background: var(--bg-tertiary);
                padding: 16px;
                border-radius: 12px;
                text-align: center;
            }
            
            .stat-value {
                font-size: 24px;
                font-weight: 700;
            }
            
            .stat-correct {
                color: var(--success-color);
            }
            
            .stat-total {
                color: #e67e22;
            }
            
            .stat-accuracy {
                color: var(--primary-color);
            }
        </style>
    </head>
    <body>
        <nav class="navbar">
            <div class="container">
                <div class="nav-content">
                    <a href="favorites.php" class="nav-brand">← 返回收藏夹</a>
                    <span class="nav-brand">练习结果</span>
                </div>
            </div>
        </nav>

        <div class="container">
            <div class="card result-card">
                <div class="result-icon">🏆</div>
                <h2>收藏题练习完成！</h2>
                
                <div class="result-stats">
                    <div class="stat-item">
                        <div class="stat-value stat-correct"><?php echo $correct_count; ?></div>
                        <div>做对题数</div>
                    </div>
                    <div class="stat-item">
                        <div class="stat-value stat-total"><?php echo $total; ?></div>
                        <div>总题数</div>
                    </div>
                </div>
                
                <div class="stat-item" style="grid-column: span 2; margin-top: 0;">
                    <div class="stat-value stat-accuracy"><?php echo $total > 0 ? round(($correct_count / $total) * 100, 1) : 0; ?>%</div>
                    <div>正确率</div>
                </div>
                
                <div class="action-buttons" style="display: grid; gap: 12px; margin-top: 32px;">
                    <a href="favorites.php" class="btn btn-primary btn-full">返回收藏夹</a>
                    <a href="review_favorites.php?course_id=<?php echo $course_id; ?>&project_id=<?php echo $project_id; ?>" class="btn btn-outline btn-full">重新练习</a>
                </div>
            </div>
        </div>
    </body>
    </html>
    <?php
    exit();
}
?>

<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
    <title>刷收藏题<?php echo $title_info ? ' - ' . $title_info : ''; ?> - 多课程在线刷题系统</title>
    <link rel="stylesheet" href="../config/style.css">
    <style>
        .review-header {
            background: linear-gradient(135deg, #e67e22, #e74c3c);
            color: white;
            padding: 20px;
            border-radius: 12px;
            margin-bottom: 20px;
            text-align: center;
        }
        
        .question-card {
            background: #fff9e6;
            border: 2px solid #ffeaa7;
            border-radius: 12px;
            padding: 20px;
            margin-bottom: 16px;
            position: relative;
        }
        
        .project-path {
            background: #e8f5e8;
            padding: 4px 8px;
            border-radius: 6px;
            font-size: 12px;
            margin-bottom: 12px;
        }
        
        .favorite-btn {
            background: none;
            border: none;
            font-size: 20px;
            cursor: pointer;
            transition: transform 0.3s ease;
            display: flex;
            align-items: center;
            justify-content: center;
            width: 36px;
            height: 36px;
            margin: 0 auto;
        }
        
        .favorite-btn:hover {
            transform: scale(1.2);
        }
        
        .favorite-btn.active {
            color: #e74c3c;
        }
        
        .progress-info {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 12px;
            font-size: 14px;
            color: var(--text-secondary);
            position: relative;
        }
        
        .progress-center {
            position: absolute;
            left: 50%;
            transform: translateX(-50%);
            display: flex;
            align-items: center;
        }
        
        .question-counter {
            font-weight: 600;
            color: var(--text-primary);
        }
        
        .progress-bar {
            height: 6px;
            background: var(--bg-tertiary);
            border-radius: 3px;
            overflow: hidden;
            margin-bottom: 20px;
        }
        
        .progress-fill {
            height: 100%;
            background: linear-gradient(135deg, #e67e22, #e74c3c);
            transition: width 0.3s ease;
        }
        
        @media (max-width: 640px) {
            .favorite-btn {
                width: 32px;
                height: 32px;
                font-size: 18px;
            }
            
            .progress-info {
                font-size: 13px;
            }
        }
    </style>
</head>
<body>
    <nav class="navbar">
        <div class="container">
            <div class="nav-content">
                <a href="favorites.php" class="nav-brand">← 返回收藏夹</a>
                <span class="nav-brand">刷收藏题<?php echo $title_info ? '<br><small>' . $title_info . '</small>' : ''; ?></span>
            </div>
        </div>
    </nav>

    <div class="container">
        <div class="review-header">
            <h2>刷收藏题</h2>
            <p>共 <?php echo count($favorite_questions); ?> 道收藏题目</p>
            <?php if ($title_info): ?>
                <p><small><?php echo $title_info; ?></small></p>
            <?php endif; ?>
        </div>

        <form method="post" id="reviewForm">
            <?php foreach ($favorite_questions as $index => $question): ?>
                <div class="question-card">
                    <div class="project-path">
                        <?php echo htmlspecialchars($question['course_name']); ?> &gt; 
                        <?php echo htmlspecialchars($question['module_name']); ?> &gt; 
                        <?php echo htmlspecialchars($question['project_name']); ?>
                    </div>
                    
                    <div class="progress-info">
                        <span class="question-counter">题目 <?php echo $index + 1; ?> / <?php echo count($favorite_questions); ?></span>
                        
                        <!-- 收藏按钮居中显示 -->
                        <div class="progress-center">
                            <button type="button" class="favorite-btn active" data-question-id="<?php echo $question['id']; ?>" data-is-favorite="true">
                                ❤️
                            </button>
                        </div>
                    </div>
                    
                    <div class="progress-bar">
                        <div class="progress-fill" style="width: <?php echo (($index + 1) / count($favorite_questions)) * 100; ?>%"></div>
                    </div>
                    
                    <div class="question-text">
                        <?php echo htmlspecialchars($question['question_text']); ?>
                    </div>
                    
                    <div class="options-grid">
                        <?php foreach (['A', 'B', 'C', 'D'] as $option): ?>
                            <?php if (!empty($question['option_' . strtolower($option)])): ?>
                                <label class="option-item">
                                    <input type="radio" name="answer_<?php echo $question['id']; ?>" value="<?php echo $option; ?>" class="option-input" required>
                                    <span class="option-label">
                                        <strong><?php echo $option; ?>.</strong> 
                                        <?php echo htmlspecialchars($question['option_' . strtolower($option)]); ?>
                                    </span>
                                </label>
                            <?php endif; ?>
                        <?php endforeach; ?>
                    </div>
                </div>
            <?php endforeach; ?>
            
            <div class="text-center">
                <button type="submit" class="btn btn-success btn-full" style="background: linear-gradient(135deg, #e67e22, #e74c3c); border: none;">提交答案</button>
            </div>
        </form>
    </div>
</body>
</html>