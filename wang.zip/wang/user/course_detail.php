<?php
require_once '../config/database.php';

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

$course_id = $_GET['course_id'] ?? 0;

// 获取课程信息
$course_stmt = $pdo->prepare("SELECT * FROM courses WHERE id = ? AND status = 'active'");
$course_stmt->execute([$course_id]);
$course = $course_stmt->fetch();

if (!$course) {
    header("Location: index.php");
    exit();
}

// 获取课程下的模块
$modules_stmt = $pdo->prepare("SELECT * FROM modules WHERE course_id = ? ORDER BY sort_order, id");
$modules_stmt->execute([$course_id]);
$modules = $modules_stmt->fetchAll();

// 获取用户在该课程的学习统计
$course_stats_stmt = $pdo->prepare("
    SELECT 
        COUNT(DISTINCT p.id) as total_projects,
        COUNT(DISTINCT up.project_id) as completed_projects,
        AVG(up.score) as avg_score
    FROM projects p
    JOIN modules m ON p.module_id = m.id
    LEFT JOIN user_progress up ON p.id = up.project_id AND up.user_id = ? AND up.completed = TRUE
    WHERE m.course_id = ?
");
$course_stats_stmt->execute([$_SESSION['user_id'], $course_id]);
$course_stats = $course_stats_stmt->fetch();
?>

<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
    <title><?php echo htmlspecialchars($course['course_name']); ?> - 学习详情</title>
    <link rel="stylesheet" href="../config/style.css">
    <style>
        .course-header {
            background: linear-gradient(135deg, var(--primary-color), var(--secondary-color));
            color: white;
            padding: 30px;
            border-radius: 12px;
            margin-bottom: 24px;
            text-align: center;
        }
        
        .course-title {
            font-size: 28px;
            font-weight: 700;
            margin-bottom: 8px;
        }
        
        .course-description {
            font-size: 16px;
            opacity: 0.9;
            margin-bottom: 20px;
            max-width: 600px;
            margin-left: auto;
            margin-right: auto;
        }
        
        .course-stats {
            display: grid;
            grid-template-columns: repeat(3, 1fr);
            gap: 16px;
            margin-top: 24px;
        }
        
        .course-stat {
            background: rgba(255, 255, 255, 0.2);
            padding: 16px;
            border-radius: 12px;
            text-align: center;
            backdrop-filter: blur(10px);
        }
        
        .stat-number {
            font-size: 24px;
            font-weight: 700;
            margin-bottom: 4px;
        }
        
        .stat-label {
            font-size: 14px;
            opacity: 0.9;
        }
        
        /* 模块列表样式 */
        .module-list {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
            gap: 16px;
        }
        
        .module-item {
            background: var(--bg-primary);
            border-radius: 12px;
            padding: 20px;
            box-shadow: var(--shadow);
            border-left: 4px solid #e67e22;
            transition: transform 0.2s ease;
        }
        
        .module-item:hover {
            transform: translateY(-2px);
            box-shadow: 0 8px 16px rgba(0,0,0,0.1);
        }
        
        .module-header {
            display: flex;
            justify-content: space-between;
            align-items: flex-start;
            margin-bottom: 12px;
        }
        
        .module-title {
            font-size: 18px;
            font-weight: 600;
            color: var(--text-primary);
            flex: 1;
        }
        
        .module-progress {
            font-size: 14px;
            padding: 4px 12px;
            border-radius: 20px;
            background: var(--success-color);
            color: white;
        }
        
        .module-progress.partial {
            background: var(--warning-color);
        }
        
        .module-progress.pending {
            background: var(--text-secondary);
        }
        
        .module-desc {
            color: var(--text-secondary);
            font-size: 14px;
            margin-bottom: 16px;
        }
        
        .module-stats {
            display: flex;
            justify-content: space-between;
            margin: 15px 0;
            padding: 15px 0;
            border-top: 1px solid var(--border-color);
            border-bottom: 1px solid var(--border-color);
        }
        
        .module-stat {
            text-align: center;
            flex: 1;
        }
        
        .module-stat-number {
            font-size: 16px;
            font-weight: 700;
            color: var(--primary-color);
        }
        
        .module-stat-label {
            font-size: 12px;
            color: var(--text-secondary);
        }
        
        .module-actions {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-top: 15px;
        }
        
        .module-completion {
            font-size: 14px;
            color: var(--text-secondary);
        }
        
        /* 移动端适配 */
        @media (max-width: 768px) {
            .course-stats {
                grid-template-columns: 1fr;
            }
            
            .module-list {
                grid-template-columns: 1fr;
            }
            
            .module-stats {
                flex-direction: column;
                gap: 10px;
            }
            
            .module-actions {
                flex-direction: column;
                gap: 10px;
                align-items: stretch;
            }
        }
    </style>
</head>
<body>
    <nav class="navbar">
        <div class="container">
            <div class="nav-content">
                <a href="index.php" class="nav-brand">← 返回学习中心</a>
                <span class="nav-brand"><?php echo htmlspecialchars($course['course_name']); ?></span>
            </div>
        </div>
    </nav>

    <div class="container">
        <!-- 课程头部信息 -->
        <div class="course-header">
            <h1 class="course-title"><?php echo htmlspecialchars($course['course_name']); ?></h1>
            <p class="course-description"><?php echo htmlspecialchars($course['description']); ?></p>
            
            <div class="course-stats">
                <div class="course-stat">
                    <div class="stat-number"><?php echo count($modules); ?></div>
                    <div class="stat-label">学习模块</div>
                </div>
                <div class="course-stat">
                    <div class="stat-number"><?php echo $course_stats['total_projects'] ?? 0; ?></div>
                    <div class="stat-label">刷题项目</div>
                </div>
                <div class="course-stat">
                    <div class="stat-number"><?php echo $course_stats['completed_projects'] ? round(($course_stats['completed_projects'] / $course_stats['total_projects']) * 100) : 0; ?>%</div>
                    <div class="stat-label">完成进度</div>
                </div>
            </div>
        </div>

        <!-- 模块列表 -->
        <h2 class="mb-3">学习模块</h2>
        <div class="module-list">
            <?php foreach ($modules as $module): 
                // 获取模块下的项目数量
                $projects_stmt = $pdo->prepare("SELECT COUNT(*) as project_count FROM projects WHERE module_id = ?");
                $projects_stmt->execute([$module['id']]);
                $project_count = $projects_stmt->fetchColumn();
                
                // 获取用户在该模块中完成的项目数量
                $completed_projects_stmt = $pdo->prepare("
                    SELECT COUNT(*) as completed_count 
                    FROM user_progress up 
                    JOIN projects p ON up.project_id = p.id 
                    WHERE up.user_id = ? AND up.completed = TRUE AND p.module_id = ?
                ");
                $completed_projects_stmt->execute([$_SESSION['user_id'], $module['id']]);
                $completed_count = $completed_projects_stmt->fetchColumn();
                
                // 计算模块进度
                $progress = $project_count > 0 ? round(($completed_count / $project_count) * 100) : 0;
                
                // 确定进度状态
                $progress_class = '';
                if ($progress == 0) {
                    $progress_class = 'pending';
                } elseif ($progress < 100) {
                    $progress_class = 'partial';
                }
            ?>
                <div class="module-item">
                    <div class="module-header">
                        <div class="module-title"><?php echo htmlspecialchars($module['module_name']); ?></div>
                        <div class="module-progress <?php echo $progress_class; ?>">
                            <?php echo $progress; ?>%
                        </div>
                    </div>
                    <div class="module-desc">
                        <?php echo htmlspecialchars($module['description']); ?>
                    </div>
                    
                    <div class="module-stats">
                        <div class="module-stat">
                            <div class="module-stat-number"><?php echo $project_count; ?></div>
                            <div class="module-stat-label">学习项目</div>
                        </div>
                        <div class="module-stat">
                            <div class="module-stat-number"><?php echo $completed_count; ?></div>
                            <div class="module-stat-label">已完成</div>
                        </div>
                    </div>
                    
                    <div class="module-actions">
                        <div class="module-completion">
                            <?php if ($completed_count > 0): ?>
                                进度: <?php echo $completed_count; ?>/<?php echo $project_count; ?>
                            <?php else: ?>
                                尚未开始
                            <?php endif; ?>
                        </div>
                        <a href="module_detail.php?module_id=<?php echo $module['id']; ?>" class="btn btn-primary btn-sm">
                            <?php echo $completed_count > 0 ? '继续学习' : '开始学习'; ?>
                        </a>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
        
        <?php if (empty($modules)): ?>
            <div class="card text-center" style="padding: 40px 20px;">
                <div style="font-size: 48px; margin-bottom: 16px;">📂</div>
                <h3>暂无学习模块</h3>
                <p>该课程还没有添加学习模块</p>
            </div>
        <?php endif; ?>
    </div>

    <script>
        // 页面加载动画
        document.addEventListener('DOMContentLoaded', function() {
            const moduleItems = document.querySelectorAll('.module-item');
            moduleItems.forEach((item, index) => {
                item.style.opacity = '0';
                item.style.transform = 'translateY(20px)';
                setTimeout(() => {
                    item.style.transition = 'all 0.5s ease';
                    item.style.opacity = '1';
                    item.style.transform = 'translateY(0)';
                }, index * 100);
            });
        });
    </script>
</body>
</html>