<?php
// change_password.php
require_once '../config/database.php';

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

$user_id = $_SESSION['user_id'];
$message = '';
$message_type = '';

// 处理表单提交
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $current_password = $_POST['current_password'];
    $new_password = $_POST['new_password'];
    $confirm_password = $_POST['confirm_password'];
    
    // 验证当前密码
    $check_stmt = $pdo->prepare("SELECT password FROM users WHERE id = ?");
    $check_stmt->execute([$user_id]);
    $user_data = $check_stmt->fetch();
    
    if (!$user_data || !password_verify($current_password, $user_data['password'])) {
        $message = "当前密码错误";
        $message_type = 'error';
    } elseif (empty($new_password)) {
        $message = "新密码不能为空";
        $message_type = 'error';
    } elseif (strlen($new_password) < 6) {
        $message = "新密码长度不能少于6位";
        $message_type = 'error';
    } elseif ($new_password !== $confirm_password) {
        $message = "两次输入的新密码不一致";
        $message_type = 'error';
    } else {
        // 更新密码
        $hashed_password = password_hash($new_password, PASSWORD_DEFAULT);
        $update_stmt = $pdo->prepare("UPDATE users SET password = ? WHERE id = ?");
        
        if ($update_stmt->execute([$hashed_password, $user_id])) {
            $message = "密码更新成功";
            $message_type = 'success';
            
            // 清空表单
            $_POST = [];
        } else {
            $message = "密码更新失败，请稍后重试";
            $message_type = 'error';
        }
    }
}
?>

<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>修改密码 - 多课程在线刷题系统</title>
    <link rel="stylesheet" href="../config/style.css">
    <style>
        .password-container {
            max-width: 500px;
            margin: 50px auto;
            padding: 20px;
        }
        .password-section {
            background: white;
            padding: 25px;
            border-radius: 12px;
            box-shadow: var(--shadow);
        }
        .form-group {
            margin-bottom: 20px;
        }
        .form-group label {
            display: block;
            margin-bottom: 8px;
            font-weight: 600;
        }
        .form-group input {
            width: 100%;
            padding: 10px;
            border: 1px solid var(--border-color);
            border-radius: 6px;
            font-size: 14px;
            box-sizing: border-box;
        }
        .btn-update {
            background: var(--primary-color);
            color: white;
            padding: 12px 30px;
            border: none;
            border-radius: 6px;
            cursor: pointer;
            font-size: 16px;
            transition: background 0.3s;
            width: 100%;
        }
        .btn-update:hover {
            background: var(--secondary-color);
        }
        .message {
            padding: 15px;
            border-radius: 6px;
            margin: 20px 0;
        }
        .message.success {
            background: #d4edda;
            color: #155724;
            border: 1px solid #c3e6cb;
        }
        .message.error {
            background: #f8d7da;
            color: #721c24;
            border: 1px solid #f5c6cb;
        }
        .password-requirements {
            font-size: 12px;
            color: var(--text-secondary);
            margin-top: 5px;
        }
        .security-tips {
            background: #fff3cd;
            border: 1px solid #ffeaa7;
            padding: 15px;
            border-radius: 6px;
            margin: 20px 0;
            font-size: 14px;
        }
        .back-link {
            display: inline-block;
            margin-top: 15px;
            color: var(--primary-color);
            text-decoration: none;
        }
        .back-link:hover {
            text-decoration: underline;
        }
    </style>
</head>
<body>
    <nav class="navbar">
        <div class="container">
            <div class="nav-content">
                <a href="index.php" class="nav-brand">📚 多课程刷题系统</a>
                <div class="nav-menu">
                    <span style="color: var(--text-secondary);">欢迎, <?php echo htmlspecialchars($_SESSION['username']); ?></span>
                    <a href="index.php" class="nav-link">学习中心</a>
                    <a href="logout.php" class="nav-link">退出</a>
                </div>
            </div>
        </div>
    </nav>

    <div class="container">
        <div class="password-container">
            <div class="password-section">
                <h1>修改密码</h1>
                <p>请谨慎操作，确保密码安全</p>
                
                <?php if ($message): ?>
                    <div class="message <?php echo $message_type; ?>">
                        <?php echo htmlspecialchars($message); ?>
                    </div>
                <?php endif; ?>
                
                <div class="security-tips">
                    <strong>🔒 安全提示：</strong>
                    <ul style="margin: 8px 0 0 20px;">
                        <li>密码长度至少6位</li>
                        <li>建议使用字母、数字和符号的组合</li>
                        <li>定期更换密码以提高安全性</li>
                    </ul>
                </div>
                
                <form method="post">
                    <div class="form-group">
                        <label for="current_password">当前密码：</label>
                        <input type="password" id="current_password" name="current_password" 
                               placeholder="请输入当前密码" required>
                    </div>
                    
                    <div class="form-group">
                        <label for="new_password">新密码：</label>
                        <input type="password" id="new_password" name="new_password" 
                               placeholder="请输入新密码（至少6位）" required>
                        <div class="password-requirements">密码长度至少6位</div>
                    </div>
                    
                    <div class="form-group">
                        <label for="confirm_password">确认新密码：</label>
                        <input type="password" id="confirm_password" name="confirm_password" 
                               placeholder="请再次输入新密码" required>
                    </div>
                    
                    <button type="submit" class="btn-update">更新密码</button>
                </form>
                
                <a href="index.php" class="back-link">← 返回学习中心</a>
            </div>
        </div>
    </div>

    <script>
        // 客户端验证
        document.querySelector('form').addEventListener('submit', function(e) {
            const newPassword = document.getElementById('new_password').value;
            const confirmPassword = document.getElementById('confirm_password').value;
            
            if (newPassword.length < 6) {
                alert('新密码长度不能少于6位');
                e.preventDefault();
                return;
            }
            
            if (newPassword !== confirmPassword) {
                alert('两次输入的新密码不一致');
                e.preventDefault();
                return;
            }
        });
    </script>
</body>
</html>