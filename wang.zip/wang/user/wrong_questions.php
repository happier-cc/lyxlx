<?php
require_once '../config/database.php';

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

$project_id = $_GET['project_id'] ?? 'all';
$course_id = $_GET['course_id'] ?? 'all';

// 获取错题（根据筛选条件）
$where_conditions = ["wq.user_id = ?"];
$params = [$_SESSION['user_id']];

if ($course_id != 'all') {
    $where_conditions[] = "c.id = ?";
    $params[] = $course_id;
}

if ($project_id != 'all') {
    $where_conditions[] = "wq.project_id = ?";
    $params[] = $project_id;
}

$where_sql = implode(" AND ", $where_conditions);

// 获取错题
if ($project_id == 'all' && $course_id == 'all') {
    $wrong_stmt = $pdo->prepare("
        SELECT wq.*, q.question_text, q.option_a, q.option_b, q.option_c, q.option_d, 
               q.correct_answer, q.explanation, p.project_name, p.id as project_id,
               m.module_name, c.course_name, c.id as course_id
        FROM wrong_questions wq 
        JOIN questions q ON wq.question_id = q.id 
        JOIN projects p ON wq.project_id = p.id
        JOIN modules m ON p.module_id = m.id
        JOIN courses c ON m.course_id = c.id
        WHERE $where_sql
        ORDER BY wq.created_at DESC
    ");
} else {
    $wrong_stmt = $pdo->prepare("
        SELECT wq.*, q.question_text, q.option_a, q.option_b, q.option_c, q.option_d, 
               q.correct_answer, q.explanation, p.project_name, p.id as project_id,
               m.module_name, c.course_name, c.id as course_id
        FROM wrong_questions wq 
        JOIN questions q ON wq.question_id = q.id 
        JOIN projects p ON wq.project_id = p.id
        JOIN modules m ON p.module_id = m.id
        JOIN courses c ON m.course_id = c.id
        WHERE $where_sql
        ORDER BY wq.created_at DESC
    ");
}

$wrong_stmt->execute($params);
$wrong_questions = $wrong_stmt->fetchAll();

// 获取所有包含错题的课程用于筛选
$courses_stmt = $pdo->prepare("
    SELECT DISTINCT c.id, c.course_name, COUNT(wq.id) as question_count
    FROM wrong_questions wq 
    JOIN questions q ON wq.question_id = q.id 
    JOIN projects p ON wq.project_id = p.id
    JOIN modules m ON p.module_id = m.id
    JOIN courses c ON m.course_id = c.id
    WHERE wq.user_id = ?
    GROUP BY c.id, c.course_name
    ORDER BY c.course_name
");
$courses_stmt->execute([$_SESSION['user_id']]);
$available_courses = $courses_stmt->fetchAll();

// 获取所有包含错题的项目用于筛选
$projects_stmt = $pdo->prepare("
    SELECT DISTINCT p.id, p.project_name, m.module_name, c.course_name, c.id as course_id, COUNT(wq.id) as question_count
    FROM wrong_questions wq 
    JOIN questions q ON wq.question_id = q.id 
    JOIN projects p ON wq.project_id = p.id
    JOIN modules m ON p.module_id = m.id
    JOIN courses c ON m.course_id = c.id
    WHERE wq.user_id = ?
    GROUP BY p.id, p.project_name, m.module_name, c.course_name, c.id
    ORDER BY c.course_name, m.module_name, p.project_name
");
$projects_stmt->execute([$_SESSION['user_id']]);
$available_projects = $projects_stmt->fetchAll();

// 按课程分组错题
$wrong_questions_by_course = [];
$total_count = 0;
foreach ($wrong_questions as $question) {
    $current_course_id = $question['course_id'] ?? 'unknown';
    if (!isset($wrong_questions_by_course[$current_course_id])) {
        $wrong_questions_by_course[$current_course_id] = [
            'course_name' => $question['course_name'],
            'questions' => []
        ];
    }
    $wrong_questions_by_course[$current_course_id]['questions'][] = $question;
    $total_count++;
}

// 准备当前选中的项目数据用于JavaScript
$current_course_projects = [];
if ($course_id != 'all') {
    foreach ($available_projects as $project) {
        if ($project['course_id'] == $course_id) {
            $current_course_projects[] = $project;
        }
    }
}
?>

<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
    <title>我的错题本 - 多课程在线刷题系统</title>
    <link rel="stylesheet" href="../config/style.css">
    <style>
        .filters-section {
            background: var(--bg-primary);
            padding: 20px;
            border-radius: 12px;
            margin-bottom: 24px;
        }
        
        .filter-group {
            display: flex;
            gap: 16px;
            align-items: center;
            margin-bottom: 16px;
        }
        
        .filter-label {
            font-weight: 600;
            color: var(--text-primary);
            min-width: 80px;
        }
        
        .filter-select {
            flex: 1;
            padding: 10px 16px;
            border: 2px solid var(--border-color);
            border-radius: 8px;
            background: white;
            font-size: 14px;
            color: var(--text-primary);
            cursor: pointer;
        }
        
        .filter-stats {
            display: flex;
            gap: 16px;
            font-size: 14px;
            color: var(--text-secondary);
            margin-top: 16px;
            padding-top: 16px;
            border-top: 1px solid var(--border-color);
        }
        
        .stat-item {
            display: flex;
            align-items: center;
            gap: 6px;
        }
        
        .stat-value {
            font-weight: 600;
            color: #dc2626;
        }
        
        .wrong-course {
            margin-bottom: 32px;
        }
        
        .course-header {
            background: linear-gradient(135deg, #dc2626, #ef4444);
            color: white;
            padding: 20px;
            border-radius: 12px;
            margin-bottom: 16px;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        
        .course-title {
            font-size: 18px;
            font-weight: 600;
        }
        
        .wrong-count {
            background: rgba(255, 255, 255, 0.2);
            padding: 4px 12px;
            border-radius: 20px;
            font-size: 14px;
        }
        
        .wrong-item {
            background: #fef2f2;
            border: 1px solid #fecaca;
            border-radius: 12px;
            padding: 20px;
            margin-bottom: 16px;
        }
        
        .question-header {
            display: flex;
            justify-content: space-between;
            align-items: flex-start;
            margin-bottom: 12px;
        }
        
        .question-text {
            font-weight: 600;
            color: var(--text-primary);
            flex: 1;
        }
        
        .question-meta {
            font-size: 12px;
            color: var(--text-secondary);
            text-align: right;
        }
        
        .project-path {
            background: #e3f2fd;
            padding: 4px 8px;
            border-radius: 6px;
            font-size: 12px;
            margin-bottom: 8px;
        }
        
        .options-review {
            margin: 16px 0;
            padding: 16px;
            background: #f8f9fa;
            border-radius: 8px;
        }
        
        .option-review-item {
            padding: 10px 14px;
            margin: 6px 0;
            border-radius: 6px;
            border: 1px solid #e9ecef;
            background: white;
            transition: all 0.2s ease;
        }
        
        .user-wrong-option {
            background: #fee2e2;
            border-color: #fecaca;
            color: #dc2626;
            border-left: 4px solid #dc2626;
        }
        
        .correct-option {
            background: #d1fae5;
            border-color: #a7f3d0;
            color: #065f46;
            border-left: 4px solid #059669;
        }
        
        .option-label {
            font-weight: 600;
            margin-right: 8px;
            display: inline-block;
            width: 24px;
        }
        
        .option-badge {
            font-size: 12px;
            padding: 2px 8px;
            border-radius: 12px;
            margin-left: 8px;
            font-weight: 600;
        }
        
        .badge-wrong {
            background: #dc2626;
            color: white;
        }
        
        .badge-correct {
            background: #059669;
            color: white;
        }
        
        .explanation {
            background: #fef3c7;
            border: 1px solid #fde68a;
            padding: 12px;
            border-radius: 8px;
            margin-top: 12px;
        }
        
        .empty-state {
            text-align: center;
            padding: 60px 20px;
            color: var(--text-secondary);
        }
        
        .empty-icon {
            font-size: 64px;
            margin-bottom: 20px;
        }
        
        .action-buttons {
            display: flex;
            gap: 10px;
            margin-top: 15px;
            flex-wrap: wrap;
        }
        
        .review-all-btn {
            background: linear-gradient(135deg, #dc2626, #ef4444);
            color: white;
            border: none;
        }
        
        .review-all-btn:hover {
            background: linear-gradient(135deg, #b91c1c, #dc2626);
        }
        
        .course-actions {
            display: flex;
            gap: 10px;
            margin-top: 16px;
            flex-wrap: wrap;
        }
        
        .btn-course-review {
            background: #dc2626;
            color: white;
        }
        
        .btn-course-review:hover {
            background: #b91c1c;
        }
        
        .filter-actions {
            display: flex;
            gap: 12px;
            margin-top: 16px;
            flex-wrap: wrap;
        }
        
        @media (max-width: 640px) {
            .filter-group {
                flex-direction: column;
                align-items: stretch;
                gap: 8px;
            }
            
            .filter-label {
                min-width: auto;
            }
            
            .filter-stats {
                flex-direction: column;
                gap: 8px;
            }
            
            .course-header {
                flex-direction: column;
                gap: 12px;
                text-align: center;
            }
            
            .question-header {
                flex-direction: column;
                gap: 8px;
            }
            
            .question-text {
                padding-right: 0;
                padding-top: 40px;
            }
            
            .question-meta {
                text-align: left;
            }
            
            .course-actions, .filter-actions {
                justify-content: center;
            }
            
            .options-review {
                padding: 12px;
            }
        }
    </style>
    <script>
        // 存储所有项目的原始数据
        const allProjects = <?php echo json_encode($available_projects); ?>;
        
        function updateProjectFilter() {
            const courseSelect = document.getElementById('courseFilter');
            const projectSelect = document.getElementById('projectFilter');
            const selectedCourseId = courseSelect.value;
            
            // 保存当前选中的项目ID
            const currentSelectedProjectId = '<?php echo $project_id; ?>';
            
            // 清空项目选择器
            projectSelect.innerHTML = '<option value="all">所有项目</option>';
            
            // 筛选项目
            let filteredProjects = allProjects;
            if (selectedCourseId !== 'all') {
                filteredProjects = allProjects.filter(project => project.course_id == selectedCourseId);
            }
            
            // 添加项目选项
            filteredProjects.forEach(project => {
                const option = document.createElement('option');
                option.value = project.id;
                option.textContent = `${project.module_name} > ${project.project_name} (${project.question_count}题)`;
                
                // 如果这是之前选中的项目，保持选中状态
                if (project.id == currentSelectedProjectId) {
                    option.selected = true;
                }
                
                projectSelect.appendChild(option);
            });
        }
        
        function applyFilters() {
            const courseId = document.getElementById('courseFilter').value;
            const projectId = document.getElementById('projectFilter').value;
            
            let url = 'wrong_questions.php?';
            
            if (courseId !== 'all') {
                url += 'course_id=' + encodeURIComponent(courseId) + '&';
            }
            
            if (projectId !== 'all') {
                url += 'project_id=' + encodeURIComponent(projectId) + '&';
            }
            
            // 移除末尾的&
            url = url.replace(/[&]+$/, '');
            
            // 如果url以?结尾，移除?
            if (url.endsWith('?')) {
                url = url.slice(0, -1);
            }
            
            window.location.href = url;
        }
        
        // 页面加载时初始化
        document.addEventListener('DOMContentLoaded', function() {
            updateProjectFilter();
        });
    </script>
</head>
<body>
    <nav class="navbar">
        <div class="container">
            <div class="nav-content">
                <a href="index.php" class="nav-brand">← 返回学习中心</a>
                <span class="nav-brand">我的错题本</span>
            </div>
        </div>
    </nav>

    <div class="container">
        <?php if (empty($wrong_questions)): ?>
            <div class="empty-state">
                <div class="empty-icon">🎉</div>
                <h2>暂无错题！</h2>
                <p>太棒了！你还没有做错的题目</p>
                <a href="index.php" class="btn btn-primary mt-3">开始刷题</a>
            </div>
        <?php else: ?>
            <div class="filters-section">
                <h2>我的错题本</h2>
                <p>筛选和查看您的错题</p>
                
                <div class="filter-group">
                    <div class="filter-label">按课程筛选：</div>
                    <select id="courseFilter" class="filter-select" onchange="updateProjectFilter()">
                        <option value="all" <?php echo $course_id == 'all' ? 'selected' : ''; ?>>所有课程</option>
                        <?php foreach ($available_courses as $course): ?>
                            <option value="<?php echo $course['id']; ?>" <?php echo $course_id == $course['id'] ? 'selected' : ''; ?>>
                                <?php echo htmlspecialchars($course['course_name'] . " (" . $course['question_count'] . "题)"); ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>
                
                <div class="filter-group">
                    <div class="filter-label">按项目筛选：</div>
                    <select id="projectFilter" class="filter-select">
                        <option value="all">所有项目</option>
                        <!-- 项目选项通过JavaScript动态生成 -->
                    </select>
                </div>
                
                <div class="filter-actions">
                    <button onclick="applyFilters()" class="btn btn-primary">应用筛选</button>
                    <a href="wrong_questions.php" class="btn btn-outline">重置筛选</a>
                    <a href="review_wrong.php?course_id=<?php echo $course_id; ?>&project_id=<?php echo $project_id; ?>" class="btn review-all-btn">
                        重做错题 (当前<?php echo $total_count; ?>题)
                    </a>
                </div>
                
                <div class="filter-stats">
                    <div class="stat-item">
                        <span>当前显示：</span>
                        <span class="stat-value"><?php echo $total_count; ?>题</span>
                    </div>
                    <div class="stat-item">
                        <span>错题总数：</span>
                        <span class="stat-value">
                            <?php 
                                $total_wrong_stmt = $pdo->prepare("SELECT COUNT(*) as total FROM wrong_questions WHERE user_id = ?");
                                $total_wrong_stmt->execute([$_SESSION['user_id']]);
                                $total_wrong = $total_wrong_stmt->fetch();
                                echo $total_wrong['total'];
                            ?>题
                        </span>
                    </div>
                    <?php if ($course_id != 'all' || $project_id != 'all'): ?>
                    <div class="stat-item">
                        <span>筛选状态：</span>
                        <span class="stat-value" style="color: #dc2626;">
                            <?php 
                                if ($course_id != 'all' && $project_id != 'all') {
                                    echo "课程 + 项目筛选";
                                } elseif ($course_id != 'all') {
                                    echo "课程筛选";
                                } elseif ($project_id != 'all') {
                                    echo "项目筛选";
                                }
                            ?>
                        </span>
                    </div>
                    <?php endif; ?>
                </div>
            </div>
            
            <?php foreach ($wrong_questions_by_course as $current_course_id => $course_data): ?>
                <div class="wrong-course">
                    <div class="course-header">
                        <div class="course-title"><?php echo htmlspecialchars($course_data['course_name']); ?></div>
                        <div class="wrong-count"><?php echo count($course_data['questions']); ?> 题</div>
                    </div>
                    
                    <div class="course-actions">
                        <a href="review_wrong.php?course_id=<?php echo $current_course_id; ?>&project_id=all" class="btn btn-course-review">
                            重做错题 (本课程<?php echo count($course_data['questions']); ?>题)
                        </a>
                        <a href="quiz.php?course_id=<?php echo $current_course_id; ?>" class="btn btn-outline">
                            前往课程刷题
                        </a>
                    </div>
                    
                    <?php foreach ($course_data['questions'] as $index => $question): ?>
                        <div class="wrong-item">
                            <div class="project-path">
                                <?php echo htmlspecialchars($question['module_name']); ?> &gt; 
                                <?php echo htmlspecialchars($question['project_name']); ?>
                            </div>
                            
                            <div class="question-header">
                                <div class="question-text">
                                    <?php echo ($index + 1) . '. ' . htmlspecialchars($question['question_text']); ?>
                                </div>
                                <div class="question-meta">
                                    错题时间: <?php echo date('Y-m-d H:i', strtotime($question['created_at'])); ?>
                                </div>
                            </div>
                            
                            <!-- 显示选项 -->
                            <div class="options-review">
                                <?php foreach (['A', 'B', 'C', 'D'] as $option): ?>
                                    <?php if (!empty($question['option_' . strtolower($option)])): 
                                        $option_class = '';
                                        $badge = '';
                                        
                                        // 判断选项类型
                                        if ($option == $question['wrong_answer']) {
                                            $option_class = 'user-wrong-option';
                                            $badge = '<span class="option-badge badge-wrong">你的选择</span>';
                                        }
                                        if ($option == $question['correct_answer']) {
                                            $option_class = 'correct-option';
                                            $badge = '<span class="option-badge badge-correct">正确答案</span>';
                                        }
                                    ?>
                                        <div class="option-review-item <?php echo $option_class; ?>">
                                            <span class="option-label"><?php echo $option; ?>.</span>
                                            <?php echo htmlspecialchars($question['option_' . strtolower($option)]); ?>
                                            <?php echo $badge; ?>
                                        </div>
                                    <?php endif; ?>
                                <?php endforeach; ?>
                            </div>
                            
                            <?php if ($question['explanation']): ?>
                                <div class="explanation">
                                    <strong>解析：</strong>
                                    <?php echo htmlspecialchars($question['explanation']); ?>
                                </div>
                            <?php endif; ?>
                            
                            <div class="action-buttons">
                                <a href="review_wrong.php?course_id=<?php echo $question['course_id']; ?>&project_id=<?php echo $question['project_id']; ?>" class="btn btn-primary btn-sm">
                                    重做本项目错题
                                </a>
                                <a href="quiz.php?project_id=<?php echo $question['project_id']; ?>" class="btn btn-outline btn-sm">
                                    前往项目刷题
                                </a>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>
            <?php endforeach; ?>
            
            <div class="text-center mt-4">
                <a href="review_wrong.php?course_id=<?php echo $course_id; ?>&project_id=<?php echo $project_id; ?>" class="btn review-all-btn">
                    重做错题 (当前<?php echo $total_count; ?>题)
                </a>
                <a href="index.php" class="btn btn-outline">返回学习中心</a>
            </div>
        <?php endif; ?>
    </div>
</body>
</html>