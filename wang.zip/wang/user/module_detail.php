<?php
require_once '../config/database.php';

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

$module_id = $_GET['module_id'] ?? 0;

// 获取模块信息
$module_stmt = $pdo->prepare("
    SELECT m.*, c.course_name, c.id as course_id 
    FROM modules m 
    JOIN courses c ON m.course_id = c.id 
    WHERE m.id = ?
");
$module_stmt->execute([$module_id]);
$module = $module_stmt->fetch();

if (!$module) {
    header("Location: index.php");
    exit();
}

// 获取模块下的项目
$projects_stmt = $pdo->prepare("SELECT * FROM projects WHERE module_id = ? ORDER BY sort_order, id");
$projects_stmt->execute([$module_id]);
$projects = $projects_stmt->fetchAll();

// 获取用户在该模块的学习统计
$module_stats_stmt = $pdo->prepare("
    SELECT 
        COUNT(DISTINCT p.id) as total_projects,
        COUNT(DISTINCT up.project_id) as completed_projects,
        AVG(up.score) as avg_score
    FROM projects p
    LEFT JOIN user_progress up ON p.id = up.project_id AND up.user_id = ? AND up.completed = TRUE
    WHERE p.module_id = ?
");
$module_stats_stmt->execute([$_SESSION['user_id'], $module_id]);
$module_stats = $module_stats_stmt->fetch();
?>

<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
    <title><?php echo htmlspecialchars($module['module_name']); ?> - 项目列表</title>
    <link rel="stylesheet" href="../config/style.css">
    <style>
        .module-header {
            background: linear-gradient(135deg, #e67e22, #e74c3c);
            color: white;
            padding: 30px;
            border-radius: 12px;
            margin-bottom: 24px;
        }
        
        .breadcrumb {
            font-size: 14px;
            opacity: 0.8;
            margin-bottom: 8px;
        }
        
        .breadcrumb a {
            color: white;
            text-decoration: none;
        }
        
        .breadcrumb a:hover {
            text-decoration: underline;
        }
        
        .module-title {
            font-size: 28px;
            font-weight: 700;
            margin-bottom: 8px;
        }
        
        .module-description {
            font-size: 16px;
            opacity: 0.9;
            margin-bottom: 20px;
        }
        
        .module-stats {
            display: grid;
            grid-template-columns: repeat(3, 1fr);
            gap: 16px;
            margin-top: 24px;
        }
        
        .module-stat {
            background: rgba(255, 255, 255, 0.2);
            padding: 16px;
            border-radius: 12px;
            text-align: center;
            backdrop-filter: blur(10px);
        }
        
        .stat-number {
            font-size: 24px;
            font-weight: 700;
            margin-bottom: 4px;
        }
        
        .stat-label {
            font-size: 14px;
            opacity: 0.9;
        }
        
        /* 项目列表样式 */
        .project-list {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
            gap: 16px;
        }
        
        .project-item {
            background: var(--bg-primary);
            border-radius: 12px;
            padding: 20px;
            box-shadow: var(--shadow);
            border-left: 4px solid #3498db;
            transition: transform 0.2s ease;
        }
        
        .project-item:hover {
            transform: translateY(-2px);
            box-shadow: 0 8px 16px rgba(0,0,0,0.1);
        }
        
        .project-header {
            display: flex;
            justify-content: space-between;
            align-items: flex-start;
            margin-bottom: 12px;
        }
        
        .project-title {
            font-size: 18px;
            font-weight: 600;
            color: var(--text-primary);
            flex: 1;
        }
        
        .project-status {
            font-size: 14px;
            padding: 4px 12px;
            border-radius: 20px;
            background: var(--success-color);
            color: white;
        }
        
        .project-status.pending {
            background: var(--warning-color);
        }
        
        .project-desc {
            color: var(--text-secondary);
            font-size: 14px;
            margin-bottom: 16px;
        }
        
        .project-info {
            display: flex;
            justify-content: space-between;
            margin: 15px 0;
            padding: 15px 0;
            border-top: 1px solid var(--border-color);
            border-bottom: 1px solid var(--border-color);
        }
        
        .project-stat {
            text-align: center;
            flex: 1;
        }
        
        .project-stat-number {
            font-size: 16px;
            font-weight: 700;
            color: var(--primary-color);
        }
        
        .project-stat-label {
            font-size: 12px;
            color: var(--text-secondary);
        }
        
        .project-actions {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-top: 15px;
        }
        
        .project-score {
            font-size: 14px;
            color: var(--text-secondary);
        }
        
        /* 移动端适配 */
        @media (max-width: 768px) {
            .module-stats {
                grid-template-columns: 1fr;
            }
            
            .project-list {
                grid-template-columns: 1fr;
            }
            
            .project-info {
                flex-direction: column;
                gap: 10px;
            }
            
            .project-actions {
                flex-direction: column;
                gap: 10px;
                align-items: stretch;
            }
        }
    </style>
</head>
<body>
    <nav class="navbar">
        <div class="container">
            <div class="nav-content">
                <a href="course_detail.php?course_id=<?php echo $module['course_id']; ?>" class="nav-brand">← 返回课程</a>
                <span class="nav-brand"><?php echo htmlspecialchars($module['module_name']); ?></span>
            </div>
        </div>
    </nav>

    <div class="container">
        <!-- 模块头部信息 -->
        <div class="module-header">
            <div class="breadcrumb">
                <a href="index.php">学习中心</a> &gt; 
                <a href="course_detail.php?course_id=<?php echo $module['course_id']; ?>"><?php echo htmlspecialchars($module['course_name']); ?></a> &gt; 
                <?php echo htmlspecialchars($module['module_name']); ?>
            </div>
            <h1 class="module-title"><?php echo htmlspecialchars($module['module_name']); ?></h1>
            <p class="module-description"><?php echo htmlspecialchars($module['description']); ?></p>
            
            <div class="module-stats">
                <div class="module-stat">
                    <div class="stat-number"><?php echo count($projects); ?></div>
                    <div class="stat-label">学习项目</div>
                </div>
                <div class="module-stat">
                    <div class="stat-number"><?php echo $module_stats['completed_projects'] ?? 0; ?></div>
                    <div class="stat-label">已完成</div>
                </div>
                <div class="module-stat">
                    <div class="stat-number"><?php echo $module_stats['avg_score'] ? round($module_stats['avg_score'], 1) : '0'; ?></div>
                    <div class="stat-label">平均分数</div>
                </div>
            </div>
        </div>

        <!-- 项目列表 -->
        <h2 class="mb-3">学习项目</h2>
        <div class="project-list">
            <?php foreach ($projects as $project): 
                // 获取项目的题目数量
                $questions_stmt = $pdo->prepare("SELECT COUNT(*) as question_count FROM questions WHERE project_id = ?");
                $questions_stmt->execute([$project['id']]);
                $question_count = $questions_stmt->fetchColumn();
                
                // 获取用户在该项目的学习进度
                $progress_stmt = $pdo->prepare("SELECT * FROM user_progress WHERE user_id = ? AND project_id = ?");
                $progress_stmt->execute([$_SESSION['user_id'], $project['id']]);
                $progress = $progress_stmt->fetch();
                
                // 获取项目的收藏数量
                $favorite_stmt = $pdo->prepare("SELECT COUNT(*) as favorite_count FROM favorite_questions WHERE user_id = ? AND project_id = ?");
                $favorite_stmt->execute([$_SESSION['user_id'], $project['id']]);
                $favorite_count = $favorite_stmt->fetchColumn();
            ?>
                <div class="project-item">
                    <div class="project-header">
                        <div class="project-title"><?php echo htmlspecialchars($project['project_name']); ?></div>
                        <div class="project-status <?php echo $progress && $progress['completed'] ? '' : 'pending'; ?>">
                            <?php echo $progress && $progress['completed'] ? '已完成' : '待学习'; ?>
                        </div>
                    </div>
                    <div class="project-desc">
                        <?php echo htmlspecialchars($project['description']); ?>
                    </div>
                    
                    <div class="project-info">
                        <div class="project-stat">
                            <div class="project-stat-number"><?php echo $question_count; ?></div>
                            <div class="project-stat-label">题目数量</div>
                        </div>
                        <div class="project-stat">
                            <div class="project-stat-number"><?php echo $favorite_count; ?></div>
                            <div class="project-stat-label">收藏题目</div>
                        </div>
                    </div>
                    
                    <div class="project-actions">
                        <div class="project-score">
                            <?php if ($progress && $progress['completed']): ?>
                                最高得分: <?php echo $progress['score']; ?>分
                            <?php else: ?>
                                尚未开始
                            <?php endif; ?>
                        </div>
                        <a href="quiz.php?project_id=<?php echo $project['id']; ?>" class="btn btn-primary btn-sm">
                            <?php echo $progress && $progress['completed'] ? '重新学习' : '开始学习'; ?>
                        </a>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
        
        <?php if (empty($projects)): ?>
            <div class="card text-center" style="padding: 40px 20px;">
                <div style="font-size: 48px; margin-bottom: 16px;">📝</div>
                <h3>暂无学习项目</h3>
                <p>该模块还没有添加学习项目</p>
            </div>
        <?php endif; ?>
    </div>

    <script>
        // 页面加载动画
        document.addEventListener('DOMContentLoaded', function() {
            const projectItems = document.querySelectorAll('.project-item');
            projectItems.forEach((item, index) => {
                item.style.opacity = '0';
                item.style.transform = 'translateY(20px)';
                setTimeout(() => {
                    item.style.transition = 'all 0.5s ease';
                    item.style.opacity = '1';
                    item.style.transform = 'translateY(0)';
                }, index * 100);
            });
        });
    </script>
</body>
</html>