<?php
require_once '../config/database.php';

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

$project_id = $_GET['project_id'] ?? 0;

// 记录答题开始时间
if (!isset($_SESSION['quiz_start_time'])) {
    $_SESSION['quiz_start_time'] = time();
    $_SESSION['quiz_project_id'] = $project_id;
}

// 获取项目信息
$project_stmt = $pdo->prepare("
    SELECT p.*, m.module_name, c.course_name 
    FROM projects p 
    JOIN modules m ON p.module_id = m.id 
    JOIN courses c ON m.course_id = c.id 
    WHERE p.id = ?
");
$project_stmt->execute([$project_id]);
$project = $project_stmt->fetch();

if (!$project) {
    header("Location: index.php");
    exit();
}

// 获取题目 - 修改为随机排序
$questions_stmt = $pdo->prepare("SELECT * FROM questions WHERE project_id = ? ORDER BY RAND()");
$questions_stmt->execute([$project_id]);
$questions = $questions_stmt->fetchAll();

if (empty($questions)) {
    die("<div class='container'><div class='card text-center'><h2>该项目暂无题目！</h2><a href='index.php' class='btn btn-primary'>返回首页</a></div></div>");
}

// 检查收藏状态
$favorite_status = [];
foreach ($questions as $question) {
    $fav_stmt = $pdo->prepare("SELECT id FROM favorite_questions WHERE user_id = ? AND question_id = ?");
    $fav_stmt->execute([$_SESSION['user_id'], $question['id']]);
    $favorite_status[$question['id']] = $fav_stmt->fetch() ? true : false;
}

// 处理收藏/取消收藏
if (isset($_POST['toggle_favorite'])) {
    $question_id = $_POST['question_id'];
    $is_favorite = $_POST['is_favorite'];
    
    if ($is_favorite == 'false') {
        // 添加收藏
        $stmt = $pdo->prepare("INSERT INTO favorite_questions (user_id, question_id, project_id) VALUES (?, ?, ?)");
        $stmt->execute([$_SESSION['user_id'], $question_id, $project_id]);
        $favorite_status[$question_id] = true;
    } else {
        // 取消收藏
        $stmt = $pdo->prepare("DELETE FROM favorite_questions WHERE user_id = ? AND question_id = ?");
        $stmt->execute([$_SESSION['user_id'], $question_id]);
        $favorite_status[$question_id] = false;
    }
    
    // 返回JSON响应
    header('Content-Type: application/json');
    echo json_encode(['success' => true, 'is_favorite' => $favorite_status[$question_id]]);
    exit();
}

if ($_SERVER['REQUEST_METHOD'] == 'POST' && !isset($_POST['toggle_favorite'])) {
    // 计算实际学习时长
    $start_time = $_SESSION['quiz_start_time'];
    $end_time = time();
    $study_duration = round(($end_time - $start_time) / 60); // 转换为分钟
    
    // 原有的答题逻辑保持不变
    $score = 0;
    $total_questions = count($questions);
    $wrong_answers = [];
    
    foreach ($questions as $question) {
        $user_answer = $_POST['answer_' . $question['id']] ?? '';
        $is_correct = ($user_answer == $question['correct_answer']);
        
        if ($is_correct) {
            $score++;
        } else {
            // 记录错题
            $wrong_answers[] = [
                'question' => $question,
                'user_answer' => $user_answer
            ];
            
            // 检查是否已经记录过这道错题
            $check_wrong_stmt = $pdo->prepare("SELECT id FROM wrong_questions WHERE user_id = ? AND question_id = ? AND project_id = ?");
            $check_wrong_stmt->execute([$_SESSION['user_id'], $question['id'], $project_id]);
            $existing_wrong = $check_wrong_stmt->fetch();
            
            if (!$existing_wrong) {
                $wrong_stmt = $pdo->prepare("INSERT INTO wrong_questions (user_id, question_id, project_id, wrong_answer, created_at) VALUES (?, ?, ?, ?, NOW())");
                $wrong_stmt->execute([$_SESSION['user_id'], $question['id'], $project_id, $user_answer]);
            } else {
                $update_wrong_stmt = $pdo->prepare("UPDATE wrong_questions SET wrong_answer = ?, created_at = NOW() WHERE id = ?");
                $update_wrong_stmt->execute([$user_answer, $existing_wrong['id']]);
            }
        }
        
        // 记录用户答案
        $user_answer_stmt = $pdo->prepare("
            INSERT INTO user_answers (user_id, question_id, selected_answer, is_correct, project_id, created_at) 
            VALUES (?, ?, ?, ?, ?, NOW())
        ");
        $user_answer_stmt->execute([
            $_SESSION['user_id'], 
            $question['id'], 
            $user_answer, 
            $is_correct ? 1 : 0,
            $project_id
        ]);
    }
    
    $final_score = round(($score / $total_questions) * 100);
    
    // 更新用户进度
    $progress_stmt = $pdo->prepare("
        INSERT INTO user_progress (user_id, project_id, completed, score, completed_at, started_at, study_duration, attempt_count) 
        VALUES (?, ?, TRUE, ?, NOW(), FROM_UNIXTIME(?), ?, 1) 
        ON DUPLICATE KEY UPDATE 
        completed = TRUE, 
        score = GREATEST(score, ?), 
        completed_at = NOW(),
        started_at = FROM_UNIXTIME(?),
        study_duration = study_duration + ?,
        attempt_count = attempt_count + 1
    ");
    $progress_stmt->execute([
        $_SESSION['user_id'], 
        $project_id, 
        $final_score, 
        $start_time, 
        $study_duration,
        $final_score,
        $start_time,
        $study_duration
    ]);

// ============ 新增：记录学习历史 ============
try {
    $history_stmt = $pdo->prepare("
        INSERT INTO user_study_history 
        (user_id, project_id, score, completed_at, study_duration, total_questions, correct_answers) 
        VALUES (?, ?, ?, NOW(), ?, ?, ?)
    ");
    $history_stmt->execute([
        $_SESSION['user_id'],
        $project_id,
        $final_score,
        $study_duration,
        $total_questions,
        $score
    ]);
} catch (PDOException $e) {
    // 如果插入历史记录失败，记录错误但不影响主要流程
    error_log("记录学习历史失败: " . $e->getMessage());
}
// ============ 新增结束 ============

    
    // 清除答题开始时间
    unset($_SESSION['quiz_start_time']);
    unset($_SESSION['quiz_project_id']);
    
    // 显示结果页面
    ?>
    <!DOCTYPE html>
    <html lang="zh-CN">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
        <title>答题结果 - 多课程在线刷题系统</title>
        <link rel="stylesheet" href="../config/style.css">
        <style>
            .result-card { text-align: center; padding: 40px 20px; }
            .score-circle { width: 120px; height: 120px; border-radius: 50%; background: linear-gradient(135deg, var(--primary-color), var(--secondary-color)); color: white; display: flex; align-items: center; justify-content: center; font-size: 32px; font-weight: 700; margin: 0 auto 24px; }
            .result-stats { display: grid; grid-template-columns: repeat(3, 1fr); gap: 16px; margin: 24px 0; }
            .stat-item { background: var(--bg-tertiary); padding: 16px; border-radius: 12px; text-align: center; }
            .stat-value { font-size: 24px; font-weight: 700; color: var(--primary-color); }
            .wrong-questions { margin-top: 32px; text-align: left; }
            .wrong-item { background: #fef2f2; border: 1px solid #fecaca; border-radius: 8px; padding: 16px; margin-bottom: 12px; }
            .action-buttons { display: grid; gap: 12px; margin-top: 32px; }
            .options-review { margin: 12px 0; padding: 12px; background: #f8f9fa; border-radius: 6px; }
            .option-review-item { padding: 8px 12px; margin: 4px 0; border-radius: 4px; border: 1px solid #e9ecef; background: white; }
            .user-wrong-option { background: #fee2e2; border-color: #fecaca; color: #dc2626; }
            .correct-option { background: #d1fae5; border-color: #a7f3d0; color: #065f46; }
            .option-label { font-weight: 600; margin-right: 8px; }
            .breadcrumb {
                font-size: 14px;
                color: var(--text-secondary);
                margin-bottom: 16px;
            }
            .breadcrumb a {
                color: var(--primary-color);
                text-decoration: none;
            }
        </style>
    </head>
    <body>
        <nav class="navbar">
            <div class="container">
                <div class="nav-content">
                    <a href="module_detail.php?module_id=<?php 
                        $module_stmt = $pdo->prepare("SELECT module_id FROM projects WHERE id = ?");
                        $module_stmt->execute([$project_id]);
                        $module_id = $module_stmt->fetchColumn();
                        echo $module_id;
                    ?>" class="nav-brand">← 返回</a>
                    <span class="nav-brand">答题结果</span>
                </div>
            </div>
        </nav>

        <div class="container">
            <div class="breadcrumb">
                <a href="index.php">学习中心</a> &gt; 
                <a href="course_detail.php?course_id=<?php 
                    $course_stmt = $pdo->prepare("SELECT c.id FROM courses c JOIN modules m ON c.id = m.course_id JOIN projects p ON m.id = p.module_id WHERE p.id = ?");
                    $course_stmt->execute([$project_id]);
                    $course_id = $course_stmt->fetchColumn();
                    echo $course_id;
                ?>"><?php echo htmlspecialchars($project['course_name']); ?></a> &gt; 
                <a href="module_detail.php?module_id=<?php echo $module_id; ?>"><?php echo htmlspecialchars($project['module_name']); ?></a> &gt; 
                <?php echo htmlspecialchars($project['project_name']); ?>
            </div>

            <div class="card result-card">
                <div class="score-circle"><?php echo $final_score; ?>分</div>
                <h2>答题完成！</h2>
                <p>你已完成 <?php echo htmlspecialchars($project['project_name']); ?> 的测试</p>
                
                <div class="result-stats">
                    <div class="stat-item">
                        <div class="stat-value"><?php echo $score; ?></div>
                        <div>答对题数</div>
                    </div>
                    <div class="stat-item">
                        <div class="stat-value"><?php echo $total_questions; ?></div>
                        <div>总题数</div>
                    </div>
                    <div class="stat-item">
                        <div class="stat-value"><?php echo $study_duration; ?></div>
                        <div>学习时长(分钟)</div>
                    </div>
                </div>
                
                <?php if (!empty($wrong_answers)): ?>
                    <div class="wrong-questions">
                        <h3>错题分析 (<?php echo count($wrong_answers); ?>题)</h3>
                        <?php foreach ($wrong_answers as $wrong): 
                            $question = $wrong['question'];
                            $user_answer = $wrong['user_answer'];
                            $correct_answer = $question['correct_answer'];
                        ?>
                            <div class="wrong-item">
                                <p><strong>题目：</strong><?php echo htmlspecialchars($question['question_text']); ?></p>
                                
                                <div class="options-review">
                                    <?php foreach (['A', 'B', 'C', 'D'] as $option): ?>
                                        <?php if (!empty($question['option_' . strtolower($option)])): 
                                            $option_class = '';
                                            if ($option == $user_answer) {
                                                $option_class = 'user-wrong-option';
                                            }
                                            if ($option == $correct_answer) {
                                                $option_class = 'correct-option';
                                            }
                                        ?>
                                            <div class="option-review-item <?php echo $option_class; ?>">
                                                <span class="option-label"><?php echo $option; ?>.</span>
                                                <?php echo htmlspecialchars($question['option_' . strtolower($option)]); ?>
                                                <?php if ($option == $user_answer && $option != $correct_answer): ?>
                                                    <span style="background: #dc2626; color: white; margin-left: 8px; padding: 2px 8px; border-radius: 12px; font-size: 12px;">你的选择</span>
                                                <?php endif; ?>
                                                <?php if ($option == $correct_answer): ?>
                                                    <span style="background: #059669; color: white; margin-left: 8px; padding: 2px 8px; border-radius: 12px; font-size: 12px;">正确答案</span>
                                                <?php endif; ?>
                                            </div>
                                        <?php endif; ?>
                                    <?php endforeach; ?>
                                </div>

                                <?php if (!empty($question['explanation'])): ?>
                                    <p><strong>解析：</strong><?php echo htmlspecialchars($question['explanation']); ?></p>
                                <?php endif; ?>
                            </div>
                        <?php endforeach; ?>
                    </div>
                <?php endif; ?>
                
                <div class="action-buttons">
                    <a href="module_detail.php?module_id=<?php echo $module_id; ?>" class="btn btn-primary btn-full">返回项目列表</a>
                    <?php if (!empty($wrong_answers)): ?>
                        <a href="wrong_questions.php?project_id=<?php echo $project_id; ?>" class="btn btn-error btn-full">复习错题</a>
                    <?php endif; ?>
                    <a href="quiz.php?project_id=<?php echo $project_id; ?>" class="btn btn-outline btn-full">重新测试</a>
                </div>
            </div>
        </div>
    </body>
    </html>
    <?php
    exit();
}
?>

<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
    <title><?php echo htmlspecialchars($project['project_name']); ?> - 多课程在线刷题系统</title>
    <link rel="stylesheet" href="../config/style.css">
    <style>
        .quiz-header {
            background: var(--bg-primary);
            padding: 20px;
            border-radius: 12px;
            margin-bottom: 20px;
            box-shadow: var(--shadow);
            position: sticky;
            top: 80px;
            z-index: 10;
        }
        
        .breadcrumb {
            font-size: 14px;
            color: var(--text-secondary);
            margin-bottom: 12px;
        }
        
        .breadcrumb a {
            color: var(--primary-color);
            text-decoration: none;
        }
        
        .progress-info {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 12px;
            font-size: 14px;
            color: var(--text-secondary);
        }
        
        .progress-bar {
            height: 6px;
            background: var(--bg-tertiary);
            border-radius: 3px;
            overflow: hidden;
        }
        
        .progress-fill {
            height: 100%;
            background: linear-gradient(135deg, var(--primary-color), var(--secondary-color));
            transition: width 0.3s ease;
        }
        
        .question-counter {
            font-weight: 600;
            color: var(--text-primary);
        }
        
        .question-card {
            margin-bottom: 16px;
            transition: transform 0.3s ease;
            position: relative;
        }
        
        .favorite-btn {
            position: absolute;
            top: 20px;
            left: 50%;
            transform: translateX(-50%);
            background: none;
            border: none;
            font-size: 24px;
            cursor: pointer;
            transition: transform 0.3s ease;
            z-index: 5;
        }
        
        .favorite-btn:hover {
            transform: translateX(-50%) scale(1.2);
        }
        
        .favorite-btn.active {
            color: #e74c3c;
        }
        
        .navigation-buttons {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 12px;
            margin-top: 24px;
            position: sticky;
            bottom: 20px;
            background: var(--bg-primary);
            padding: 16px;
            border-radius: 12px;
            box-shadow: var(--shadow-lg);
        }
        
        /* 题目导航样式保持不变 */
        .quiz-navigation {
            position: fixed;
            top: 80px;
            right: 20px;
            background: white;
            border-radius: 12px;
            box-shadow: var(--shadow-lg);
            padding: 15px;
            z-index: 100;
            max-height: 70vh;
            overflow-y: auto;
            width: 280px;
        }
        
        .nav-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 12px;
            padding-bottom: 10px;
            border-bottom: 1px solid var(--border-color);
        }
        
        .nav-title {
            font-weight: 600;
            color: var(--text-primary);
        }
        
        .nav-close {
            background: none;
            border: none;
            font-size: 20px;
            cursor: pointer;
            color: var(--text-secondary);
        }
        
        .nav-grid {
            display: grid;
            grid-template-columns: repeat(5, 1fr);
            gap: 8px;
        }
        
        .nav-item {
            width: 40px;
            height: 40px;
            border: 2px solid var(--border-color);
            border-radius: 8px;
            display: flex;
            align-items: center;
            justify-content: center;
            cursor: pointer;
            font-size: 14px;
            font-weight: 600;
            transition: all 0.3s ease;
            text-decoration: none;
            color: var(--text-primary);
        }
        
        .nav-item.current {
            border-color: var(--primary-color);
            background: var(--primary-color);
            color: white;
        }
        
        .nav-item.answered {
            border-color: var(--success-color);
            background: var(--success-color);
            color: white;
        }
        
        .nav-item.unanswered {
            border-color: var(--error-color);
            background: #fee2e2;
            color: var(--error-color);
        }
        
        .nav-toggle {
            position: fixed;
            top: 80px;
            right: 20px;
            background: var(--primary-color);
            color: white;
            border: none;
            border-radius: 50%;
            width: 50px;
            height: 50px;
            font-size: 20px;
            cursor: pointer;
            box-shadow: var(--shadow-lg);
            z-index: 99;
            display: flex;
            align-items: center;
            justify-content: center;
        }
        
        /* 其他样式保持不变 */
        @media (max-width: 640px) {
            .quiz-header {
                top: 70px;
                padding: 16px;
            }
            
            .navigation-buttons {
                grid-template-columns: 1fr;
            }
            
            .favorite-btn {
                top: 15px;
                font-size: 20px;
            }
            
            .quiz-navigation {
                top: 70px;
                right: 10px;
                width: 250px;
            }
            
            .nav-toggle {
                top: 70px;
                right: 10px;
                width: 45px;
                height: 45px;
            }
        }
    </style>
</head>
<body>
    <!-- 导航栏 -->
    <nav class="navbar">
        <div class="container">
            <div class="nav-content">
                <a href="module_detail.php?module_id=<?php 
                    $module_stmt = $pdo->prepare("SELECT module_id FROM projects WHERE id = ?");
                    $module_stmt->execute([$project_id]);
                    $module_id = $module_stmt->fetchColumn();
                    echo $module_id;
                ?>" class="nav-brand">← 返回</a>
                <span class="nav-brand"><?php echo htmlspecialchars($project['project_name']); ?></span>
            </div>
        </div>
    </nav>

    <!-- 题目导航面板 -->
    <button class="nav-toggle" onclick="toggleNavigation()">📋</button>
    
    <div class="quiz-navigation" id="quizNavigation" style="display: none;">
        <div class="nav-header">
            <div class="nav-title">题目导航</div>
            <button class="nav-close" onclick="toggleNavigation()">×</button>
        </div>
        
        <div class="nav-grid" id="questionNavGrid">
            <!-- 题目导航项将通过JavaScript动态生成 -->
        </div>
    </div>

    <div class="container">
        <div class="breadcrumb">
            <a href="index.php">学习中心</a> &gt; 
            <a href="course_detail.php?course_id=<?php 
                $course_stmt = $pdo->prepare("SELECT c.id FROM courses c JOIN modules m ON c.id = m.course_id JOIN projects p ON m.id = p.module_id WHERE p.id = ?");
                $course_stmt->execute([$project_id]);
                $course_id = $course_stmt->fetchColumn();
                echo $course_id;
            ?>"><?php echo htmlspecialchars($project['course_name']); ?></a> &gt; 
            <a href="module_detail.php?module_id=<?php echo $module_id; ?>"><?php echo htmlspecialchars($project['module_name']); ?></a> &gt; 
            <?php echo htmlspecialchars($project['project_name']); ?>
        </div>

        <form method="post" id="quizForm">
            <?php foreach ($questions as $index => $question): 
                // 随机排序选项
                $options = [];
                foreach (['A', 'B', 'C', 'D'] as $option) {
                    if (!empty($question['option_' . strtolower($option)])) {
                        $options[$option] = $question['option_' . strtolower($option)];
                    }
                }
                // 打乱选项顺序但记住正确答案
                $correct_answer = $question['correct_answer'];
                $correct_option_text = $options[$correct_answer];
                shuffle_assoc($options);
                
                // 重新找到正确答案在新顺序中的位置
                $new_correct_answer = array_search($correct_option_text, $options);
            ?>
                <div class="question-card card" id="question-<?php echo $index; ?>" <?php echo $index > 0 ? 'style="display: none;"' : ''; ?>>
                    <div class="progress-info">
                        <span class="question-counter">题目 <?php echo $index + 1; ?> / <?php echo count($questions); ?></span>
                    </div>
                    
                    <div class="progress-bar">
                        <div class="progress-fill" style="width: <?php echo (($index + 1) / count($questions)) * 100; ?>%"></div>
                    </div>
                    
                    <!-- 收藏按钮 -->
                    <button type="button" class="favorite-btn <?php echo $favorite_status[$question['id']] ? 'active' : ''; ?>" 
                            data-question-id="<?php echo $question['id']; ?>" 
                            data-is-favorite="<?php echo $favorite_status[$question['id']] ? 'true' : 'false'; ?>">
                        <?php echo $favorite_status[$question['id']] ? '❤️' : '🤍'; ?>
                    </button>
                    
                    <div class="question-text">
                        <?php echo htmlspecialchars($question['question_text']); ?>
                    </div>
                    
                    <div class="options-grid">
                        <?php foreach ($options as $option => $text): ?>
                            <label class="option-item">
                                <input type="radio" name="answer_<?php echo $question['id']; ?>" value="<?php echo $option; ?>" class="option-input" required
                                       onchange="updateQuestionStatus(<?php echo $index; ?>, true)">
                                <span class="option-label">
                                    <strong><?php echo $option; ?>.</strong> 
                                    <?php echo htmlspecialchars($text); ?>
                                </span>
                            </label>
                        <?php endforeach; ?>
                    </div>
                </div>
            <?php endforeach; ?>
            
            <div class="navigation-buttons">
                <button type="button" class="btn btn-outline" onclick="showPreviousQuestion()" id="prevBtn" style="display: none;">上一题</button>
                <button type="button" class="btn btn-primary" onclick="showNextQuestion()" id="nextBtn">下一题</button>
                <button type="button" class="btn btn-success btn-full" id="submitBtn" style="display: none;" onclick="checkBeforeSubmit()">提交答案</button>
            </div>
        </form>
    </div>

<script>
    // JavaScript代码保持不变，与原来的quiz.php相同
    let currentQuestion = 0;
    const totalQuestions = <?php echo count($questions); ?>;
    const questionStatus = new Array(totalQuestions).fill(false);
    
    function initQuestionNavigation() {
        const navGrid = document.getElementById('questionNavGrid');
        navGrid.innerHTML = '';
        
        for (let i = 0; i < totalQuestions; i++) {
            const navItem = document.createElement('a');
            navItem.className = 'nav-item';
            navItem.href = 'javascript:void(0)';
            navItem.innerHTML = i + 1;
            navItem.onclick = () => showQuestion(i);
            
            if (i === currentQuestion) {
                navItem.classList.add('current');
            } else if (questionStatus[i]) {
                navItem.classList.add('answered');
            } else {
                navItem.classList.add('unanswered');
            }
            
            navGrid.appendChild(navItem);
        }
    }
    
    function showQuestion(index) {
        document.querySelectorAll('.question-card').forEach(card => {
            card.style.display = 'none';
        });
        
        document.getElementById('question-' + index).style.display = 'block';
        
        document.getElementById('prevBtn').style.display = index > 0 ? 'block' : 'none';
        document.getElementById('nextBtn').style.display = index < totalQuestions - 1 ? 'block' : 'none';
        document.getElementById('submitBtn').style.display = index === totalQuestions - 1 ? 'block' : 'none';
        
        currentQuestion = index;
        initQuestionNavigation();
    }
    
    function showNextQuestion() {
        if (currentQuestion < totalQuestions - 1) {
            showQuestion(currentQuestion + 1);
        }
    }
    
    function showPreviousQuestion() {
        if (currentQuestion > 0) {
            showQuestion(currentQuestion - 1);
        }
    }
    
    function updateQuestionStatus(questionIndex, isAnswered) {
        questionStatus[questionIndex] = isAnswered;
        initQuestionNavigation();
        
        if (isAnswered && questionIndex < totalQuestions - 1) {
            setTimeout(() => {
                showNextQuestion();
            }, 300);
        }
    }
    
    function toggleNavigation() {
        const nav = document.getElementById('quizNavigation');
        nav.style.display = nav.style.display === 'none' ? 'block' : 'none';
    }
    
    function checkBeforeSubmit() {
        const allAnswered = questionStatus.every(status => status);
        if (allAnswered) {
            document.getElementById('quizForm').submit();
        } else {
            alert('请完成所有题目后再提交！');
            // 跳转到第一道未做题
            const firstUnanswered = questionStatus.findIndex(status => !status);
            if (firstUnanswered !== -1) {
                showQuestion(firstUnanswered);
                toggleNavigation();
            }
        }
    }
    
    // 收藏功能
    document.querySelectorAll('.favorite-btn').forEach(btn => {
        btn.addEventListener('click', function() {
            const questionId = this.dataset.questionId;
            const isFavorite = this.dataset.isFavorite === 'true';
            
            fetch('quiz.php?project_id=<?php echo $project_id; ?>', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded',
                },
                body: `toggle_favorite=true&question_id=${questionId}&is_favorite=${isFavorite}`
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    this.dataset.isFavorite = data.is_favorite ? 'true' : 'false';
                    this.innerHTML = data.is_favorite ? '❤️' : '🤍';
                    this.classList.toggle('active', data.is_favorite);
                }
            })
            .catch(error => console.error('Error:', error));
        });
    });
    
    // 键盘快捷键
    document.addEventListener('keydown', function(e) {
        switch(e.key) {
            case 'ArrowLeft':
                if (currentQuestion > 0) {
                    showPreviousQuestion();
                }
                break;
            case 'ArrowRight':
                if (currentQuestion < totalQuestions - 1) {
                    showNextQuestion();
                }
                break;
            case 'Escape':
                toggleNavigation();
                break;
        }
    });
    
    // 初始化
    document.addEventListener('DOMContentLoaded', function() {
        initQuestionNavigation();
        
        // 初始化题目状态
        document.querySelectorAll('.question-card').forEach((card, index) => {
            const questionId = card.querySelector('input[type="radio"]').name;
            const answered = document.querySelector(`input[name="${questionId}"]:checked`);
            questionStatus[index] = !!answered;
        });
    });
</script>
</body>
</html>

<?php
// 辅助函数：打乱关联数组顺序但保持键值关系
function shuffle_assoc(&$array) {
    $keys = array_keys($array);
    shuffle($keys);
    $new = [];
    foreach($keys as $key) {
        $new[$key] = $array[$key];
    }
    $array = $new;
    return true;
}
?>