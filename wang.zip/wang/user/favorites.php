<?php
require_once '../config/database.php';

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

$project_id = $_GET['project_id'] ?? 'all';
$course_id = $_GET['course_id'] ?? 'all';

// 获取收藏的题目（根据筛选条件）
$where_conditions = ["fq.user_id = ?"];
$params = [$_SESSION['user_id']];

if ($course_id != 'all') {
    $where_conditions[] = "c.id = ?";
    $params[] = $course_id;
}

if ($project_id != 'all') {
    $where_conditions[] = "fq.project_id = ?";
    $params[] = $project_id;
}

$where_sql = implode(" AND ", $where_conditions);

$favorites_stmt = $pdo->prepare("
    SELECT fq.*, q.question_text, q.option_a, q.option_b, q.option_c, q.option_d, 
           q.correct_answer, q.explanation, p.project_name, p.id as project_id,
           m.module_name, c.course_name, c.id as course_id
    FROM favorite_questions fq 
    JOIN questions q ON fq.question_id = q.id 
    JOIN projects p ON fq.project_id = p.id
    JOIN modules m ON p.module_id = m.id
    JOIN courses c ON m.course_id = c.id
    WHERE $where_sql
    ORDER BY fq.created_at DESC
");
$favorites_stmt->execute($params);
$favorite_questions = $favorites_stmt->fetchAll();

// 获取所有包含收藏题目的课程用于筛选
$courses_stmt = $pdo->prepare("
    SELECT DISTINCT c.id, c.course_name, COUNT(fq.id) as question_count
    FROM favorite_questions fq 
    JOIN questions q ON fq.question_id = q.id 
    JOIN projects p ON fq.project_id = p.id
    JOIN modules m ON p.module_id = m.id
    JOIN courses c ON m.course_id = c.id
    WHERE fq.user_id = ?
    GROUP BY c.id, c.course_name
    ORDER BY c.course_name
");
$courses_stmt->execute([$_SESSION['user_id']]);
$available_courses = $courses_stmt->fetchAll();

// 获取所有包含收藏题目的项目用于筛选
$projects_stmt = $pdo->prepare("
    SELECT DISTINCT p.id, p.project_name, m.module_name, c.course_name, c.id as course_id, COUNT(fq.id) as question_count
    FROM favorite_questions fq 
    JOIN questions q ON fq.question_id = q.id 
    JOIN projects p ON fq.project_id = p.id
    JOIN modules m ON p.module_id = m.id
    JOIN courses c ON m.course_id = c.id
    WHERE fq.user_id = ?
    GROUP BY p.id, p.project_name, m.module_name, c.course_name, c.id
    ORDER BY c.course_name, m.module_name, p.project_name
");
$projects_stmt->execute([$_SESSION['user_id']]);
$available_projects = $projects_stmt->fetchAll();

// 按课程分组
$favorites_by_course = [];
$total_count = 0;
foreach ($favorite_questions as $question) {
    $current_course_id = $question['course_id'] ?? 'unknown';
    if (!isset($favorites_by_course[$current_course_id])) {
        $favorites_by_course[$current_course_id] = [
            'course_name' => $question['course_name'],
            'questions' => []
        ];
    }
    $favorites_by_course[$current_course_id]['questions'][] = $question;
    $total_count++;
}

// 取消收藏
if (isset($_POST['remove_favorite'])) {
    $favorite_id = $_POST['favorite_id'];
    $remove_stmt = $pdo->prepare("DELETE FROM favorite_questions WHERE id = ? AND user_id = ?");
    $remove_stmt->execute([$favorite_id, $_SESSION['user_id']]);
    
    $redirect_url = "favorites.php";
    if ($project_id != 'all') $redirect_url .= "?project_id=" . $project_id;
    if ($course_id != 'all') $redirect_url .= (strpos($redirect_url, '?') === false ? "?" : "&") . "course_id=" . $course_id;
    
    header("Location: " . $redirect_url);
    exit();
}

// 准备当前选中的项目数据用于JavaScript
$current_course_projects = [];
if ($course_id != 'all') {
    foreach ($available_projects as $project) {
        if ($project['course_id'] == $course_id) {
            $current_course_projects[] = $project;
        }
    }
}
?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
    <title>我的收藏 - 多课程在线刷题系统</title>
    <link rel="stylesheet" href="../config/style.css">
    <style>
        .filters-section {
            background: var(--bg-primary);
            padding: 20px;
            border-radius: 12px;
            margin-bottom: 24px;
        }
        
        .filter-group {
            display: flex;
            gap: 16px;
            align-items: center;
            margin-bottom: 16px;
        }
        
        .filter-label {
            font-weight: 600;
            color: var(--text-primary);
            min-width: 80px;
        }
        
        .filter-select {
            flex: 1;
            padding: 10px 16px;
            border: 2px solid var(--border-color);
            border-radius: 8px;
            background: white;
            font-size: 14px;
            color: var(--text-primary);
            cursor: pointer;
        }
        
        .filter-stats {
            display: flex;
            gap: 16px;
            font-size: 14px;
            color: var(--text-secondary);
            margin-top: 16px;
            padding-top: 16px;
            border-top: 1px solid var(--border-color);
        }
        
        .stat-item {
            display: flex;
            align-items: center;
            gap: 6px;
        }
        
        .stat-value {
            font-weight: 600;
            color: var(--primary-color);
        }
        
        .favorite-course {
            margin-bottom: 32px;
        }
        
        .course-header {
            background: linear-gradient(135deg, #e67e22, #e74c3c);
            color: white;
            padding: 20px;
            border-radius: 12px;
            margin-bottom: 16px;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        
        .course-title {
            font-size: 18px;
            font-weight: 600;
        }
        
        .favorite-count {
            background: rgba(255, 255, 255, 0.2);
            padding: 4px 12px;
            border-radius: 20px;
            font-size: 14px;
        }
        
        .favorite-item {
            background: #fff9e6;
            border: 2px solid #ffeaa7;
            border-radius: 12px;
            padding: 20px;
            margin-bottom: 16px;
            position: relative;
        }
        
        .question-header {
            display: flex;
            justify-content: space-between;
            align-items: flex-start;
            margin-bottom: 12px;
        }
        
        .question-text {
            font-weight: 600;
            color: var(--text-primary);
            flex: 1;
            padding-right: 60px;
        }
        
        .question-meta {
            font-size: 12px;
            color: var(--text-secondary);
            text-align: right;
        }
        
        .project-path {
            background: #e8f5e8;
            padding: 4px 8px;
            border-radius: 6px;
            font-size: 12px;
            margin-bottom: 8px;
        }
        
        .options-review {
            margin: 16px 0;
            padding: 16px;
            background: #f8f9fa;
            border-radius: 8px;
        }
        
        .option-review-item {
            padding: 10px 14px;
            margin: 6px 0;
            border-radius: 6px;
            border: 1px solid #e9ecef;
            background: white;
        }
        
        .correct-option {
            background: #d1fae5;
            border-color: #a7f3d0;
            color: #065f46;
            border-left: 4px solid #059669;
        }
        
        .option-label {
            font-weight: 600;
            margin-right: 8px;
            display: inline-block;
            width: 24px;
        }
        
        .remove-favorite-btn {
            position: absolute;
            top: 20px;
            right: 20px;
            background: none;
            border: none;
            font-size: 20px;
            cursor: pointer;
            color: #e74c3c;
            transition: transform 0.3s ease;
        }
        
        .remove-favorite-btn:hover {
            transform: scale(1.2);
        }
        
        .empty-state {
            text-align: center;
            padding: 60px 20px;
            color: var(--text-secondary);
        }
        
        .empty-icon {
            font-size: 64px;
            margin-bottom: 20px;
        }
        
        .action-buttons {
            display: flex;
            gap: 10px;
            margin-top: 15px;
            flex-wrap: wrap;
        }
        
        .review-all-btn {
            background: linear-gradient(135deg, #e67e22, #e74c3c);
            color: white;
            border: none;
        }
        
        .review-all-btn:hover {
            background: linear-gradient(135deg, #d35400, #c0392b);
        }
        
        .course-actions {
            display: flex;
            gap: 10px;
            margin-top: 16px;
            flex-wrap: wrap;
        }
        
        .btn-course-review {
            background: #e67e22;
            color: white;
        }
        
        .btn-course-review:hover {
            background: #d35400;
        }
        
        .filter-actions {
            display: flex;
            gap: 12px;
            margin-top: 16px;
            flex-wrap: wrap;
        }
        
        @media (max-width: 640px) {
            .filter-group {
                flex-direction: column;
                align-items: stretch;
                gap: 8px;
            }
            
            .filter-label {
                min-width: auto;
            }
            
            .filter-stats {
                flex-direction: column;
                gap: 8px;
            }
            
            .course-header {
                flex-direction: column;
                gap: 12px;
                text-align: center;
            }
            
            .question-header {
                flex-direction: column;
                gap: 8px;
            }
            
            .question-text {
                padding-right: 0;
                padding-top: 40px;
            }
            
            .remove-favorite-btn {
                top: 15px;
                right: 15px;
            }
            
            .question-meta {
                text-align: left;
            }
            
            .course-actions, .filter-actions {
                justify-content: center;
            }
        }
    </style>
    <script>
        // 存储所有项目的原始数据
        const allProjects = <?php echo json_encode($available_projects); ?>;
        
        function updateProjectFilter() {
            const courseSelect = document.getElementById('courseFilter');
            const projectSelect = document.getElementById('projectFilter');
            const selectedCourseId = courseSelect.value;
            
            // 保存当前选中的项目ID
            const currentSelectedProjectId = '<?php echo $project_id; ?>';
            
            // 清空项目选择器
            projectSelect.innerHTML = '<option value="all">所有项目</option>';
            
            // 筛选项目
            let filteredProjects = allProjects;
            if (selectedCourseId !== 'all') {
                filteredProjects = allProjects.filter(project => project.course_id == selectedCourseId);
            }
            
            // 添加项目选项
            filteredProjects.forEach(project => {
                const option = document.createElement('option');
                option.value = project.id;
                option.textContent = `${project.module_name} > ${project.project_name} (${project.question_count}题)`;
                
                // 如果这是之前选中的项目，保持选中状态
                if (project.id == currentSelectedProjectId) {
                    option.selected = true;
                }
                
                projectSelect.appendChild(option);
            });
        }
        
        function applyFilters() {
            const courseId = document.getElementById('courseFilter').value;
            const projectId = document.getElementById('projectFilter').value;
            
            let url = 'favorites.php?';
            
            if (courseId !== 'all') {
                url += 'course_id=' + encodeURIComponent(courseId) + '&';
            }
            
            if (projectId !== 'all') {
                url += 'project_id=' + encodeURIComponent(projectId) + '&';
            }
            
            // 移除末尾的&
            url = url.replace(/[&]+$/, '');
            
            // 如果url以?结尾，移除?
            if (url.endsWith('?')) {
                url = url.slice(0, -1);
            }
            
            window.location.href = url;
        }
        
        // 页面加载时初始化
        document.addEventListener('DOMContentLoaded', function() {
            updateProjectFilter();
        });
    </script>
</head>
<body>
    <nav class="navbar">
        <div class="container">
            <div class="nav-content">
                <a href="index.php" class="nav-brand">← 返回学习中心</a>
                <span class="nav-brand">我的收藏</span>
            </div>
        </div>
    </nav>

    <div class="container">
        <?php if (empty($favorite_questions)): ?>
            <div class="empty-state">
                <div class="empty-icon">📚</div>
                <h2>暂无收藏题目</h2>
                <p>在刷题时点击心形图标可以收藏题目</p>
                <a href="index.php" class="btn btn-primary mt-3">开始刷题</a>
            </div>
        <?php else: ?>
            <div class="filters-section">
                <h2>我的收藏</h2>
                <p>筛选和查看您的收藏题目</p>
                
                <div class="filter-group">
                    <div class="filter-label">按课程筛选：</div>
                    <select id="courseFilter" class="filter-select" onchange="updateProjectFilter()">
                        <option value="all" <?php echo $course_id == 'all' ? 'selected' : ''; ?>>所有课程</option>
                        <?php foreach ($available_courses as $course): ?>
                            <option value="<?php echo $course['id']; ?>" <?php echo $course_id == $course['id'] ? 'selected' : ''; ?>>
                                <?php echo htmlspecialchars($course['course_name'] . " (" . $course['question_count'] . "题)"); ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>
                
                <div class="filter-group">
                    <div class="filter-label">按项目筛选：</div>
                    <select id="projectFilter" class="filter-select">
                        <option value="all">所有项目</option>
                        <!-- 项目选项通过JavaScript动态生成 -->
                    </select>
                </div>
                
                <div class="filter-actions">
                    <button onclick="applyFilters()" class="btn btn-primary">应用筛选</button>
                    <a href="favorites.php" class="btn btn-outline">重置筛选</a>
                    <a href="review_favorites.php?course_id=<?php echo $course_id; ?>&project_id=<?php echo $project_id; ?>" class="btn review-all-btn">
                        刷题模式 (当前<?php echo $total_count; ?>题)
                    </a>
                </div>
                
                <div class="filter-stats">
                    <div class="stat-item">
                        <span>当前显示：</span>
                        <span class="stat-value"><?php echo $total_count; ?>题</span>
                    </div>
                    <div class="stat-item">
                        <span>收藏总数：</span>
                        <span class="stat-value">
                            <?php 
                                $total_fav_stmt = $pdo->prepare("SELECT COUNT(*) as total FROM favorite_questions WHERE user_id = ?");
                                $total_fav_stmt->execute([$_SESSION['user_id']]);
                                $total_fav = $total_fav_stmt->fetch();
                                echo $total_fav['total'];
                            ?>题
                        </span>
                    </div>
                    <?php if ($course_id != 'all' || $project_id != 'all'): ?>
                    <div class="stat-item">
                        <span>筛选状态：</span>
                        <span class="stat-value" style="color: #e67e22;">
                            <?php 
                                if ($course_id != 'all' && $project_id != 'all') {
                                    echo "课程 + 项目筛选";
                                } elseif ($course_id != 'all') {
                                    echo "课程筛选";
                                } elseif ($project_id != 'all') {
                                    echo "项目筛选";
                                }
                            ?>
                        </span>
                    </div>
                    <?php endif; ?>
                </div>
            </div>
            
            <?php foreach ($favorites_by_course as $current_course_id => $course_data): ?>
                <div class="favorite-course">
                    <div class="course-header">
                        <div class="course-title"><?php echo htmlspecialchars($course_data['course_name']); ?></div>
                        <div class="favorite-count"><?php echo count($course_data['questions']); ?> 题</div>
                    </div>
                    
                    <div class="course-actions">
                        <a href="review_favorites.php?course_id=<?php echo $current_course_id; ?>&project_id=all" class="btn btn-course-review">
                            刷题模式 (本课程<?php echo count($course_data['questions']); ?>题)
                        </a>
                        <a href="quiz.php?course_id=<?php echo $current_course_id; ?>" class="btn btn-outline">
                            前往课程刷题
                        </a>
                    </div>
                    
                    <?php foreach ($course_data['questions'] as $index => $question): ?>
                        <div class="favorite-item">
                            <form method="post" style="display: inline;">
                                <input type="hidden" name="favorite_id" value="<?php echo $question['id']; ?>">
                                <button type="submit" name="remove_favorite" class="remove-favorite-btn" 
                                        onclick="return confirm('确定要取消收藏这道题目吗？')">
                                    ❌
                                </button>
                            </form>
                            
                            <div class="project-path">
                                <?php echo htmlspecialchars($question['module_name']); ?> &gt; 
                                <?php echo htmlspecialchars($question['project_name']); ?>
                            </div>
                            
                            <div class="question-header">
                                <div class="question-text">
                                    <?php echo ($index + 1) . '. ' . htmlspecialchars($question['question_text']); ?>
                                </div>
                                <div class="question-meta">
                                    收藏时间: <?php echo date('Y-m-d H:i', strtotime($question['created_at'])); ?>
                                </div>
                            </div>
                            
                            <div class="options-review">
                                <strong style="display: block; margin-bottom: 12px;">选项：</strong>
                                <?php foreach (['A', 'B', 'C', 'D'] as $option): ?>
                                    <?php if (!empty($question['option_' . strtolower($option)])): 
                                        $option_class = $option == $question['correct_answer'] ? 'correct-option' : '';
                                    ?>
                                        <div class="option-review-item <?php echo $option_class; ?>">
                                            <span class="option-label"><?php echo $option; ?>.</span>
                                            <?php echo htmlspecialchars($question['option_' . strtolower($option)]); ?>
                                            <?php if ($option == $question['correct_answer']): ?>
                                                <span class="option-badge" style="background: #059669; color: white; margin-left: 8px; padding: 2px 8px; border-radius: 12px; font-size: 12px;">正确答案</span>
                                            <?php endif; ?>
                                        </div>
                                    <?php endif; ?>
                                <?php endforeach; ?>
                            </div>
                            
                            <?php if ($question['explanation']): ?>
                                <div class="explanation" style="background: #e7f3ff; border: 1px solid #b3d9ff; padding: 12px; border-radius: 8px; margin-top: 12px;">
                                    <strong>解析：</strong>
                                    <?php echo htmlspecialchars($question['explanation']); ?>
                                </div>
                            <?php endif; ?>
                            
                            <div class="action-buttons">
                                <a href="review_favorites.php?course_id=<?php echo $question['course_id']; ?>&project_id=<?php echo $question['project_id']; ?>" class="btn btn-primary btn-sm">
                                    重做本项目收藏题
                                </a>
                                <a href="quiz.php?project_id=<?php echo $question['project_id']; ?>" class="btn btn-outline btn-sm">
                                    前往项目刷题
                                </a>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>
            <?php endforeach; ?>
            
            <div class="text-center mt-4">
                <a href="review_favorites.php?course_id=<?php echo $course_id; ?>&project_id=<?php echo $project_id; ?>" class="btn review-all-btn">
                    刷题模式 (当前<?php echo $total_count; ?>题)
                </a>
                <a href="index.php" class="btn btn-outline">返回学习中心</a>
            </div>
        <?php endif; ?>
    </div>
</body>
</html>