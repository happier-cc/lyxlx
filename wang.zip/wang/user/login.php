<?php
require_once '../config/database.php';

// 检查网站是否开启
$site_enabled = true;
try {
    $check_table = $pdo->query("SHOW TABLES LIKE 'system_settings'");
    if ($check_table->rowCount() > 0) {
        $setting_stmt = $pdo->prepare("SELECT setting_value FROM system_settings WHERE setting_key = 'site_enabled'");
        $setting_stmt->execute();
        $setting = $setting_stmt->fetch();
        if ($setting && $setting['setting_value'] == '0') {
            $site_enabled = false;
        }
    }
} catch (PDOException $e) {
    // 如果查询失败，默认网站开启
    $site_enabled = true;
}

// 如果网站关闭且用户不是管理员，显示维护页面
if (!$site_enabled && (!isset($_SESSION['user_id']) || $_SESSION['role'] != 'admin')) {
    include '../maintenance.php';
    exit();
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $username = trim($_POST['username']);
    $password = $_POST['password'];
    
    try {
        $stmt = $pdo->prepare("SELECT * FROM users WHERE username = ?");
        $stmt->execute([$username]);
        $user = $stmt->fetch();
        
        if ($user) {
            // 检查账号是否被禁用
            if ($user['status'] == 'disabled') {
                $error = "账号已被禁用，请联系管理员！";
            } elseif (password_verify($password, $user['password'])) {
                // 更新最后登录时间
                $update_stmt = $pdo->prepare("UPDATE users SET last_login = NOW() WHERE id = ?");
                $update_stmt->execute([$user['id']]);
                
                $_SESSION['user_id'] = $user['id'];
                $_SESSION['username'] = $user['username'];
                $_SESSION['role'] = $user['role'];
                $_SESSION['success'] = "登录成功！";
                header("Location: index.php");
                exit();
            } else {
                $error = "用户名或密码错误！";
            }
        } else {
            $error = "用户名或密码错误！";
        }
    } catch(PDOException $e) {
        $error = "登录失败，请稍后重试";
    }
}
?>

<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
    <title>用户登录 - 多课程在线刷题系统</title>
    <link rel="stylesheet" href="../config/style.css">
    <style>
        body { 
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 20px;
        }
        .login-card {
            background: white;
            padding: 30px;
            border-radius: 20px;
            box-shadow: 0 20px 40px rgba(0,0,0,0.1);
            width: 100%;
            max-width: 400px;
        }
        .logo {
            text-align: center;
            margin-bottom: 30px;
        }
        .logo h1 {
            color: var(--primary-color);
            font-size: 28px;
        }
        .system-features {
            background: #f8f9fa;
            padding: 15px;
            border-radius: 10px;
            margin: 20px 0;
            font-size: 14px;
        }
        .features-list {
            margin: 8px 0 0 20px;
        }
    </style>
</head>
<body>
    <div class="login-card">
        <div class="logo">
            <h1>📚 旅游类刷题系统</h1>
            <p>欢迎回来，请登录</p>
        </div>
        
        <?php if (isset($error)): ?>
            <div class="alert alert-error"><?php echo $error; ?></div>
        <?php endif; ?>
        
        <?php if (isset($_SESSION['success'])): ?>
            <div class="alert alert-success"><?php echo $_SESSION['success']; unset($_SESSION['success']); ?></div>
        <?php endif; ?>

        <form method="post">
            <div class="form-group">
                <label for="username" class="form-label">用户名：</label>
                <input type="text" id="username" name="username" class="form-input" 
                       value="<?php echo isset($_POST['username']) ? htmlspecialchars($_POST['username']) : ''; ?>" 
                       placeholder="请输入用户名" required>
            </div>
            
            <div class="form-group">
                <label for="password" class="form-label">密码：</label>
                <input type="password" id="password" name="password" class="form-input" 
                       placeholder="请输入密码" required>
            </div>
            
            <button type="submit" class="btn btn-primary btn-full">登录</button>
        </form>
        
        <div class="text-center mt-3">
            <p>没有账号？<a href="register.php" style="color: var(--primary-color);">立即注册</a></p>
            <p><a href="../index.php" style="color: var(--text-secondary);">返回首页</a></p>
        </div>
    </div>
</body>
</html>