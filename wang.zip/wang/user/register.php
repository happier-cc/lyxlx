<?php
require_once '../config/database.php';

// 检查网站是否开启
$site_enabled = true;
try {
    $check_table = $pdo->query("SHOW TABLES LIKE 'system_settings'");
    if ($check_table->rowCount() > 0) {
        $setting_stmt = $pdo->prepare("SELECT setting_value FROM system_settings WHERE setting_key = 'site_enabled'");
        $setting_stmt->execute();
        $setting = $setting_stmt->fetch();
        if ($setting && $setting['setting_value'] == '0') {
            $site_enabled = false;
        }
    }
} catch (PDOException $e) {
    // 如果查询失败，默认网站开启
    $site_enabled = true;
}

// 如果网站关闭且用户不是管理员，显示维护页面
if (!$site_enabled && (!isset($_SESSION['user_id']) || $_SESSION['role'] != 'admin')) {
    include '../maintenance.php';
    exit();
}

// 检查注册功能是否开启
$registration_enabled = true;
try {
    $check_table = $pdo->query("SHOW TABLES LIKE 'system_settings'");
    if ($check_table->rowCount() > 0) {
        $setting_stmt = $pdo->prepare("SELECT setting_value FROM system_settings WHERE setting_key = 'registration_enabled'");
        $setting_stmt->execute();
        $setting = $setting_stmt->fetch();
        if ($setting && $setting['setting_value'] == '0') {
            $registration_enabled = false;
        }
    }
} catch (PDOException $e) {
    // 如果查询失败，默认允许注册
    $registration_enabled = true;
}

if (!$registration_enabled) {
    // 注册功能关闭，显示提示信息
    ?>
    <!DOCTYPE html>
    <html lang="zh-CN">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
        <title>注册暂不可用 - 多课程在线刷题系统</title>
        <link rel="stylesheet" href="../config/style.css">
        <style>
            body { 
                background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
                min-height: 100vh;
                display: flex;
                align-items: center;
                justify-content: center;
                padding: 20px;
            }
            .message-card {
                background: white;
                padding: 40px;
                border-radius: 20px;
                box-shadow: 0 20px 40px rgba(0,0,0,0.1);
                text-align: center;
                max-width: 500px;
                width: 100%;
            }
            .message-icon {
                font-size: 64px;
                margin-bottom: 20px;
            }
        </style>
    </head>
    <body>
        <div class="message-card">
            <div class="message-icon">🚫</div>
            <h1>注册功能暂不可用</h1>
            <p>系统目前暂停新用户注册，请稍后再试或联系管理员。</p>
            
            <div style="background: #f8f9fa; padding: 20px; border-radius: 10px; margin: 20px 0;">
                <p><strong>可能的原因：</strong></p>
                <ul style="text-align: left; margin: 10px 0;">
                    <li>系统维护升级中</li>
                    <li>用户数量已达到上限</li>
                    <li>管理员暂时关闭了注册功能</li>
                </ul>
            </div>
            
            <div class="grid grid-2" style="gap: 12px;">
                <a href="login.php" class="btn btn-primary">用户登录</a>
                <a href="../index.php" class="btn btn-outline">返回首页</a>
            </div>
            
            <div style="margin-top: 20px; font-size: 14px; color: var(--text-secondary);">
                <p>如有疑问，请联系系统管理员</p>
            </div>
        </div>
    </body>
    </html>
    <?php
    exit();
}

// 原有的注册逻辑（只有在注册开启时才执行）
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $username = trim($_POST['username']);
    $password = $_POST['password'];
    $confirm_password = $_POST['confirm_password'];
    
    // 验证输入
    if (empty($username) || empty($password)) {
        $error = "用户名和密码不能为空！";
    } elseif (strlen($username) < 3) {
        $error = "用户名长度不能少于3位！";
    } elseif (strlen($password) < 6) {
        $error = "密码长度不能少于6位！";
    } elseif ($password !== $confirm_password) {
        $error = "两次输入的密码不一致！";
    } else {
        try {
            $hashed_password = password_hash($password, PASSWORD_DEFAULT);
            $stmt = $pdo->prepare("INSERT INTO users (username, password) VALUES (?, ?)");
            $stmt->execute([$username, $hashed_password]);
            $_SESSION['success'] = "注册成功，请登录！";
            header("Location: login.php");
            exit();
        } catch(PDOException $e) {
            if ($e->getCode() == 23000) {
                $error = "用户名已存在！";
            } else {
                $error = "注册失败，请稍后重试";
            }
        }
    }
}
?>

<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
    <title>用户注册 - 多课程在线刷题系统</title>
    <link rel="stylesheet" href="../config/style.css">
    <style>
        body { 
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 20px;
        }
        .register-card {
            background: white;
            padding: 30px;
            border-radius: 20px;
            box-shadow: 0 20px 40px rgba(0,0,0,0.1);
            width: 100%;
            max-width: 400px;
        }
        .logo {
            text-align: center;
            margin-bottom: 30px;
        }
        .logo h1 {
            color: var(--primary-color);
            font-size: 28px;
        }
        .registration-notice {
            background: #e7f3ff;
            border: 1px solid #b3d9ff;
            border-radius: 8px;
            padding: 15px;
            margin: 20px 0;
            font-size: 14px;
        }
        .system-benefits {
            background: #f0f9ff;
            border: 1px solid #bae6fd;
            border-radius: 8px;
            padding: 15px;
            margin: 20px 0;
            font-size: 14px;
        }
    </style>
</head>
<body>
    <div class="register-card">
        <div class="logo">
            <h1>📚 多课程刷题系统</h1>
            <p>创建你的学习账号</p>
        </div>
        
        <?php if (isset($error)): ?>
            <div class="alert alert-error"><?php echo $error; ?></div>
        <?php endif; ?>
        
        <?php if (isset($_SESSION['success'])): ?>
            <div class="alert alert-success"><?php echo $_SESSION['success']; unset($_SESSION['success']); ?></div>
        <?php endif; ?>

        <div class="system-benefits">
            <strong>🎯 注册后您将获得：</strong>
            <ul style="margin: 8px 0 0 20px;">
                <li>多课程学习资源</li>
                <li>个性化学习路径</li>
                <li>智能错题复习</li>
                <li>学习进度追踪</li>
            </ul>
        </div>

        <div class="registration-notice">
            <strong>💡 注册说明：</strong>
            <p>请使用真实有效的用户名，注册后即可开始学习。</p>
        </div>

        <form method="post">
            <div class="form-group">
                <label for="username" class="form-label">用户名：</label>
                <input type="text" id="username" name="username" class="form-input" 
                       value="<?php echo isset($_POST['username']) ? htmlspecialchars($_POST['username']) : ''; ?>" 
                       placeholder="请输入用户名" required minlength="3">
            </div>
            
            <div class="form-group">
                <label for="password" class="form-label">密码：</label>
                <input type="password" id="password" name="password" class="form-input" 
                       placeholder="请输入密码（至少6位）" required minlength="6">
            </div>
            
            <div class="form-group">
                <label for="confirm_password" class="form-label">确认密码：</label>
                <input type="password" id="confirm_password" name="confirm_password" class="form-input" 
                       placeholder="请再次输入密码" required minlength="6">
            </div>
            
            <button type="submit" class="btn btn-primary btn-full">注册账号</button>
        </form>
        
        <div class="text-center mt-3">
            <p>已有账号？<a href="login.php" style="color: var(--primary-color);">立即登录</a></p>
            <p><a href="../index.php" style="color: var(--text-secondary);">返回首页</a></p>
        </div>
    </div>

    <script>
        // 实时检查密码匹配
        const password = document.getElementById('password');
        const confirmPassword = document.getElementById('confirm_password');
        
        function checkPasswordMatch() {
            if (password.value !== confirmPassword.value) {
                confirmPassword.style.borderColor = 'var(--error-color)';
            } else {
                confirmPassword.style.borderColor = 'var(--success-color)';
            }
        }
        
        password.addEventListener('input', checkPasswordMatch);
        confirmPassword.addEventListener('input', checkPasswordMatch);
    </script>
</body>
</html>