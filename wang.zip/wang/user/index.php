<?php
require_once '../config/database.php';

// 检查网站是否开启
$site_enabled = true;
try {
    $check_table = $pdo->query("SHOW TABLES LIKE 'system_settings'");
    if ($check_table->rowCount() > 0) {
        $setting_stmt = $pdo->prepare("SELECT setting_value FROM system_settings WHERE setting_key = 'site_enabled'");
        $setting_stmt->execute();
        $setting = $setting_stmt->fetch();
        if ($setting && $setting['setting_value'] == '0') {
            $site_enabled = false;
        }
    }
} catch (PDOException $e) {
    // 如果查询失败，默认网站开启
    $site_enabled = true;
}

// 如果网站关闭且用户不是管理员，显示维护页面
if (!$site_enabled && (!isset($_SESSION['user_id']) || $_SESSION['role'] != 'admin')) {
    include '../maintenance.php';
    exit();
}

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

// 获取所有课程
$courses_stmt = $pdo->prepare("SELECT * FROM courses WHERE status = 'active' ORDER BY sort_order, id");
$courses_stmt->execute();
$courses = $courses_stmt->fetchAll();

// 获取用户学习统计
$stats_stmt = $pdo->prepare("
    SELECT 
        COUNT(DISTINCT p.id) as total_projects,
        COUNT(DISTINCT up.project_id) as completed_projects,
        AVG(up.score) as avg_score
    FROM projects p
    LEFT JOIN user_progress up ON p.id = up.project_id AND up.user_id = ? AND up.completed = TRUE
");
$stats_stmt->execute([$_SESSION['user_id']]);
$stats = $stats_stmt->fetch();

// 获取错题数量
$wrong_count_stmt = $pdo->prepare("SELECT COUNT(DISTINCT question_id) as wrong_count FROM wrong_questions WHERE user_id = ?");
$wrong_count_stmt->execute([$_SESSION['user_id']]);
$wrong_count = $wrong_count_stmt->fetchColumn();

// 获取收藏数量
$favorite_count_stmt = $pdo->prepare("SELECT COUNT(*) as favorite_count FROM favorite_questions WHERE user_id = ?");
$favorite_count_stmt->execute([$_SESSION['user_id']]);
$favorite_count = $favorite_count_stmt->fetchColumn();
?>

<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
    <title>学习中心 - 多课程在线刷题系统</title>
    <link rel="stylesheet" href="../config/style.css">
    <style>
        .hero-section {
            background: linear-gradient(135deg, var(--primary-color), var(--secondary-color));
            color: white;
            padding: 40px 0;
            margin: 0 -16px 32px;
            padding-left: 16px;
            padding-right: 16px;
        }
        
        .welcome-text {
            font-size: 24px;
            font-weight: 700;
            margin-bottom: 8px;
        }
        
        .subtitle {
            opacity: 0.9;
            font-size: 16px;
        }
        
        .quick-stats {
            display: grid;
            grid-template-columns: repeat(4, 1fr);
            gap: 12px;
            margin: 24px 0;
        }
        
        .quick-stat {
            background: rgba(255, 255, 255, 0.2);
            padding: 16px;
            border-radius: 12px;
            text-align: center;
            backdrop-filter: blur(10px);
            transition: transform 0.2s ease;
        }
        
        .quick-stat:hover {
            transform: translateY(-2px);
        }
        
        .quick-stat-number {
            font-size: 20px;
            font-weight: 700;
            margin-bottom: 4px;
        }
        
        .quick-stat-label {
            font-size: 12px;
            opacity: 0.9;
        }
        
        /* 课程卡片样式 */
        .course-list {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(350px, 1fr));
            gap: 16px;
        }
        
        .course-item {
            background: var(--bg-primary);
            border-radius: 12px;
            padding: 20px;
            box-shadow: var(--shadow);
            border-left: 4px solid var(--primary-color);
            transition: transform 0.2s ease;
        }
        
        .course-item:hover {
            transform: translateY(-2px);
            box-shadow: 0 8px 16px rgba(0,0,0,0.1);
        }
        
        .course-header {
            display: flex;
            justify-content: space-between;
            align-items: flex-start;
            margin-bottom: 12px;
        }
        
        .course-title {
            font-size: 18px;
            font-weight: 600;
            color: var(--text-primary);
            flex: 1;
        }
        
        .course-status {
            font-size: 14px;
            padding: 4px 12px;
            border-radius: 20px;
            background: var(--success-color);
            color: white;
        }
        
        .course-status.pending {
            background: var(--warning-color);
        }
        
        .course-desc {
            color: var(--text-secondary);
            font-size: 14px;
            margin-bottom: 16px;
        }
        
        .course-stats {
            display: flex;
            justify-content: space-between;
            margin: 15px 0;
            padding: 15px 0;
            border-top: 1px solid var(--border-color);
            border-bottom: 1px solid var(--border-color);
        }
        
        .course-stat {
            text-align: center;
            flex: 1;
        }
        
        .course-stat-number {
            font-size: 18px;
            font-weight: 700;
            color: var(--primary-color);
        }
        
        .course-stat-label {
            font-size: 12px;
            color: var(--text-secondary);
        }
        
        .course-actions {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-top: 15px;
        }
        
        .course-progress {
            font-size: 14px;
            color: var(--text-secondary);
        }
        
        .floating-action {
            position: fixed;
            bottom: 24px;
            right: 24px;
            z-index: 50;
        }
        
        .action-buttons {
            display: flex;
            gap: 10px;
            margin-top: 20px;
            flex-wrap: wrap;
        }
        
        .profile-header-container {
            display: flex;
            justify-content: space-between;
            align-items: flex-start;
            flex-wrap: wrap;
            gap: 16px;
        }
        
        .learning-tips {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 16px;
            margin-top: 16px;
        }
        
        .tip-card {
            text-align: center;
            padding: 16px;
            background: var(--bg-tertiary);
            border-radius: 8px;
            transition: transform 0.2s ease;
        }
        
        .tip-card:hover {
            transform: translateY(-2px);
        }
        
        /* 移动端适配 */
        @media (max-width: 768px) {
            .quick-stats {
                grid-template-columns: repeat(2, 1fr);
            }
            
            .hero-section {
                padding: 32px 0;
            }
            
            .welcome-text {
                font-size: 20px;
            }
            
            .quick-stats {
                grid-template-columns: repeat(2, 1fr);
                gap: 8px;
            }
            
            .quick-stat {
                padding: 12px;
            }
            
            .quick-stat-number {
                font-size: 18px;
            }
            
            .action-buttons {
                flex-direction: column;
            }
            
            .action-buttons .btn {
                width: 100%;
            }
            
            .course-list {
                grid-template-columns: 1fr;
            }
            
            .profile-header-container {
                flex-direction: column;
                align-items: stretch;
            }
            
            .course-stats {
                flex-direction: column;
                gap: 10px;
            }
            
            .course-actions {
                flex-direction: column;
                gap: 10px;
                align-items: stretch;
            }
        }
        
        @media (min-width: 769px) and (max-width: 1024px) {
            .course-list {
                grid-template-columns: repeat(2, 1fr);
            }
        }
        
        @media (min-width: 1025px) {
            .course-list {
                grid-template-columns: repeat(auto-fit, minmax(350px, 1fr));
            }
        }
    </style>
</head>
<body>
    <!-- 导航栏 -->
    <nav class="navbar">
        <div class="container">
            <div class="nav-content">
                <a href="index.php" class="nav-brand">📚 学习中心</a>
                <button class="mobile-menu-btn" onclick="toggleMenu()">☰</button>
                <div class="nav-menu" id="navMenu">
                    <a href="wrong_questions.php" class="nav-link">📖 错题本<?php echo $wrong_count > 0 ? " ($wrong_count)" : ""; ?></a>
                    <a href="favorites.php" class="nav-link">❤️ 我的收藏<?php echo $favorite_count > 0 ? " ($favorite_count)" : ""; ?></a>
                    <?php if (isset($_SESSION['role']) && $_SESSION['role'] == 'admin'): ?>
                        <a href="../admin/index.php" class="nav-link">⚙️ 管理</a>
                    <?php endif; ?>
                    <a href="change_password.php" class="nav-link">🔒 修改密码</a>
                    <a href="logout.php" class="nav-link">🚪 退出</a>
                </div>
            </div>
        </div>
    </nav>

    <div class="container">
        <!-- 欢迎区域 -->
        <div class="hero-section">
            <div class="profile-header-container">
                <div>
                    <div class="welcome-text">欢迎, <?php echo htmlspecialchars($_SESSION['username']); ?>!</div>
                    <div class="subtitle">选择课程开始学习</div>
                </div>
            </div>
            
            <!-- 快速统计 -->
            <div class="quick-stats">
                <div class="quick-stat">
                    <div class="quick-stat-number"><?php echo count($courses); ?></div>
                    <div class="quick-stat-label">总课程</div>
                </div>
                <div class="quick-stat">
                    <div class="quick-stat-number"><?php echo $stats['completed_projects'] ?? 0; ?></div>
                    <div class="quick-stat-label">完成项目</div>
                </div>
                <div class="quick-stat">
                    <div class="quick-stat-number"><?php echo $stats['avg_score'] ? round($stats['avg_score'], 1) : '0'; ?></div>
                    <div class="quick-stat-label">平均分数</div>
                </div>
                <div class="quick-stat">
                    <a href="profile.php" style="color: white; text-decoration: none; display: block;">
                        <div class="quick-stat-number">📊</div>
                        <div class="quick-stat-label">详细统计</div>
                    </a>
                </div>
            </div>
        </div>

        <!-- 课程列表 -->
        <h2 class="mb-3">我的课程</h2>
        <div class="course-list">
            <?php foreach ($courses as $course): 
                // 获取课程的模块数量
                $modules_stmt = $pdo->prepare("SELECT COUNT(*) as module_count FROM modules WHERE course_id = ?");
                $modules_stmt->execute([$course['id']]);
                $module_count = $modules_stmt->fetchColumn();
                
                // 获取课程的项目数量
                $projects_stmt = $pdo->prepare("
                    SELECT COUNT(*) as project_count 
                    FROM projects p 
                    JOIN modules m ON p.module_id = m.id 
                    WHERE m.course_id = ?
                ");
                $projects_stmt->execute([$course['id']]);
                $project_count = $projects_stmt->fetchColumn();
                
                // 获取用户在该课程中完成的项目数量
                $completed_projects_stmt = $pdo->prepare("
                    SELECT COUNT(*) as completed_count 
                    FROM user_progress up 
                    JOIN projects p ON up.project_id = p.id 
                    JOIN modules m ON p.module_id = m.id 
                    WHERE up.user_id = ? AND up.completed = TRUE AND m.course_id = ?
                ");
                $completed_projects_stmt->execute([$_SESSION['user_id'], $course['id']]);
                $completed_count = $completed_projects_stmt->fetchColumn();
                
                // 计算课程进度
                $progress = $project_count > 0 ? round(($completed_count / $project_count) * 100) : 0;
            ?>
                <div class="course-item">
                    <div class="course-header">
                        <div class="course-title"><?php echo htmlspecialchars($course['course_name']); ?></div>
                        <div class="course-status <?php echo $progress == 100 ? '' : 'pending'; ?>">
                            <?php echo $progress == 100 ? '已完成' : '学习中'; ?>
                        </div>
                    </div>
                    <div class="course-desc">
                        <?php echo htmlspecialchars($course['description']); ?>
                    </div>
                    
                    <div class="course-stats">
                        <div class="course-stat">
                            <div class="course-stat-number"><?php echo $module_count; ?></div>
                            <div class="course-stat-label">学习模块</div>
                        </div>
                        <div class="course-stat">
                            <div class="course-stat-number"><?php echo $project_count; ?></div>
                            <div class="course-stat-label">刷题项目</div>
                        </div>
                        <div class="course-stat">
                            <div class="course-stat-number"><?php echo $progress; ?>%</div>
                            <div class="course-stat-label">完成进度</div>
                        </div>
                    </div>
                    
                    <div class="course-actions">
                        <div class="course-progress">
                            <?php if ($completed_count > 0): ?>
                                已完成: <?php echo $completed_count; ?>/<?php echo $project_count; ?> 项目
                            <?php else: ?>
                                尚未开始
                            <?php endif; ?>
                        </div>
                        <a href="course_detail.php?course_id=<?php echo $course['id']; ?>" class="btn btn-primary btn-sm">
                            <?php echo $completed_count > 0 ? '继续学习' : '开始学习'; ?>
                        </a>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
        
        <?php if (empty($courses)): ?>
            <div class="card text-center" style="padding: 60px 20px;">
                <div style="font-size: 64px; margin-bottom: 20px;">📚</div>
                <h3>暂无课程</h3>
                <p>管理员正在准备课程内容，请稍后再来</p>
                <?php if (isset($_SESSION['role']) && $_SESSION['role'] == 'admin'): ?>
                    <a href="../admin/index.php" class="btn btn-primary mt-3">前往管理后台添加课程</a>
                <?php endif; ?>
            </div>
        <?php endif; ?>
        
        <!-- 功能提示 -->
        <div class="card mt-4">
            <h3>💡 系统特色</h3>
            <div class="learning-tips">
                <div class="tip-card">
                    <div style="font-size: 24px; margin-bottom: 8px;">🎯</div>
                    <div style="font-weight: 600;">分层学习</div>
                    <div style="font-size: 12px; color: var(--text-secondary);">课程→模块→项目三层结构</div>
                </div>
                <div class="tip-card">
                    <div style="font-size: 24px; margin-bottom: 8px;">❤️</div>
                    <div style="font-weight: 600;">收藏题目</div>
                    <div style="font-size: 12px; color: var(--text-secondary);">点击心形图标收藏重点题目</div>
                </div>
                <div class="tip-card">
                    <div style="font-size: 24px; margin-bottom: 8px;">📖</div>
                    <div style="font-weight: 600;">错题复习</div>
                    <div style="font-size: 12px; color: var(--text-secondary);">自动记录错题便于重点复习</div>
                </div>
                <div class="tip-card">
                    <div style="font-size: 24px; margin-bottom: 8px;">📊</div>
                    <div style="font-weight: 600;">学习统计</div>
                    <div style="font-size: 12px; color: var(--text-secondary);">查看详细学习进度和统计</div>
                </div>
            </div>
        </div>
    </div>

    <!-- 浮动操作按钮 -->
    <div class="floating-action">
        <div style="display: flex; flex-direction: column; gap: 10px;">
            <?php if ($wrong_count > 0): ?>
                <a href="wrong_questions.php" class="btn btn-error" style="white-space: nowrap;">
                    📖 复习错题
                </a>
            <?php endif; ?>
            <?php if ($favorite_count > 0): ?>
                <a href="favorites.php" class="btn" style="background: #e74c3c; color: white; white-space: nowrap;">
                    ❤️ 我的收藏
                </a>
            <?php endif; ?>
        </div>
    </div>

    <script>
        function toggleMenu() {
            const menu = document.getElementById('navMenu');
            menu.classList.toggle('active');
        }
        
        // 点击其他地方关闭菜单
        document.addEventListener('click', function(event) {
            const menu = document.getElementById('navMenu');
            const button = document.querySelector('.mobile-menu-btn');
            if (!menu.contains(event.target) && !button.contains(event.target)) {
                menu.classList.remove('active');
            }
        });
        
        // 页面加载动画
        document.addEventListener('DOMContentLoaded', function() {
            const courseItems = document.querySelectorAll('.course-item');
            courseItems.forEach((item, index) => {
                item.style.opacity = '0';
                item.style.transform = 'translateY(20px)';
                setTimeout(() => {
                    item.style.transition = 'all 0.5s ease';
                    item.style.opacity = '1';
                    item.style.transform = 'translateY(0)';
                }, index * 100);
            });
        });
    </script>
</body>
</html>