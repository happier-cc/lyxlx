<?php
require_once '../config/database.php';

try {
    // 插入或更新网站开关设置
    $stmt = $pdo->prepare("
        INSERT INTO system_settings (setting_key, setting_value, description) 
        VALUES ('site_enabled', '1', '网站开关（1开启，0关闭）')
        ON DUPLICATE KEY UPDATE setting_value = VALUES(setting_value)
    ");
    $stmt->execute();
    
    // 插入或更新注册设置
    $stmt = $pdo->prepare("
        INSERT INTO system_settings (setting_key, setting_value, description) 
        VALUES ('registration_enabled', '1', '用户注册功能开关（1开启，0关闭）')
        ON DUPLICATE KEY UPDATE setting_value = VALUES(setting_value)
    ");
    $stmt->execute();
    
    echo "系统设置初始化成功！";
    echo "<br><a href='../admin/manage_settings.php'>返回系统设置</a>";
    
} catch (PDOException $e) {
    echo "初始化失败：" . $e->getMessage();
}
?>