<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
    <title>系统维护中 - 在线刷题系统</title>
    <link rel="stylesheet" href="config/style.css">
    <style>
        body { 
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 20px;
            margin: 0;
        }
        .maintenance-card {
            background: white;
            padding: 40px;
            border-radius: 20px;
            box-shadow: 0 20px 40px rgba(0,0,0,0.1);
            text-align: center;
            max-width: 500px;
            width: 100%;
        }
        .maintenance-icon {
            font-size: 64px;
            margin-bottom: 20px;
        }
        .admin-login {
            background: #f8f9fa;
            padding: 20px;
            border-radius: 10px;
            margin: 20px 0;
        }
    </style>
</head>
<body>
    <div class="maintenance-card">
        <div class="maintenance-icon">🔧</div>
        <h1>系统维护中</h1>
        <p>我们正在对系统进行维护升级，以提供更好的服务体验。</p>
        
        <div style="background: #f8f9fa; padding: 20px; border-radius: 10px; margin: 20px 0;">
            <p><strong>维护内容：</strong></p>
            <ul style="text-align: left; margin: 10px 0;">
                <li>系统性能优化</li>
                <li>功能更新升级</li>
                <li>安全漏洞修复</li>
            </ul>
        </div>
        
        <p>预计完成时间将另行通知，给您带来的不便敬请谅解。</p>
        

        <div style="margin-top: 20px; font-size: 14px; color: var(--text-secondary);">
            <p>如有紧急问题，请联系系统管理员</p>
        </div>
    </div>
</body>
</html>