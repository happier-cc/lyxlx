<?php
require_once 'config/database.php';

// 检查网站是否开启
$site_enabled = true;
try {
    $check_table = $pdo->query("SHOW TABLES LIKE 'system_settings'");
    if ($check_table->rowCount() > 0) {
        $setting_stmt = $pdo->prepare("SELECT setting_value FROM system_settings WHERE setting_key = 'site_enabled'");
        $setting_stmt->execute();
        $setting = $setting_stmt->fetch();
        if ($setting && $setting['setting_value'] == '0') {
            $site_enabled = false;
        }
    }
} catch (PDOException $e) {
    // 如果查询失败，默认网站开启
    $site_enabled = true;
}

// 如果网站关闭且用户不是管理员，显示维护页面
if (!$site_enabled && (!isset($_SESSION['user_id']) || $_SESSION['role'] != 'admin')) {
    include 'maintenance.php';
    exit();
}

// 检查用户是否已登录
$is_logged_in = isset($_SESSION['user_id']);
$username = $is_logged_in ? $_SESSION['username'] : '';
$user_role = $is_logged_in ? ($_SESSION['role'] ?? 'user') : '';

// 获取课程列表
$courses_stmt = $pdo->prepare("SELECT * FROM courses WHERE status = 'active' ORDER BY sort_order, id");
$courses_stmt->execute();
$courses = $courses_stmt->fetchAll();
?>

<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
    <title>河南职教高考在线刷题系统 - 提升你的学习效率</title>
    <link rel="stylesheet" href="config/style.css">
    <style>
        .hero-section {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            padding: 80px 0;
            text-align: center;
        }
        
        .hero-title {
            font-size: 2.5rem;
            font-weight: 700;
            margin-bottom: 1rem;
        }
        
        .hero-subtitle {
            font-size: 1.2rem;
            opacity: 0.9;
            margin-bottom: 2rem;
        }
        
        .courses-section {
            padding: 60px 0;
        }
        
        .course-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
            gap: 30px;
            margin-top: 40px;
        }
        
        .course-card {
            background: white;
            border-radius: 15px;
            padding: 30px;
            box-shadow: 0 10px 30px rgba(0,0,0,0.1);
            transition: transform 0.3s ease;
            text-align: center;
        }
        
        .course-card:hover {
            transform: translateY(-5px);
        }
        
        .course-icon {
            font-size: 48px;
            margin-bottom: 20px;
        }
        
        .course-title {
            font-size: 1.3rem;
            font-weight: 600;
            margin-bottom: 15px;
            color: var(--text-primary);
        }
        
        .course-stats {
            display: flex;
            justify-content: space-around;
            margin: 20px 0;
            padding: 15px 0;
            border-top: 1px solid var(--border-color);
            border-bottom: 1px solid var(--border-color);
        }
        
        .stat {
            text-align: center;
        }
        
        .stat-number {
            font-size: 1.5rem;
            font-weight: 700;
            color: var(--primary-color);
        }
        
        .stat-label {
            font-size: 0.9rem;
            color: var(--text-secondary);
        }
        
        .user-welcome {
            background: rgba(255, 255, 255, 0.1);
            padding: 20px;
            border-radius: 10px;
            margin: 20px 0;
            text-align: center;
        }
        
        .user-actions {
            display: flex;
            gap: 15px;
            justify-content: center;
            margin-top: 20px;
            flex-wrap: wrap;
        }
        
        .action-buttons {
            display: flex;
            gap: 20px;
            justify-content: center;
            margin-top: 30px;
            flex-wrap: wrap;
        }
        
        @media (max-width: 768px) {
            .hero-title {
                font-size: 2rem;
            }
            
            .hero-subtitle {
                font-size: 1rem;
            }
            
            .action-buttons {
                flex-direction: column;
                align-items: center;
            }
            
            .user-actions {
                flex-direction: column;
                align-items: center;
            }
            
            .course-grid {
                grid-template-columns: 1fr;
            }
        }
    </style>
</head>
<body>
    <!-- 导航栏 -->
    <nav class="navbar">
        <div class="container">
            <div class="nav-content">
                <a href="index.php" class="nav-brand">📚 河南职教高考刷题系统</a>
                <div class="nav-menu">
                    <?php if ($is_logged_in): ?>
                        <span style="color: var(--text-secondary); margin-right: 15px;">
                            欢迎, <?php echo htmlspecialchars($username); ?>
                        </span>
                        <a href="user/index.php" class="nav-link">学习中心</a>
                        <?php if ($user_role == 'admin'): ?>
                            <a href="admin/index.php" class="nav-link">管理后台</a>
                        <?php endif; ?>
                        <a href="user/logout.php" class="nav-link">退出</a>
                    <?php else: ?>
                        <a href="user/login.php" class="nav-link">用户登录</a>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </nav>

    <!-- 首页内容 -->
    <section class="hero-section">
        <div class="container">
            <h1 class="hero-title">职教高考旅游类在线学习平台</h1>
            <p class="hero-subtitle">专为参加2026年、2027年职教高考的旅游类考生开发设计</p>
            
            <?php if ($is_logged_in): ?>
                <!-- 已登录用户显示 -->
                <div class="user-welcome">
                    <h2>欢迎回来, <?php echo htmlspecialchars($username); ?>! 👋</h2>
                    <p>选择课程开始你的学习之旅</p>
                    <div class="user-actions">
                        <a href="user/index.php" class="btn btn-primary">进入学习中心</a>
                        <?php if ($user_role == 'admin'): ?>
                            <a href="admin/index.php" class="btn btn-outline" style="background: rgba(255,255,255,0.1); color: white; border-color: white;">管理后台</a>
                        <?php endif; ?>
                    </div>
                </div>
            <?php else: ?>
                <!-- 未登录用户显示 -->
                <div class="action-buttons">
                    <a href="user/register.php" class="btn btn-primary">免费注册</a>
                    <a href="user/login.php" class="btn btn-outline" style="background: rgba(255,255,255,0.1); color: white; border-color: white;">立即登录</a>
                </div>
            <?php endif; ?>
        </div>
    </section>

    <!-- 课程展示 -->
    <section class="courses-section">
        <div class="container">
            <h2 class="text-center" style="margin-bottom: 20px;">可选课程</h2>
            <p class="text-center" style="color: var(--text-secondary); margin-bottom: 40px;">选择你感兴趣的课程开始学习</p>
            
            <?php if (empty($courses)): ?>
                <div class="text-center" style="padding: 60px 20px;">
                    <div style="font-size: 64px; margin-bottom: 20px;">📚</div>
                    <h3>暂无课程</h3>
                    <p>管理员正在准备课程内容，请稍后再来</p>
                </div>
            <?php else: ?>
                <div class="course-grid">
                    <?php foreach ($courses as $course): 
                        // 获取课程的模块数量
                        $modules_stmt = $pdo->prepare("SELECT COUNT(*) as module_count FROM modules WHERE course_id = ?");
                        $modules_stmt->execute([$course['id']]);
                        $module_count = $modules_stmt->fetchColumn();
                        
                        // 获取课程的项目数量
                        $projects_stmt = $pdo->prepare("
                            SELECT COUNT(*) as project_count 
                            FROM projects p 
                            JOIN modules m ON p.module_id = m.id 
                            WHERE m.course_id = ?
                        ");
                        $projects_stmt->execute([$course['id']]);
                        $project_count = $projects_stmt->fetchColumn();
                    ?>
                        <div class="course-card">
                            <div class="course-icon">📖</div>
                            <h3 class="course-title"><?php echo htmlspecialchars($course['course_name']); ?></h3>
                            <p style="color: var(--text-secondary); margin-bottom: 20px;">
                                <?php echo htmlspecialchars($course['description']); ?>
                            </p>
                            
                            <div class="course-stats">
                                <div class="stat">
                                    <div class="stat-number"><?php echo $module_count; ?></div>
                                    <div class="stat-label">模块</div>
                                </div>
                                <div class="stat">
                                    <div class="stat-number"><?php echo $project_count; ?></div>
                                    <div class="stat-label">项目</div>
                                </div>
                            </div>
                            
                            <?php if ($is_logged_in): ?>
                                <a href="user/course_detail.php?course_id=<?php echo $course['id']; ?>" class="btn btn-primary btn-full">
                                    开始学习
                                </a>
                            <?php else: ?>
                                <a href="user/login.php" class="btn btn-outline btn-full">
                                    登录后学习
                                </a>
                            <?php endif; ?>
                        </div>
                    <?php endforeach; ?>
                </div>
            <?php endif; ?>
        </div>
    </section>

    <footer style="background: var(--text-primary); color: white; padding: 40px 0; text-align: center;">
        <div class="container">
            <p>&copy; 2026 河南职教高考旅游类在线学习平台. 所有权利保留.</p>
            <p><a href="https://beian.miit.gov.cn/" target="_blank">豫ICP备2026003688号</a></p>
        </div>
    </footer>
</body>
</html>